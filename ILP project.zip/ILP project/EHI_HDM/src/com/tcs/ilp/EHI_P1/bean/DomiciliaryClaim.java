package com.tcs.ilp.EHI_P1.bean;

import java.sql.Timestamp;
import java.util.Date;

public class DomiciliaryClaim {
	private String claimId;
	private String status;
	private String HealthInsuranceId;
	private String TPAId;
	private double approvedAmount;
	private Date approvedDateTime;
	private String altEmailId;
	private String treatmentStartDate;
	private String treatmentEndDate;
	private String dateOfInjury;
	private String nameOfDoctor;
	private String TypeOfillness;
	private double totalClaimAmount;
	private String[] uploadPath = new String[4];
	private String action;
	private String claim_type;
	private String claim_escalation;
	private Timestamp claim_date;

	
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHealthInsuranceId() {
		return HealthInsuranceId;
	}
	public void setHealthInsuranceId(String healthInsuranceId) {
		HealthInsuranceId = healthInsuranceId;
	}
	public String getTPAId() {
		return TPAId;
	}
	public void setTPAId(String tPAId) {
		TPAId = tPAId;
	}
	public double getApprovedAmount() {
		return approvedAmount;
	}
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}
	public Date getApprovedDateTime() {
		return approvedDateTime;
	}
	public void setApprovedDateTime(Date approvedDateTime) {
		this.approvedDateTime = approvedDateTime;
	}
	public String getAltEmailId() {
		return altEmailId;
	}
	public void setAltEmailId(String altEmailId) {
		this.altEmailId = altEmailId;
	}
	public String getTreatmentStartDate() {
		return treatmentStartDate;
	}
	public void setTreatmentStartDate(String treatmentStartDate) {
		this.treatmentStartDate = treatmentStartDate;
	}
	public String getTreatmentEndDate() {
		return treatmentEndDate;
	}
	public void setTreatmentEndDate(String treatmentEndDate) {
		this.treatmentEndDate = treatmentEndDate;
	}
	public String getDateOfInjury() {
		return dateOfInjury;
	}
	public void setDateOfInjury(String dateOfInjury) {
		this.dateOfInjury = dateOfInjury;
	}
	public String getNameOfDoctor() {
		return nameOfDoctor;
	}
	public void setNameOfDoctor(String nameOfDoctor) {
		this.nameOfDoctor = nameOfDoctor;
	}
	public String getTypeOfillness() {
		return TypeOfillness;
	}
	public void setTypeOfillness(String typeOfillness) {
		TypeOfillness = typeOfillness;
	}
	
	
	
	public double getTotalClaimAmount() {
		return totalClaimAmount;
	}
	public void setTotalClaimAmount(double totalClaimAmount) {
		this.totalClaimAmount = totalClaimAmount;
	}
	public String[] getUploadPath() {
		return uploadPath;
	}
	public void setUploadPath(String[] uploadPath) {
		this.uploadPath = uploadPath;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getClaim_type() {
		return claim_type;
	}
	public void setClaim_type(String claim_type) {
		this.claim_type = claim_type;
	}
	public String getClaim_escalation() {
		return claim_escalation;
	}
	public void setClaim_escalation(String claim_escalation) {
		this.claim_escalation = claim_escalation;
	}
	public Timestamp getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(Timestamp claim_date) {
		this.claim_date = claim_date;
	}
	
	
}
