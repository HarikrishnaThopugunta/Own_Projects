package com.tcs.ilp.EHI_P1.bean;

import java.sql.Timestamp;

public class Beneficiary {
	
	private String HealthInsuranceId;
	private long EmployeeId;
	private String BeneficiaryName=null;
	private String Relation;
	private String DateOfBirth;
	private String Gender;
	private long PolicyNo;
	private String PolicyStartDate;
	private int PolicyPeriod;
	private double TotalSumInsured;
	private String status;
	private String TPAID;
	private Timestamp RegisteredTime;
	private Timestamp Approvetime;
	private String Reason;
	private Timestamp LastUpdateDateTime;

	public String getHealthInsuranceId()
	{
		return HealthInsuranceId;
	}

	public void setHealthInsuranceId(String healthInsuranceId)
	{
		HealthInsuranceId = healthInsuranceId;
	}

	public long getEmployeeId()
	{
		return EmployeeId;
	}

	public void setEmployeeId(long employeeId)
	{
		EmployeeId = employeeId;
	}

	public String getBeneficiaryName() 
	{
		return BeneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) 
	{
		BeneficiaryName = beneficiaryName;
	}

	public String getRelation()
	{
		return Relation;
	}

	public void setRelation(String relation) 
	{
		Relation = relation;
	}

	

	public String getGender() 
	{
		return Gender;
	}

	public void setGender(String gender) 
	{
		Gender = gender;
	}

	public long getPolicyNo() {
		return PolicyNo;
	}

	public void setPolicyNo(long policyNo) 
	{
		PolicyNo= policyNo;
	}

	
	public String getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public String getPolicyStartDate() {
		return PolicyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		PolicyStartDate = policyStartDate;
	}

	public int getPolicyPeriod() 
	{
		return PolicyPeriod;
	}

	public void setPolicyPeriod(int policyPeriod) 
	{
		PolicyPeriod = policyPeriod;
	}

	public double getTotalSumInsured() 
	{
		return TotalSumInsured;
	}

	public void setTotalSumInsured(double totalSumInsured) 
	{
		TotalSumInsured = totalSumInsured;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTPAID() {
		return TPAID;
	}

	public void setTPAID(String string) {
		TPAID = string;
	}

	public Timestamp getRegisteredTime() {
		return RegisteredTime;
	}

	public void setRegisteredTime(Timestamp registeredTime) {
		RegisteredTime = registeredTime;
	}

	public Timestamp getApprovetime() {
		return Approvetime;
	}

	public void setApprovetime(Timestamp approvetime) {
		Approvetime = approvetime;
	}

	public String getReason() {
		return Reason;
	}

	public void setReason(String reason) {
		Reason = reason;
	}

	public Timestamp getLastUpdateDateTime() 
	{
		return LastUpdateDateTime;
	}

	public void setLastUpdateDateTime(Timestamp lastUpdateDateTime) 
	{
		LastUpdateDateTime = lastUpdateDateTime;
	}




}
