package com.tcs.ilp.EHI_P1.bean;

import java.util.ArrayList;

public class City {
	
	private String cityId;
	private String stateId;
	private ArrayList<String> cityName;
	private long STDCode;
	private ArrayList<String> stateName;
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	
	
	public long getSTDCode() {
		return STDCode;
	}
	public void setSTDCode(long sTDCode) {
		STDCode = sTDCode;
	}
	public ArrayList<String> getCityName() {
		return cityName;
	}
	public void setCityName(ArrayList<String> cityName) {
		this.cityName = cityName;
	}
	public ArrayList<String> getStateName() {
		return stateName;
	}
	public void setStateName(ArrayList<String> stateName) {
		this.stateName = stateName;
	}
	
	
	
}
