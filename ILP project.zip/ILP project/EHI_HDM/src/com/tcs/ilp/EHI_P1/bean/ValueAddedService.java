package com.tcs.ilp.EHI_P1.bean;

public class ValueAddedService {
	private int VASId;
	public int getVASId() {
		return VASId;
	}
	public void setVASId(int vASId) {
		VASId = vASId;
	}
	private int employeeId;
	private String employeeName;
	private String gender;
	private int age;
	private long mobileNumber;
	private String email;
	private String appointmentFor;
	private String healthInsuranceID;
	private String state;
	private String city;
	private String location;
	private String hospitalName;
	private String preferredDate;
	private String prefferedTime;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAppointmentFor() {
		return appointmentFor;
	}
	public void setAppointmentFor(String appointmentFor) {
		this.appointmentFor = appointmentFor;
	}
	public String getHealthInsuranceID() {
		return healthInsuranceID;
	}
	public void setHealthInsuranceID(String healthInsuranceID) {
		this.healthInsuranceID = healthInsuranceID;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getPreferredDate() {
		return preferredDate;
	}
	public void setPreferredDate(String preferredDate) {
		this.preferredDate = preferredDate;
	}
	public String getPrefferedTime() {
		return prefferedTime;
	}
	public void setPrefferedTime(String prefferedTime) {
		this.prefferedTime = prefferedTime;
	}
	

}
