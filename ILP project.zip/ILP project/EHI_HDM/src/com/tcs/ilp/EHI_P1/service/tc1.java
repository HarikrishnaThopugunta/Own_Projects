package com.tcs.ilp.EHI_P1.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class tc1 {
	public static final int BUSINESS_START_HOUR = 9; //      9 AM
	 public static final int BUSINESS_END_HOUR = 18; // 6 PM
	 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm a");
	 
	 public int HourDifference(java.util.Date adate,java.util.Date sdate)
		{
			Calendar registeredDateTime = Calendar.getInstance();
			registeredDateTime.setTime(adate);
			Calendar approveDateTime = Calendar.getInstance();
			approveDateTime.setTime(sdate);
			System.out.println("Registered Date and time:\t\t" + sdf.format(registeredDateTime.getTime()));

			tc1 time = new tc1();
			int a= time.checkBusinessTime(registeredDateTime,approveDateTime);

			System.out.println("\nApproved date and time :\t\t" + sdf.format(approveDateTime.getTime()));
			return a;
		}
		public int checkBusinessTime(Calendar registeredDateTime,Calendar approvedDateTime)
		{
			// To get Present Working Day & Hour excluding Holidays

			int addTimeMins = 0;
			while(approvedDateTime.compareTo(registeredDateTime)>=0)

			{
				int diffMins=0;
				adjustToBusinessHours(registeredDateTime);


				// Finding Business End Time On That Day
				Calendar businessEndTime = Calendar.getInstance();
				if(registeredDateTime.get(Calendar.DAY_OF_YEAR)<approvedDateTime.get(Calendar.DAY_OF_YEAR))
				{


					businessEndTime.setTime(registeredDateTime.getTime());
					businessEndTime.set(Calendar.HOUR_OF_DAY, BUSINESS_END_HOUR);
					businessEndTime.clear(Calendar.MINUTE);
					diffMins = (int) (( businessEndTime.getTimeInMillis() -
							registeredDateTime.getTimeInMillis())/(1000*60));
					System.out.println("Differrence in minutes = "+diffMins);

				}
				else if(registeredDateTime.get(Calendar.DAY_OF_YEAR)==approvedDateTime.get(Calendar.DAY_OF_YEAR))
				{
					businessEndTime.setTime(approvedDateTime.getTime());
					diffMins = (int) (( businessEndTime.getTimeInMillis() -
							registeredDateTime.getTimeInMillis())/(1000*60));
					System.out.println("Same date but hour difference is = "+diffMins);

				}

				addTimeMins=addTimeMins+diffMins;

				System.out.println(addTimeMins);

				registeredDateTime.add(Calendar.DATE,1);
				registeredDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				registeredDateTime.clear(Calendar.MINUTE);

			}
			addTimeMins=addTimeMins/60;
			System.out.println("delay time is = " + addTimeMins);
			return addTimeMins;
		}


		// Method to skip Non-Business Hours (Before 9 AM and After 6 PM)

		public void adjustToBusinessHours(Calendar givenDateTime)
		{

			int hourOfDay = givenDateTime.get(Calendar.HOUR_OF_DAY);
			//System.out.println(hourOfDay);

			if(hourOfDay < BUSINESS_START_HOUR)    // Skip to 9 AM on that Day
			{

				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				givenDateTime.clear(Calendar.MINUTE);
			}

			if(hourOfDay >= BUSINESS_END_HOUR)   // Skip to Next Day 9 AM
			{

				givenDateTime.add(Calendar.DATE, 1);
				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				givenDateTime.clear(Calendar.MINUTE);
			}

			HolidayChecking(givenDateTime);       // skip Holidays
		}


		// Method to skip Holidays ( Weekends and General )

		public void HolidayChecking(Calendar givenDateTime)
		{
			GeneralHolidaysChecking(givenDateTime);   // General Holidays before Weekends
			//System.out.println(givenDateTime.get(Calendar.DAY_OF_WEEK));

			if(givenDateTime.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY)
			{

				givenDateTime.add(Calendar.DATE,2);    // Saturday and Sunday
				// in case of Business Hour
				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR); 
				givenDateTime.clear(Calendar.MINUTE);
			}

			if(givenDateTime.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)
			{

				givenDateTime.add(Calendar.DATE,1);    // Sunday
				// in case of Business Hour
				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				givenDateTime.clear(Calendar.MINUTE);
			}

			GeneralHolidaysChecking(givenDateTime);   // General Holidays after Weekends
		}

		// Method to skip General Holidays

		public void GeneralHolidaysChecking(Calendar givenDateTime)
		{
			// Considering only given Date without Time (Temp)
			Calendar givenDate = Calendar.getInstance(); 
			givenDate.setTime(givenDateTime.getTime());    
			givenDate.set(Calendar.HOUR_OF_DAY, 0);
			givenDate.set(Calendar.MINUTE, 0);   
			givenDate.set(Calendar.SECOND, 0);
			givenDate.set(Calendar.MILLISECOND, 0);

			// List of General Holidays
			GregorianCalendar[] generalHolidays =  getGeneralHolidays(givenDate);

			for(int i=0; i<generalHolidays.length; i++)  // Check for all Holidays
			{

				if(givenDate.equals(generalHolidays[i]))  
				{

					givenDateTime.add(Calendar.DATE,1); // Add one date to Actual Date & Time
					// in case of Business Hour
					givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
					givenDateTime.clear(Calendar.MINUTE);

					givenDate.add(Calendar.DATE,1);    // Add one date to Temp Date
				}
			}
		}

		// General Holidays list

		public GregorianCalendar[] getGeneralHolidays(Calendar givenDate)
		{

			GregorianCalendar[] genHolidays =  {

					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.JANUARY, 14),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.JANUARY, 26),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.MAY, 1),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.AUGUST, 15),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.OCTOBER, 2),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.NOVEMBER, 1),
					new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.DECEMBER, 25)

			};

			return genHolidays;
		}
		public void GenerateEscalationReport(String hiid) {
			// TODO Auto-generated method stub
			
		}


}
