package com.tcs.ilp.EHI_P1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.bean.TPABean;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.service.EmployeeService;
import com.tcs.ilp.EHI_P1.service.TPAService;
import com.tcs.ilp.EHI_P1.service.tc1;

public class TPAController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String Password;
	public static String Userid;
	static String health;

	public TPAController() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		String action123 = request.getParameter("AdminLogin");
		System.out.println(action);
		String login = request.getParameter("login");
		// System.out.println(login);
		System.out.println("Hello" + action);
		String pendingRequest = request.getParameter("pendingRequest");
		String submitTheReason = request.getParameter("submitTheReason");
		// System.out.println(pendingRequest);

		String RequestApproval = request.getParameter("RequestApproval");

		String ViewDetails = request.getParameter("ViewDetails");
		String hiid = null;

		// System.out.println(RequestApproval);

		/*
		 * String APPROVE = request.getParameter("APPROVE"); //
		 * System.out.println(APPROVE);
		 * 
		 * String DECLINE = request.getParameter("DECLINE"); //
		 * System.out.println(DECLINE);
		 */

		// Login functionality
		try {

			if ("login".equals(login)) {
				Password = request.getParameter("Password"); // move with
																// objects with
																// the help of
																// bean class
				Userid = request.getParameter("Userid");
				// System.out.println(Password);
				// System.out.println(Userid);

				TPABean tpabean = new TPABean();
				tpabean.setPassword(Password);
				tpabean.setTPAuserid(Userid);

				TPABean value = null;
				HttpSession hs = request.getSession();
				hs.setAttribute("tpaID", tpabean.getTPAuserid());
				TPAService tpas = new TPAService();
				value = tpas.login(tpabean);
				// System.out.println("controller  "+value);
				if (value != null) {
					System.out.println("entered");
					RequestDispatcher reqD = request
							.getRequestDispatcher("AdminHome.jsp");
					reqD.forward(request, response);
				} else {

					PrintWriter out = response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('User or password incorrect');");
					out.println("location='AdminLogin.jsp';");
					out.println("</script>");

					/*
					 * RequestDispatcher reqD =
					 * request.getRequestDispatcher("wrong.html");
					 * //window.alert("error"); reqD.include(request, response);
					 * // we need to proceed with include :
					 */}
			}

			// Pending request functionality

			else if ("pendingRequest".equals(pendingRequest)) {
				HttpSession hs = request.getSession();
				System.out.println("Controller Pending request");

				ArrayList<Beneficiary> value = new ArrayList<Beneficiary>();
				TPAService tpas = new TPAService();
				value = tpas.pendingRequest();
				hs.setAttribute("elist", value);
				if (value != null) {
					RequestDispatcher reqD = request
							.getRequestDispatcher("CheckPendingRequests.jsp");// change
																				// the
																				// name
																				// of
																				// pendingRequest
					reqD.forward(request, response);
				} else {
					RequestDispatcher reqD = request
							.getRequestDispatcher("wrong.html");
					// window.alert("error");
					reqD.forward(request, response);
				}
				/*
				 * String scenario= request.getParameter("scenario");
				 * if(scenario.equals("RequestApproval")){ RequestDispatcher rd=
				 * request.getRequestDispatcher("DisplayEmployeeDetails.jsp");
				 * rd.forward(request, response); } else
				 * if(scenario.equals("RequestDecline")){ RequestDispatcher rd=
				 * request.getRequestDispatcher(""); rd.forward(request,
				 * response); }
				 */

			}

			// //reason

			else if ("Submit".equals(submitTheReason)) {
				// HttpSession hs=request.getSession();
				System.out.println("Controller Pending request");

				TPAService tpas = new TPAService();

				String reason = request.getParameter("ereason");
				System.out.println(health);

				boolean value = tpas.Reason(health, reason);

				if (value != false) {
					RequestDispatcher reqD = request
							.getRequestDispatcher("TPAaction.jsp");// change the
																	// name of
																	// pendingRequest
					reqD.forward(request, response);
				} else {
					RequestDispatcher reqD = request
							.getRequestDispatcher("wrong.html");
					// window.alert("error");
					reqD.forward(request, response);
				}

			}

			// Request approval for employee/dependent functionality

			else if ("RequestApproval".equalsIgnoreCase(RequestApproval)) {
				HttpSession hs = request.getSession();
				System.out.println("RequestApproval");
				boolean value = false;
				TPAService tpas = new TPAService();

				if (request.getParameter("getName").toString()
						.equals("APPROVE")) {
					boolean status = false;
					System.out.println(request.getParameter("getName")
							.toString());
					hiid = request.getParameter("id");
					health = hiid;

					status = tpas.updateApprovalTime(hiid);
					if (status == true)
						System.out.println("approval time has been updated");
					System.out.println(hiid);

					int slaTime = 0;

					try {
						TPAService serviceObject = new TPAService();
						slaTime = serviceObject.fetchDate(hiid);
						System.out.println("slaTime");

						if (slaTime > 48) {
							tc1 obj = new tc1();
							obj.GenerateEscalationReport(hiid);

							RequestDispatcher rd = request
									.getRequestDispatcher("EscalationReport.jsp");
							rd.forward(request, response);
							System.out.println("cannot approve");
						}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					value = tpas.RequestApproval(hiid);
					hs.setAttribute("approvedStatus", value);
					RequestDispatcher rd = request
							.getRequestDispatcher("TPAaction.jsp");
					rd.forward(request, response);

				} else if (request.getParameter("getName").toString()
						.equals("DECLINE")) {
					hiid = request.getParameter("id");
					// TPAService tpas = new TPAService();
					value = tpas.RequestDecline(hiid);
					hs.setAttribute("deletedStatus", value);
					RequestDispatcher rd = request
							.getRequestDispatcher("TPAaction.jsp");
					rd.forward(request, response);
				}

			}
			// Request Declining for employee/dependent functionality
			/*
			 * if ("RequestDecline".equalsIgnoreCase(RequestApproval)) {
			 * HttpSession hs=request.getSession();
			 * System.out.println("RequestDecline"); boolean value=false;
			 * TPAService tpas = new TPAService();
			 * if(request.getParameter("getName").toString().equals("DECLINE"))
			 * { System.out.println(request.getParameter("getName").toString());
			 * String hiid=request.getParameter("id"); System.out.println(hiid);
			 * value=tpas.RequestDecline(hiid);
			 * 
			 * hs.setAttribute("deletedStatus",value); RequestDispatcher rd=
			 * request.getRequestDispatcher("DisplayEmployeeDetails.jsp");
			 * rd.forward(request, response);
			 * 
			 * } }
			 */

			// /

			else if ("ViewDetails".equals(ViewDetails)) {

				HttpSession hs = request.getSession();
				System.out.println("Controller Pending request");

				ArrayList<Beneficiary> value = new ArrayList<Beneficiary>();
				TPAService tpas = new TPAService();
				value = tpas.viewDetailsOfEmployee();
				hs.setAttribute("listPendingRequest", value);
				if (value != null) {
					RequestDispatcher reqD = request
							.getRequestDispatcher("ViewEscalationReport.jsp");// change
																				// the
																				// name
																				// of
																				// pendingRequest
					reqD.forward(request, response);
				} else {
					RequestDispatcher reqD = request
							.getRequestDispatcher("wrong.html");
					// window.alert("error");
					reqD.forward(request, response);
				}
			}

			/*
			 * Password=request.getParameter("Password"); // move with objects
			 * with the help of bean class
			 * Userid=request.getParameter("Userid"); //
			 * System.out.println(Password); // System.out.println(Userid);
			 * 
			 * TPABean tpabean=new TPABean(); tpabean.setPassword(Password);
			 * tpabean.setTPAuserid(Userid);
			 * 
			 * boolean value=false;
			 * 
			 * TPAService tpas = new TPAService(); value=tpas.login(tpabean); //
			 * System.out.println("controller  "+value); if(value==true) {
			 */
			/*
			 * System.out.println(); RequestDispatcher reqD =
			 * request.getRequestDispatcher("ViewDetails.jsp");
			 * reqD.forward(request, response);
			 */
			/*
			 * } else { RequestDispatcher reqD =
			 * request.getRequestDispatcher("wrong.html");
			 * //window.alert("error"); reqD.include(request, response); // we
			 * need to proceed with include : }
			 */

			else if ("AddHospital".equals(action)) {

				Hospital hospital = new Hospital();
				hospital.setHospitalName(request.getParameter("HospitalName"));
				hospital.setAddress(request.getParameter("Address"));
				System.out.println("CITY: " + request.getParameter("CityName"));
				System.out.println("STATE: "
						+ request.getParameter("StateName"));
				hospital.setCityName(request.getParameter("CityName"));
				hospital.setStateName(request.getParameter("StateName"));
				hospital.setPinCode(Integer.parseInt(request
						.getParameter("PinCode")));
				hospital.setSTDCode(Integer.parseInt(request
						.getParameter("STDCode")));
				hospital.setPhoneNumber(Long.parseLong(request
						.getParameter("PhoneNumber")));

				TPAService tPAService = new TPAService();

				String hospital_id = null;
				try {
					hospital_id = tPAService.addHospital(hospital);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				request.setAttribute("hospital_id", hospital_id);
				System.out.println(hospital_id);
				RequestDispatcher reqD = request
						.getRequestDispatcher("AddHospitalResult.jsp");

				reqD.forward(request, response);

			}

			else if (action.equals("ViewHospital")) {
				HttpSession s = request.getSession();
				// String id=hs.getAttribute("empid").toString();
				// int empid=Integer.parseInt(id);
				int HospitalId = 2;
				System.out.println("v1");
				ArrayList<Hospital> hospital = new ArrayList<>();
				TPAService ts = new TPAService();
				System.out.println("v2");
				try {
					hospital = ts.UpdateHospital(HospitalId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("v3");
				s.setAttribute("hospitalList", hospital);
				String scenario = request.getParameter("scenario");
				if (scenario.equals("UpdateHospital")) {
					System.out.println("v4");
					RequestDispatcher rd = request
							.getRequestDispatcher("UpdateHospital.jsp");
					rd.forward(request, response);
					System.out.println("v5");
				} else if (scenario.equals("DeleteHospital")) {
					RequestDispatcher rd = request
							.getRequestDispatcher("DeleteHospital.jsp");
					rd.forward(request, response);
				}
			}

			else if (action.equals("UpdateHospital")) {
				HttpSession s = request.getSession();
				String Hid = request.getParameter("update");
				Hospital hospital = new Hospital();
				TPAService ts = new TPAService();
				try {
					hospital = ts.UpdateHospital(Hid);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				s.setAttribute("UpdateSelectedHospital", hospital);
				RequestDispatcher rd = request
						.getRequestDispatcher("UpdateSelectedHospital.jsp");
				rd.forward(request, response);
			}

			else if (action.equals("DeleteHospital")) {
				HttpSession s = request.getSession();
				String hid = request.getParameter("delete");
				boolean status = false;
				TPAService ts = new TPAService();
				try {
					status = ts.DeleteHospital(hid);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				s.setAttribute("deletedStatus", status);
				RequestDispatcher rd = request
						.getRequestDispatcher("DeleteHospitalResult.jsp");
				rd.forward(request, response);
			}

			else if (action.equals("UpdateSelectedHospital")) {
				System.out.println("1");
				String HospitalName = request.getParameter("HospitalName");
				String Address = request.getParameter("Address");
				String CityName = request.getParameter("CityName");
				String StateName = request.getParameter("StateName");
				int PinCode = (Integer
						.parseInt(request.getParameter("PinCode")));
				int StdCode = (Integer
						.parseInt(request.getParameter("STDCode")));
				long PhoneNumber = (Long.parseLong(request
						.getParameter("PhoneNumber")));

				System.out.println("2");
				HttpSession s = request.getSession();
				String Hid = (String) s.getAttribute("Hid");
				TPAService ts = new TPAService();
				boolean status = false;
				System.out.println("3");
				try {
					status = ts.updateSelectedHospitalDetails(Hid,
							HospitalName, Address, CityName, StateName,
							PinCode, StdCode, PhoneNumber);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("STATUS: " + status);
				s.setAttribute("updatedStatus1", status);
				RequestDispatcher rd = request
						.getRequestDispatcher("UpdateHospitalResult.jsp");
				rd.forward(request, response);
				System.out.println("4");
			} else if ("viewVASForms".equals(action)) {
				// String id=hs.getAttribute("empid").toString();
				// int empid=Integer.parseInt(id);
				// int hiid=1;
				HttpSession hs = request.getSession();
				ArrayList<VAS> b = new ArrayList<>();
				TPAService es = new TPAService();
				b = es.viewVASForms();
				hs.setAttribute("blist1", b);
				String scenario = request.getParameter("scenario");
				System.out.println("Hello");
				if (scenario.equals("ApproveVAS")) {
					RequestDispatcher rd = request
							.getRequestDispatcher("ApproveVASList.jsp");
					rd.forward(request, response);
				} else if (scenario.equals("DeclineVAS")) {
					RequestDispatcher rd = request
							.getRequestDispatcher("DeclineVASList.jsp");
					rd.forward(request, response);
				}
			} else if (action.equals("acceptSelectedVAS")) {
				if (request.getParameter("getName").toString()
						.equals("APPROVE")) {
					String hiid1 = request.getParameter("id_passed");
					String vasID = request.getParameter("id_passed_1");
					TPAService es = new TPAService();
					boolean slaStatus = es.checkVASSLATime(vasID);
					System.out.println(vasID);
					boolean status = false;
					HttpSession hs = request.getSession();
					status = es.acceptSelectedVAS(vasID);
					hs.setAttribute("deletedStatus", status);
					hs.setAttribute("vasID", vasID);
					if (slaStatus == false) {
						RequestDispatcher rd1 = request
								.getRequestDispatcher("Reason.jsp");
						rd1.forward(request, response);
					} else {
						RequestDispatcher rd = request
								.getRequestDispatcher("AdminVASHome.jsp");
						rd.forward(request, response);
					}
				} else if (request.getParameter("getName").toString()
						.equals("DECLINE")) {
					String hiid1 = request.getParameter("id_passed");
					String vasID = request.getParameter("id_passed_1");
					TPAService es = new TPAService();
					boolean slaStatus = es.checkVASSLATime(vasID);
					System.out.println(vasID);
					boolean status = false;
					status = es.declineSelectedVAS(vasID);
					HttpSession hs = request.getSession();
					hs.setAttribute("deletedStatus", status);
					hs.setAttribute("vasID", vasID);
					if (slaStatus == false) {
						RequestDispatcher rd1 = request
								.getRequestDispatcher("Reason.jsp");
						rd1.forward(request, response);
					} else {
						RequestDispatcher rd = request
								.getRequestDispatcher("AdminVASHome.jsp");
						rd.forward(request, response);
					}
				}

			} else if (action.equals("reasonforEscalation")) {
				HttpSession hs = request.getSession();
				String vasID = hs.getAttribute("vasID").toString();
				String esc = request.getParameter("reason");
				TPAService tpas1 = new TPAService();
				boolean b = false;
				b = tpas1.esclateVAS(vasID, esc);
				if (b == true) {
					RequestDispatcher rd = request
							.getRequestDispatcher("AdminVASHome.jsp");
					rd.forward(request, response);
				}
			} else if (action.equals("viewEscalation")) {
				TPAService tpas1 = new TPAService();
				ArrayList<VAS> b = new ArrayList<>();
				b = tpas1.getEscalations();
				HttpSession hs = request.getSession();
				hs.setAttribute("viewEscalation", b);
				RequestDispatcher rd = request
						.getRequestDispatcher("viewVASEscalation.jsp");
				rd.forward(request, response);
			}

			
			
			else if(action.equals("Domiciliary Claim Request")){
				TPAService domiciliaryservice=new TPAService();
				ArrayList<DomiciliaryClaim> listDomiciliaryRequest =new ArrayList<DomiciliaryClaim>();
				listDomiciliaryRequest=domiciliaryservice.viewDomiciliaryRequest();
				request.setAttribute("result", listDomiciliaryRequest);
				ServletContext sc=this.getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryData.jsp");
				rd.forward(request, response);
				
			}
			else if(action.equals("Hospitalization Claim Request")){
				

				TPAService domiciliaryservice=new TPAService();
				ArrayList<HospitalizationClaim> listHospitalizationRequest = new ArrayList<HospitalizationClaim>();
				listHospitalizationRequest=domiciliaryservice.viewHospitalizationRequest();
				request.setAttribute("result", listHospitalizationRequest);
				ServletContext sc=this.getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationData.jsp");
				rd.forward(request, response);
			}
			else if(action.equals("HospitalizationClaimSLATime"))
			{
				TPAService domiciliaryservice=new TPAService();
				boolean flag=false;
				String claim_Id=request.getParameter("claimid");
				flag=domiciliaryservice.hospitalizationClaimSLATime(claim_Id);
		         //System.out.println(claim_Id);
				if(flag==true){
				request.setAttribute("result",claim_Id);
				ServletContext sc=this.getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationClaimApprove.jsp");
				rd.forward(request, response);
				}
				else{
					request.setAttribute("result",claim_Id);
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationClaimEsclate.jsp");
					rd.forward(request, response);
				}
			}
				else if(action.equals("DomiciliaryClaimSLATime"))
				{
					TPAService domiciliaryservice=new TPAService();
					boolean flag=false;
					String claim_Id=request.getParameter("claimid");
					
					flag=domiciliaryservice.DomiciliaryClaimSLATime(claim_Id);
					 if(flag==true){
					request.setAttribute("result",claim_Id);
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryClaimApprove.jsp");
					rd.forward(request, response);
					}
					else{
						request.setAttribute("result",claim_Id);
						ServletContext sc=this.getServletContext();
						RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryClaimEsclate.jsp");
						rd.forward(request, response);
					}
			
			}
				else if(action.equals("DomiciliaryClaimApproval"))
				{
					TPAService domiciliaryservice=new TPAService();
					String claim_Id=request.getParameter("claimid");
					String status=request.getParameter("claimstatus");
					double approved_Amount=Double.parseDouble(request.getParameter("approvedamount"));
					String claim_Esclate=request.getParameter("claimesclation");
					String claim_Action=request.getParameter("claimaction");
					boolean flag=domiciliaryservice.approveDomiciliaryClaim(claim_Id, approved_Amount, status, claim_Esclate,claim_Action);
					if(flag==true){
						ServletContext sc=this.getServletContext();
						RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliarySuccess.jsp");
						rd.forward(request, response);
					}
					else{
						
						ServletContext sc=this.getServletContext();
						RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryFailure.jsp");
						rd.forward(request, response);
					}
				}
			else if(action.equals("HospitalizationClaimApproval"))
			{
				
				TPAService domiciliaryservice=new TPAService();
				String claim_Id=request.getParameter("claimid");
				String status=request.getParameter("claimstatus");
				double approved_Amount=Double.parseDouble(request.getParameter("approvedamount"));
				String claim_Esclate=request.getParameter("claimesclation");
				String claim_Action=request.getParameter("claimaction");
				boolean flag=domiciliaryservice.approveHospitalizationClaim(claim_Id, approved_Amount, status, claim_Esclate,claim_Action);
				if(flag==true){
					
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationSuccess.jsp");
					rd.forward(request, response);
				}
				else{
					
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationFailure.jsp");
					rd.forward(request, response);
				}
			}
			else if(action.equals("DomiciliaryClaimEsclation"))
			{
				TPAService domiciliaryservice=new TPAService();
				String claim_Id=request.getParameter("claimid");
				String claim_Status=request.getParameter("claimstatus");
				double approved_Amount=Double.parseDouble(request.getParameter("approvedamount"));
				String claim_Action=request.getParameter("claimaction");
				String claim_esclate=request.getParameter("claimesclate");
				
				boolean flag=domiciliaryservice.esclateDomiciliaryClaim(claim_Id, claim_esclate,approved_Amount,claim_Status,claim_Action);
				
				if(flag==true){
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryEsclateSuccess.jsp");
					rd.forward(request, response);
				}
				else{
					
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryEsclateFailure.jsp");
					rd.forward(request, response);
				}
				
			}
			
			else if(action.equals("HospitalizationClaimEsclation"))
			{
				TPAService domiciliaryservice=new TPAService();
				String claim_Id=request.getParameter("claimid");
				String claim_esclate=request.getParameter("claimesclate");
				double approved_Amount=Double.parseDouble(request.getParameter("approvedamount"));
				String claim_Action=request.getParameter("claimaction");
				String claimStatus=request.getParameter("claimstatus");
				System.out.println(claimStatus);
				boolean flag=domiciliaryservice.esclateHospitalizationClaim(claim_Id, claim_esclate,approved_Amount,claimStatus,claim_Action);
				
				if(flag==true){
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationEsclateSuccess.jsp");
					rd.forward(request, response);
				}
				else{
					
					ServletContext sc=this.getServletContext();
					RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationEsclateFailure.jsp");
					rd.forward(request, response);
				}
				
			}
			else if(action.equals("DomiciliaryClaimDocument"))
			{
				TPAService domiciliaryservice=new TPAService();
				String claim_Id=request.getParameter("claimid");
				String arr[]=domiciliaryservice.DomicilaryClaimDocument(claim_Id);
				request.setAttribute("result",claim_Id);
				request.setAttribute("path",arr);
				
				ServletContext sc=this.getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher("/DomiciliaryClaimDocument.jsp");
				
				//out.print(path);
			
				//out.print("<a href="+path+">view</a>");
				rd.include(request,response);
				
			}
			else if(action.equals("HospitalizationClaimDocument"))
			{
				TPAService domiciliaryservice=new TPAService();
				String claim_Id=request.getParameter("claimid");
				String arr[]=domiciliaryservice.HospitalizationClaimDocument(claim_Id);
				request.setAttribute("result",claim_Id);
				request.setAttribute("path",arr);
				ServletContext sc=this.getServletContext();
				RequestDispatcher rd=sc.getRequestDispatcher("/HospitalizationClaimDocument.jsp");
				//out.print(path);
		
				//out.print("<a href="+path+">view</a>");
				rd.include(request,response);
			}
		
			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void errorMessage(String string) {
		// TODO Auto-generated method stub
		System.out.println(string);
	}
}
