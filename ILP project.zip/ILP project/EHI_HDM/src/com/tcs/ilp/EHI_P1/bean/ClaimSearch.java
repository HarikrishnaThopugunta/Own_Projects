package com.tcs.ilp.EHI_P1.bean;

import java.util.Date;

public class ClaimSearch {

	private String claimType;
	private String policyYear;
	private String relationship;
	private String hid;
	private String mediAssistClaimNo;
	private Date claimRaisedOn;
	private String patientName;
	private String relation;
	private double claimAmount;
	private double approvedAmount;
	private String claimStatus;
	private String action;
	private String Escalation_Report;
	
	public String getClaimType() {
		return claimType;
	}
	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}
	public String getPolicyYear() {
		return policyYear;
	}
	public void setPolicyYear(String policyYear) {
		this.policyYear = policyYear;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getHid() {
		return hid;
	}
	public void setHid(String hid) {
		this.hid = hid;
	}
	public String getMediAssistClaimNo() {
		return mediAssistClaimNo;
	}
	public void setMediAssistClaimNo(String mediAssistClaimNo) {
		this.mediAssistClaimNo = mediAssistClaimNo;
	}
	public Date getClaimRaisedOn() {
		return claimRaisedOn;
	}
	public void setClaimRaisedOn(Date claimRaisedOn) {
		this.claimRaisedOn = claimRaisedOn;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public double getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(double claimAmount) {
		this.claimAmount = claimAmount;
	}
	public double getApprovedAmount() {
		return approvedAmount;
	}
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}
	public String getClaimStatus() {
		return claimStatus;
	}
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getEscalation_Report() {
		return Escalation_Report;
	}
	public void setEscalation_Report(String Escalation_Report) {
		this.Escalation_Report = Escalation_Report;
	}	

}
