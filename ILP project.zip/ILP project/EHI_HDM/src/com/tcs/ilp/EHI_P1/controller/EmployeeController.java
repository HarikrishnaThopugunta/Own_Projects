package com.tcs.ilp.EHI_P1.controller;

import java.io.PrintWriter;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tcs.ilp.EHI_P1.bean.Bean;
import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.ClaimSearch;
import com.tcs.ilp.EHI_P1.bean.Employee;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.bean.ValueAddedService;
import com.tcs.ilp.EHI_P1.service.EmployeeService;
import com.tcs.ilp.EHI_P1.service.TPAService;

import java.io.*;


/**
 * Servlet implementation class EmployeeController
 */
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIRECTORY = "C:/uploads";
	/**
	 * Default constructor.
	 */
	public EmployeeController() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Entered Employee Controlled Servelet");
		try {
			String action = request.getParameter("action");

			//String action=request.getParameter("action");
			System.out.println("User action received:"+action);

			
			if("hospitalization".equals(action))
			{
				//String action = request.getParameter("action");
				System.out.println("hiii its above iff = "+request.getParameter("name"));
				if(request.getParameter("name")!=null)
				{
					System.out.println("1");
					PrintWriter pr;
					try {
						pr = response.getWriter();
						response.setContentType("text/xml");
						response.setCharacterEncoding("UTF-8");
						System.out.println("hiii1");
						EmployeeService service = new EmployeeService();
						Bean bean = new Bean();
						System.out.println("hiii2");

						String name = request.getParameter("name");
						System.out.println("hiii3" +name);
						request.setAttribute("name", name);
						HttpSession hs=request.getSession();
						Integer empid = Integer.parseInt(hs.getAttribute("Empid").toString());
						System.out.println("Session empid hos = "+empid);
						bean = service.hospitalizationSearchBeneficiary(empid, name);
						if(bean!=null)
						{System.out.println("2");
						pr.write("<beneficiary>");
						pr.write("<gender>"+bean.getGender()+"</gender>");
						pr.write("<relationship>"+bean.getRelation()+"</relationship>");
						pr.write("<age>"+bean.getAge()+"</age>");
						pr.write("<hiid>"+bean.getHealthinsuranceid()+"</hiid>");
						pr.write("</beneficiary>"); 
						System.out.println("3");
						}
						System.out.println("in controller bean "+ bean.getHealthinsuranceid());

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
				else if(request.getParameter("stateId")!=null)
				{
					PrintWriter pr;
					try {
						pr = response.getWriter();
						String stateId = request.getParameter("stateId");
						System.out.println("StateId = "+stateId);
						EmployeeService service = new EmployeeService();
						ArrayList<String> cities = new ArrayList<String>();
						cities = service.searchCityByState(stateId);
						pr.write("<city>");	
						pr.write("<cityName>Select</cityName>");
						for(String city:cities)
						{
							System.out.println("xml= "+city);

							
							pr.write("<cityName>"+city+"</cityName>");

						}

						pr.write("</city>");
						pr.flush();

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else if(request.getParameter("state")!=null&&request.getParameter("city")!=null)
				{
					PrintWriter pr;
					try {
						pr = response.getWriter();
						String state = request.getParameter("state");
						String city = request.getParameter("city");
						System.out.println("State = "+state+" "+city);
						EmployeeService service = new EmployeeService();
						HashMap<String,String> hospitals = new HashMap<String,String>();
						hospitals = service.searchHospitalByCity(city, state);
						pr.write("<hospital>");	
						pr.write("<hospitalName>Select</hospitalName>");
						pr.write("<hospitalId>Select</hospitalId>");
						for(String hospital:hospitals.keySet())
						{
							System.out.println("xml= "+hospital);

							//pr.write("<ID>"+(i++) +"</ID>");
							pr.write("<hospitalName>"+hospitals.get(hospital)+"</hospitalName>");
							pr.write("<hospitalId>"+hospital+"</hospitalId>");

						}

						pr.write("</hospital>");
						pr.flush();

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else{
					try{
						
						EmployeeService service = new EmployeeService();
						Bean bean = new Bean();
						HashMap<String,String> states = new HashMap<String,String>();
						HttpSession hs=request.getSession();
						Integer empid = Integer.parseInt(hs.getAttribute("Empid").toString());
						System.out.println("Session empid hos = "+empid);
						bean = service.hospitalizationSearchEmployee(empid);
						states = service.searchState();
						System.out.print("Here is bean "+bean.getEmployeeName());
						request.setAttribute("bean", bean);
						request.setAttribute("states", states);

						System.out.println("b");
						RequestDispatcher rd = request.getRequestDispatcher("HospitalizeClaim.jsp");
						System.out.println("a");

						rd.forward(request, response);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Exception occured");

					}

				}
			}

			else if("domiciliary".equals(action)){
				System.out.print("Domiciliary form");
				//String action = request.getParameter("action");
				//HttpSession session =request.getSession();
				System.out.println("hiii its above iff");
				PrintWriter pr;
	             System.out.println("name = "+request.getParameter("id"));
				if(request.getParameter("name")!=null)
				{
					try {
						pr = response.getWriter();
						
						System.out.println("hiii1");
						EmployeeService service = new EmployeeService();
						Bean bean = new Bean();
						System.out.println("hiii2");
						String name = request.getParameter("name");
						System.out.println("hiii3" +name);
						HttpSession hs=request.getSession();
						Integer empid = Integer.parseInt(hs.getAttribute("Empid").toString());
						System.out.println("Session empid hos = "+empid);
						bean = service.domiciliarySearchBeneficiary(empid, name);
						request.setAttribute("bean1", bean);
						if(bean!=null)
						{System.out.println("2");
						pr.write("<beneficiary>");
						pr.write("<hiid>"+bean.getHealthinsuranceid()+"</hiid>");
						pr.write("<mobile>"+bean.getMobileNo()+"</mobile>");
						pr.write("</beneficiary>"); 
						System.out.println("3");
						}
					}

					catch(Exception e)
					{
						e.printStackTrace();

					}
				}

				else{
					EmployeeService service = new EmployeeService();
					Bean bean = new Bean();
					HttpSession hs=request.getSession();
					Integer empid = Integer.parseInt(hs.getAttribute("Empid").toString());
					System.out.println("Session empid hos = "+empid);
					bean = service.domiciliarySearchEmployee(empid);
					System.out.print("Here is bean "+bean.getEmployeeId());

					//	String beanId = UUID.randomUUID().toString();
					//	session.setAttribute("id", bean);
					request.setAttribute("bean", bean);
					RequestDispatcher rd = request.getRequestDispatcher("DomiciliaryClaim.jsp");
					try {
						rd.forward(request, response);
					} catch (ServletException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
				
				if ("searchclaim".equals(action)) {

					String hid = request.getParameter("hid");
					String claimType = request.getParameter("claimType");
					String policyYear = request.getParameter("policyYear");
					String relation = request.getParameter("relationship");

					if ((hid != "")) {

						EmployeeService cs = new EmployeeService();
						ArrayList<ClaimSearch> clist = cs.search(hid);
						request.setAttribute("clist", clist);
						RequestDispatcher rdis = request
								.getRequestDispatcher("viewList.jsp");
						rdis.forward(request, response);
						System.out.println(hid);
					} else {

						EmployeeService cs = new EmployeeService();
						ArrayList<ClaimSearch> clist = cs.search(claimType, policyYear,
								relation);
						request.setAttribute("clist", clist);
						RequestDispatcher rdis = request
								.getRequestDispatcher("viewList.jsp");
						rdis.forward(request, response);
					}
				}
				if ("searchforclaim".equals(action)){
					RequestDispatcher rdis = request
							.getRequestDispatcher("ClaimSearch.jsp");
					rdis.forward(request, response);
					
				}
			
		
			// TODO Auto-generated method stub
			
			
			// TODO Auto-generated method stub
			
			
			
		
			// ////// START OF AUTO-GENERATION FOR 'c'
			if (request.getParameter("name") != null) {
				if (request.getParameter("name").equalsIgnoreCase("self")) {
					System.out.println("5");
					PrintWriter pr;
					try {
						pr = response.getWriter();
						response.setContentType("text/xml");
						response.setCharacterEncoding("UTF-8");
						EmployeeService service = new EmployeeService();
						Beneficiary beneficiary = new Beneficiary();
						HttpSession hs=request.getSession();
						int empid=Integer.parseInt(hs.getAttribute("Empid").toString());
						beneficiary = service.searchDependent(empid);
						if (beneficiary != null) {
							pr.write(beneficiary.getHealthInsuranceId());
						}
						System.out.println("in controller bean "
								+ beneficiary.getHealthInsuranceId());

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						System.out.println("Excep occrd");
					}
				} else if (request.getParameter("name").equalsIgnoreCase(
						"dependent")) {
					EmployeeService service = new EmployeeService();
					Beneficiary beneficiary = new Beneficiary();
					// String namebeneficiary[]=new String[10];
					String name = request.getParameter("name");
					ArrayList<String> namebeneficiary = new ArrayList<String>();
					System.out.println(name);
					response.setContentType("text/html");
					PrintWriter pr = response.getWriter();
					// int
					// empId=Integer.parseInt(request.getParameter("employeeid"));
					HttpSession hs=request.getSession();
					int empid=Integer.parseInt(hs.getAttribute("Empid").toString());
					namebeneficiary = service.searchDependentName(empid);
					pr.write("<option value=\"--select--\">---select bname----</option>");
					for (int i = 0; i < namebeneficiary.size(); i++) {
						System.out.println(namebeneficiary);
						pr.write("<option value=\"" + namebeneficiary.get(i)
								+ "\">" + namebeneficiary.get(i) + "</option>");
					}
					System.out.println("in controller bean 1 "
							+ beneficiary.getHealthInsuranceId());
				}

			} else if (request.getParameter("dependentName") != null) {
				String dependentName = request.getParameter("dependentName");
				System.out.println(dependentName);
				response.setContentType("text/html");
				PrintWriter pr = response.getWriter();
				EmployeeService service = new EmployeeService();
				Beneficiary beneficiary = new Beneficiary();
				HttpSession hs=request.getSession();
				int empid=Integer.parseInt(hs.getAttribute("Empid").toString());
				beneficiary = service.searchDependent(empid, dependentName);
				if (beneficiary != null) {
					pr.write(beneficiary.getHealthInsuranceId());
				}
				System.out.println("in controller bean 2 "
						+ beneficiary.getHealthInsuranceId());
			}

			else if (request.getParameter("stname") != null) {
				String name = request.getParameter("name");
				System.out.println(name);
				response.setContentType("text/html");
				PrintWriter pr = response.getWriter();
				EmployeeService service = new EmployeeService();
				ArrayList<String> stlist = new ArrayList<String>();
				stlist = service.getStates();
				if(stlist.size()==0){
					pr.write(" <p>No cities found.</p>");
				}
				else{
				pr.write(" <p><select  name=\"StateName\" id=\"stateList\" onchange=\"stCHVal()\" style=\"color: #000000;float: left;font-size:20px\" class=\"select\">");
				pr.write("<option value=\"--select--\">---select state----</option>");
				for (int i = 0; i < stlist.size(); i++) {

					pr.write("<option value=\"" + stlist.get(i) + "\">"
							+ stlist.get(i) + "</option>");
				}
				pr.write("</select></p>");
				}
			}

			else if (request.getParameter("STforCT") != null
					&& request.getParameter("CTforHP") == null) {
				String stname = request.getParameter("STforCT");
				System.out.println(stname);
				response.setContentType("text/html");
				PrintWriter pr = response.getWriter();
				EmployeeService service = new EmployeeService();
				ArrayList<String> ctlist = new ArrayList<String>();
				ctlist = service.getCities(stname);
				if(ctlist.size()==0){
					pr.write(" <p>No cities found.</p>");
				}
				else{
					pr.write(" <p><select  name=\"CityName\" id=\"cityList\" onchange=\"ctCHVal()\" style=\"color: #000000;float: left;font-size:20px\" class=\"select\">");
					pr.write("<option value=\"--select--\">---select city----</option>");
					for (int i = 0; i < ctlist.size(); i++) {

						pr.write("<option value=\"" + ctlist.get(i) + "\">"
								+ ctlist.get(i) + "</option>");
					}
					pr.write("</select></p>");
				}
				
			}

			else if (request.getParameter("STforCT") != null
					&& request.getParameter("CTforHP") != null) {
				String stname = request.getParameter("STforCT");
				String ctname = request.getParameter("CTforHP");
				System.out.println(stname);
				System.out.println(ctname);
				response.setContentType("text/html");
				PrintWriter pr = response.getWriter();
				EmployeeService service = new EmployeeService();
				ArrayList<String> hplist = new ArrayList<String>();
				hplist = service.getHospitals(stname, ctname);
				if (hplist != null) {
					pr.write(" <p><select  name=\"hospitalList\" id=\"hospitalList\" style=\"color: #000000;float: left;\" class=\"select\">");
					pr.write("<option value=\"--select--\">---select hospital----</option>");
					for (int i = 0; i < hplist.size(); i++) {

						pr.write("<option value=\"" + hplist.get(i) + "\">"
								+ hplist.get(i) + "</option>");
					}
					pr.write("</select></p>");
				} else {
					pr.write("no match");
				}
			} else if (request.getParameter("hosname") != null) {
				String hospitalname = request.getParameter("hosname");
				System.out.println(hospitalname);
				response.setContentType("text/html");
				PrintWriter pr = response.getWriter();
				System.out.println("in hospital name");
				EmployeeService service = new EmployeeService();
				ArrayList<String> hospitalList = new ArrayList<String>();
				hospitalList = service.getSearchHospital(hospitalname);
				pr.write(" <p><select  name=\"hospitalList\" id=\"hospitalList\" style=\"color: #000000;float: left;font-size:30px\" class=\"select\">");
				pr.write("<option value=\"--select--\">---select hospitalName----</option>");
				for (int i = 0; i < hospitalList.size(); i++) {

					pr.write("<option value=\"" + hospitalList.get(i) + "\">"
							+ hospitalList.get(i) + "</option>");
				}
				pr.write("</select></p>");
			}

			// ////// END OF AUTO-GENERATION  FOR 'c'

			HttpSession hs=request.getSession();

			
			//// START OF TEAM A
			
			if ("login".equals(action)) 
			{
				String Userid=request.getParameter("Userid");
				String Password=request.getParameter("Password"); // move with objects with the help of bean class 

				//empId=Long.parseLong(Userid);
				Employee empbean=new Employee(); 
				empbean.setPassword(Password);
				empbean.setEmployeeId(Long.parseLong(Userid));
				Employee e= new Employee();
				EmployeeService empser=new EmployeeService();
				try {
					e=empser.loginEmployee(empbean);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if(e!=null )
				{
					System.out.println(e.getEmployeeName());
					hs.setAttribute("Empid",Long.parseLong(Userid));
					hs.setAttribute("Emp", e);
					RequestDispatcher reqDis=request.getRequestDispatcher("EmployeeHome.jsp");
					reqDis.forward(request,response);
				}
				else
				{
					PrintWriter out=response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('User or password incorrect or your HIID has not approved yet.');");
					out.println("location='EmployeeLogin.jsp';");
					out.println("</script>");

				}

			}
			if(action.equals("viewBeneficiaries")){

				long empid= (Long) hs.getAttribute("Empid");//creating session for empid
				ArrayList<Beneficiary> b = new ArrayList<Beneficiary>();
				EmployeeService es=new EmployeeService();
				b=es.viewBeneficiaries(empid);
				hs.setAttribute("blist", b);
				String scenario= request.getParameter("scenario");
				if(scenario.equals("updateBeneficiary")){
					RequestDispatcher rd= request.getRequestDispatcher("UpdateDependent.jsp");
					rd.forward(request, response);
				}
				else if(scenario.equals("deleteBeneficiary")){
					RequestDispatcher rd= request.getRequestDispatcher("DeleteDependent.jsp");
					rd.forward(request, response);
				}
				else if(scenario.equals("viewBeneficiary")){
					System.out.println(action + scenario);
					RequestDispatcher rd= request.getRequestDispatcher("ViewBeneficiaryDetails.jsp");
					rd.forward(request, response);
				}
				

				else if(scenario.equals("addBeneficiary")){
					
					String BenName=request.getParameter("name");
					String Relation=request.getParameter("rel");
					String gender=request.getParameter("gen");
					String DOB=request.getParameter("db");
					String psd=request.getParameter("policy");
					String polperiod=request.getParameter("period");
					String totsum=request.getParameter("sum");

					Beneficiary b1=new Beneficiary();


					b1.setDateOfBirth(DOB);
					b1.setPolicyStartDate(psd);
					System.out.println(DOB);
					b1.setEmployeeId(empid);
					b1.setBeneficiaryName(BenName);
					b1.setRelation(Relation);
					b1.setGender(gender);
					int p=Integer.parseInt(polperiod);
					b1.setPolicyPeriod(p);
					b1.setTotalSumInsured(Long.parseLong(totsum));
					String Hid="";

					try {
						EmployeeService es1=new EmployeeService();
						Hid=es1.createBeneficiary(b1);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					request.setAttribute("HIid",Hid);//as of now not using any where
					PrintWriter out=response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Beneficiary Registered Successfully, your Beneficiary HI-ID is ("+Hid+") ');");
					out.println("location='DependentProfile.jsp';");
					out.println("</script>");
					
				}
			}
			if(action.equals("updateSelectedBeneficiary")){
				String hiid=request.getParameter("id_passed");
				Beneficiary b = new Beneficiary();
				EmployeeService es=new EmployeeService();
				b=es.updateSelectedBeneficiary(hiid);
				hs.setAttribute("selectedBenificiary", b);
				RequestDispatcher rd= request.getRequestDispatcher("SelectedBeneficiary.jsp");
				rd.forward(request, response);
			}
			if(action.equals("view"))//viewing details
			{

				RequestDispatcher rd= request.getRequestDispatcher("EmployeeProfile.jsp");
				rd.forward(request, response);
			}
			if(action.equals("Beneficiaryview"))//viewing details
			{

				RequestDispatcher rd= request.getRequestDispatcher("DependentProfile.jsp");
				rd.forward(request, response);
			}
			if(action.equals("deleteSelectedBeneficiary")){
				String hiid=request.getParameter("id_passed");
				boolean status=false;
				EmployeeService es=new EmployeeService();
				status=es.deleteSelectedBeneficiary(hiid);
				hs.setAttribute("deletedStatus", status);
				PrintWriter out=response.getWriter();
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Beneficiary Deleted ');");
				out.println("location='DependentProfile.jsp';");
				out.println("</script>");
			}
			if(action.equals("updateSelectedBeneficiaryDetails")){
				System.out.println("hello selected update benenficiar6y ");
				String DateOfBirth=request.getParameter("DateOfBirth");
				String PolicyPeriod=request.getParameter("PolicyPeriod");
				String HIid=(String) hs.getAttribute("hiid");
				Beneficiary b1=new Beneficiary();
				b1.setHealthInsuranceId(HIid);
				b1.setDateOfBirth(DateOfBirth);
				b1.setPolicyNo(Integer.parseInt(PolicyPeriod));
				EmployeeService es=new EmployeeService();
				boolean status=false;
				status=es.updateSelectedBeneficiaryDetails(b1);
				PrintWriter out=response.getWriter();
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Selected Beneficiary Details Updated');");
				out.println("location='DependentProfile.jsp';");
				out.println("</script>");
			}

			/*empid name password DOB gender email altemail mobilenum altmobilenum policydate policyperiod suminsured bankacc bankname ifsc*/
			if(action.equals("RegisterEmployee"))
			{
				long empid=Long.parseLong(request.getParameter("empid"));
				String name=request.getParameter("name");
				String password=request.getParameter("password");
				String dob=request.getParameter("DOB");
				String gender=request.getParameter("gender");
				String email=request.getParameter("email");
				String altemail=request.getParameter("altemail");
				String address=request.getParameter("address");
				long mobilenum=Long.parseLong(request.getParameter("mobilenum"));
				long altmobilenum=Long.parseLong(request.getParameter("altmobilenum"));
				String policydate=request.getParameter("policydate");
				int policyperiod= Integer.parseInt(request.getParameter("policyperiod"));
				double suminsured=Double.parseDouble(request.getParameter("suminsured"));
				Long bankacc=Long.parseLong(request.getParameter("bankacc"));
				String bankname=request.getParameter("bankname");
				String ifsc=request.getParameter("ifsc");
				Employee employee=new Employee();
				employee.setEmployeeId(empid);
				employee.setEmployeeName(name);
				employee.setPassword(password);
				employee.setEmail(email);
				employee.setAlternateEmail(altemail);
				employee.setAddress(address);
				employee.setPhoneNumber(mobilenum);
				employee.setAlternateMobileNo(altmobilenum);
				employee.setBankAccountNo(bankacc);
				employee.setNameOfBank(bankname);
				employee.setIFSCCode(ifsc);

				Beneficiary beneficiary=new Beneficiary();
				beneficiary.setDateOfBirth(dob);
				beneficiary.setGender(gender);
				beneficiary.setPolicyStartDate(policydate);
				beneficiary.setPolicyPeriod(policyperiod);
				beneficiary.setTotalSumInsured(suminsured);
				beneficiary.setBeneficiaryName(name);
				beneficiary.setRelation("SELF");
				beneficiary.setEmployeeId(empid);
				beneficiary.setStatus("PENDING");



				EmployeeService es=new EmployeeService();
				String HIID=es.addEmployee(employee, beneficiary);
				PrintWriter out=response.getWriter();
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Registered Successfully, your HI-ID is ("+HIID+") ,Once your HIID is Approved ,U can login');");
				out.println("location='EmployeeLogin.jsp';");

				out.println("</script>");

			}
			if(action.equals("ViewEmployee"))
			{	System.out.println("hello");
				long empid= (Long) hs.getAttribute("Empid");

				HashMap<String,Object> map=new HashMap<String,Object>();
				//hs.setAttribute("blist", map);
				EmployeeService es= new EmployeeService();
				map= es.viewEmployee(empid);
				hs.setAttribute("mapObjects", map);
				RequestDispatcher rd= request.getRequestDispatcher("ViewEmployeeResult.jsp");
				rd.forward(request, response);
			}
			if("deletionEmployee".equals(action))
			{
				long empid= (Long) hs.getAttribute("Empid");
				EmployeeService ES= new EmployeeService();

				boolean flag= ES.deleteEmployee(empid);
				System.out.println(flag);
				if(flag==true)
				{
					PrintWriter out=response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Employee Deleted ');");
					out.println("location='EmployeeLogin.jsp';");
					out.println("</script>");
					
				}			
			}

			if("UpdateEmployee".equals(action)){//add service
				
				long empid= (Long) hs.getAttribute("Empid");
				HashMap<String,Object> map=new HashMap<String,Object>();
				EmployeeService ES= new EmployeeService();
				map = ES.viewEmployee(empid);
				request.setAttribute("mapObjects", map);
				RequestDispatcher rd = request.getRequestDispatcher("UpdateEmployee.jsp");
				rd.forward(request, response);
			}
			if("finalUpdation".equals(action))
			{
				/* password DOB address email altemail mobilenum altmobilenum policyperiod totalSumInsured bankAccountNo nameOfBank IFSCCode*/
				long empid= (Long) hs.getAttribute("Empid");
				
				String password=request.getParameter("password");
				String dob=request.getParameter("DOB");
				String address=request.getParameter("address");
				String email=request.getParameter("email");
				String altemail=request.getParameter("altemail");			
				long mobilenum= Long.parseLong(request.getParameter("mobilenum"));
				long altmobilenum= Long.parseLong(request.getParameter("altmobilenum"));
				int policyperiod=Integer.parseInt(request.getParameter("policyperiod"));
				double totalSumInsured=Double.parseDouble(request.getParameter("totalSumInsured"));
				long bankAccountNo= Long.parseLong(request.getParameter("bankAccountNo"));
				String nameOfBank=request.getParameter("nameOfBank");
				String IFSCCode=request.getParameter("IFSCCode");

				Employee employee= new Employee();
				employee.setEmail(email);
				employee.setAlternateEmail(altemail);
				employee.setPassword(password);
				employee.setPhoneNumber(mobilenum);
				employee.setAlternateMobileNo(altmobilenum);			
				employee.setBankAccountNo(bankAccountNo);
				employee.setNameOfBank(nameOfBank);
				employee.setIFSCCode(IFSCCode);
				employee.setAddress(address);
				employee.setEmployeeId(empid);


				Beneficiary beneficiary = new Beneficiary();
				beneficiary.setEmployeeId(empid);
				beneficiary.setDateOfBirth(dob);
				beneficiary.setPolicyPeriod(policyperiod);
				beneficiary.setTotalSumInsured(totalSumInsured);

				EmployeeService es=new EmployeeService();
				boolean isupdated=es.updateEmployee(employee, beneficiary);
				int count=1;
				//PrintWriter out=response.getWriter();
				if(isupdated==true)
				{
					PrintWriter out=response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Employee Details Updated ');");
					out.println("location='EmployeeProfile.jsp';");
					out.println("</script>");
					
				}
				else
				{		hs.setAttribute("update",count);//to show alert message
				RequestDispatcher rd = request.getRequestDispatcher("UpdateEmployee.jsp");
				rd.forward(request, response);
				}

			}
			
			if ("GenerateECard".equals(action)) 
			{
				
				System.out.println("hello i am the controller for generate ecard");
				long empid= Long.parseLong(hs.getAttribute("Empid").toString());
				
				System.out.println(empid);
				ArrayList<Beneficiary> ecard = new ArrayList<Beneficiary>();

				TPAService tpas = new TPAService();
				try {
					ecard=tpas.GenerateECard(empid);
					System.out.println("EcardTest");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				hs.setAttribute("gecard",ecard);


				if(ecard!=null)
				{
					System.out.println("Ecard Function");

					RequestDispatcher rd = request.getRequestDispatcher("Generate_E-Card.jsp");
					rd.forward(request, response);
					
				}
				
			}



			if ("GenerateECarddetails".equals(action)) 
			{
				System.out.println("controller for ecard details");
				String id = request.getParameter("hid");
				System.out.println("hid="+id);



				String empId = request.getParameter("empId");


				System.out.println("here id"+empId);
				Beneficiary ecard = new Beneficiary();


				ecard.setEmployeeId(Long.parseLong(empId));

				ecard.setHealthInsuranceId(id);
				TPAService tpas = new TPAService();
				//	HttpSession hs=request.getSession();


				hs.setAttribute("gencard",ecard);


				if(ecard!=null)
				{
					RequestDispatcher rd = request.getRequestDispatcher("Generate_E-Card_Dependent_result.jsp");
					rd.forward(request, response);
					
				}
			}
			
			if(action.equals("PayPremium"))
			{
				long empid= Long.parseLong(hs.getAttribute("Empid").toString());//creating session for empid
				ArrayList<Beneficiary> b = new ArrayList<Beneficiary>();
				EmployeeService es=new EmployeeService();
				b=es.viewDetailsByEmpid(empid);
				hs.setAttribute("plist", b);
				RequestDispatcher rd= request.getRequestDispatcher("PayPremium.jsp");
				rd.forward(request, response);			
			}

			if(action.equals("PayPremiumResult")){
				String hiid=request.getParameter("id_passed");
				Beneficiary b = new Beneficiary();
				EmployeeService es=new EmployeeService();
				b=es.payPremiumSelectedBeneficiary(hiid);
				hs.setAttribute("selectedPremiumBenificiary", b);
				RequestDispatcher rd= request.getRequestDispatcher("PayPremiumResult.jsp");
				rd.forward(request, response);
			}
			if("PayPremiumFinal".equals(action)){
				RequestDispatcher rd= request.getRequestDispatcher("PayPremiumGateWay.jsp");
				rd.forward(request, response);
			}
		//// END OF TEAM A
			
			
			
		//// START OF TEAM C
			/*
			 * SEARCH HOSPITAL
			 */
			if ("searchHospital".equals(action)) {
				System.out.println("hello1");

				String searchHospitalByName = request
						.getParameter("hospitalList");
				String searchHospitalByState = request
						.getParameter("StateName");
				String searchHospitalByCity = request.getParameter("CityName");
				System.out.println(searchHospitalByState + "::"
						+ searchHospitalByCity);
				System.out.println("hello2");
				EmployeeService emp = new EmployeeService();
				System.out.println("hello3");

				if (searchHospitalByName != null) {
					System.out.println("hello1");
					ArrayList<Hospital> searchByName = emp
							.searchHospital(searchHospitalByName);
					System.out.println("by name in control");
					request.setAttribute("HospitalID", searchByName);
					System.out.println("In search by name in controller");

					request.getRequestDispatcher("SearchHospitalDetails.jsp")
							.forward(request, response);
				}

				else if (request.getParameter("searchPincode") != "") {
					int searchHospitalByPincode = Integer.parseInt(request
							.getParameter("searchPincode"));
					System.out.println(searchHospitalByPincode);
					ArrayList<Hospital> searchByPincode = emp
							.searchHospital(searchHospitalByPincode);
					request.setAttribute("HospitalID", searchByPincode);
					System.out.println("In search by pincode in controller");
					request.getRequestDispatcher("SearchHospitalDetails.jsp")
							.forward(request, response);
				}

				else if (searchHospitalByState != ""
						&& searchHospitalByCity != "") {
					System.out.println("renu");
					ArrayList<Hospital> searchByState = emp.searchHospitalCity(
							searchHospitalByState, searchHospitalByCity);
					request.setAttribute("HospitalID", searchByState);
					System.out.println("In search by city in controller");
					request.getRequestDispatcher("SearchHospitalDetails.jsp")
							.forward(request, response);
				}

			} else if ("searchNetworkHospital".equals(action)) {
				EmployeeService emp = new EmployeeService();
				ArrayList<Hospital> searchByNetHospital = emp
						.searchNetHospital();
				request.setAttribute("HospitalID", searchByNetHospital);
				System.out.println("In search by net in controller");
				request.getRequestDispatcher("SearchNetworkHospitals.jsp")
						.forward(request, response);
			} 

			/*
			 * VALUE ADDED SERVICES
			 */
			else if ("VAS".equals(action)) {
				ValueAddedService vas = new ValueAddedService();
				int days = 0;
				vas.setEmployeeName(request.getParameter("Employee Name"));
				vas.setGender(request.getParameter("Gender"));
				vas.setAge(Integer.parseInt(request.getParameter("Age")));
				vas.setMobileNumber(Long.parseLong(request
						.getParameter("Mobile number")));
				vas.setEmail(request.getParameter("Email"));
				String appointmentfor = request.getParameter("Appointment");
				if (appointmentfor == "self") {
					vas.setAppointmentFor(appointmentfor);
					vas.setHealthInsuranceID(request.getParameter("HIIDself"));
					System.out.println("Controller 1: "
							+ vas.getHealthInsuranceID());
				} else {
					vas.setAppointmentFor(appointmentfor);
					vas.setHealthInsuranceID(request
							.getParameter("HIIDdependent"));
					System.out.println("Controller 2: "
							+ vas.getHealthInsuranceID());
				}
				System.out.println("Hospital Name: "+request.getParameter("hospitalList"));
				vas.setState(request.getParameter("StateName"));
				vas.setCity(request.getParameter("CityName"));
				vas.setLocation(request.getParameter("Location"));
				vas.setHospitalName(request.getParameter("hospitalList"));
				vas.setPreferredDate(request.getParameter("Date"));
				vas.setPrefferedTime(request.getParameter("Time"));
				EmployeeService employeeservice = new EmployeeService();
				days = employeeservice.threeMonthsValidation(vas);
				if ((days > 90) || (days == -2)) {
					String vasId = employeeservice.registerEmployeeVAS(vas);
					request.setAttribute("vasId", vasId);
					RequestDispatcher rd = request
							.getRequestDispatcher("Success.jsp");
					rd.forward(request, response);
					System.out.println(vasId);
				} else {
					request.setAttribute("days", days);
					RequestDispatcher rd = request
							.getRequestDispatcher("Error.jsp");
					rd.forward(request, response);
				}
			}
		//// END OF TEAM C

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}