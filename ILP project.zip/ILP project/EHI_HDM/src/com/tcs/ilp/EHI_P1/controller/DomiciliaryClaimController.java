package com.tcs.ilp.EHI_P1.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.service.EmployeeService;

/**
 * Servlet implementation class DomiciliaryClaimController
 */
public class DomiciliaryClaimController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIRECTORY = "C:/uploads";   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DomiciliaryClaimController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub

		DomiciliaryClaim d=new DomiciliaryClaim();
		

		// checks if the request actually contains upload file
		 if(ServletFileUpload.isMultipartContent(request)){
			 
           try {           	
                List<FileItem> multiparts = new ServletFileUpload(
                                         new DiskFileItemFactory()).parseRequest(request);
    			String filePath[] = new String[4];
                int i=0;
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()).getName();
                        item.write( new File(UPLOAD_DIRECTORY + "/" + name));
                        filePath[i] = UPLOAD_DIRECTORY + "/" + name;
                        i++;
                      System.out.println("path = "+UPLOAD_DIRECTORY + File.separator + name); 
                    }
                    else
                    {
                    	System.out.println("field"+item.getFieldName()+" and "+item.getString());
                   
                    		if("nameofdoctor".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside name of doc");
                    			d.setNameOfDoctor(item.getString());	
                    		}
                    		else if("injury".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside healthinsuranceid");
                    			d.setTypeOfillness(item.getString());
                    		}
                    		else if("amount".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside detailsofillness");
                    			d.setTotalClaimAmount(Double.parseDouble(item.getString()));
                    		}
                    		else if("healthinsuranceid".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside reason");
                    			d.setHealthInsuranceId(item.getString());
                    		}
                    		else if("treatmentstartdate".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside amount");
                    			d.setTreatmentStartDate(item.getString());
                    		}
                    		else if("treatmentenddate".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside dateofadmission");
                    			//date= new SimpleDateFormat("MM/dd/yyyy hh:mm:ss").parse(item.getString());
                    			System.out.println("date = "+ item.getString());
                    			d.setTreatmentEndDate(item.getString());
                    		}
                    		else if("dateofinjury".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside dateofdischarge");
                    			//date1= new SimpleDateFormat("mm/dd/yyyy").parse(item.getString());
                    			d.setDateOfInjury(item.getString());
                    		}
                    		
            				d.setUploadPath(filePath);
                    	
            			
                    }
            			
                    }
                
              
              // EmployeeService fs = new EmployeeService();
   			
            } catch (Exception ex) {
              ex.printStackTrace();
            }          
         
        }else{
           
        }
    
	//getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
	
		String cid = "";
		System.out.println("about to call service");
		EmployeeService es1=new EmployeeService();
		try {
			cid = es1.claimDomiciliary(d);
			System.out.println(" called service");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("cid",cid);
		RequestDispatcher rd=request.getRequestDispatcher("domiciliaryResult.jsp");
		rd.forward(request,response);
		
	
	
	}

}
