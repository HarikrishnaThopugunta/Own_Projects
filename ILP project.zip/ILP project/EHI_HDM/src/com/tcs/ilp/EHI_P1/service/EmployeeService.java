package com.tcs.ilp.EHI_P1.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.tcs.ilp.EHI_P1.bean.Bean;
import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.ClaimSearch;
import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.bean.Employee;
import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.ValueAddedService;
import com.tcs.ilp.EHI_P1.dao.EmployeeDao;

//import com.tcs.ilp.EHI_P1.dao.TPADao;

public class EmployeeService {


	
	public String claimDomiciliary(DomiciliaryClaim dc) throws SQLException{
		EmployeeDao employeeDao= new EmployeeDao();
		return employeeDao.claimDomiciliary(dc);
	}
	public String claimHospitalization(HospitalizationClaim hc) throws SQLException{
		EmployeeDao employeeDao= new EmployeeDao();
		return employeeDao.claimHospitalization(hc);
	}

	public Bean hospitalizationSearchEmployee(int empId){

		EmployeeDao dao = new EmployeeDao();
		Bean bean = dao.hospitalizationSearchEmployee(empId); 
		System.out.print("a) "+bean.getEmployeeId()+"inside service "+bean.getEmployeeName());
		return bean;
	}
	public Bean hospitalizationSearchBeneficiary(int empId,String name)
	{
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		Bean bean = dao.hospitalizationSearchBeneficiary(empId, name);
		
		return bean;
	}
	public Bean domiciliarySearchEmployee(int empId){

		EmployeeDao dao = new EmployeeDao();
		Bean bean = dao.domiciliarySearchEmployee(empId);
		System.out.print("a) "+bean.getEmployeeId()+"inside service "+bean.getEmployeeName());
		return bean;
	}
	public Bean domiciliarySearchBeneficiary(int empId,String name)
	{
		EmployeeDao dao = new EmployeeDao();
		Bean bean = dao.domiciliarySearchBeneficiary(empId, name);
		return bean;
	}
	 public HashMap<String,String> searchState()
	 {
		 EmployeeDao dao = new EmployeeDao();
		 return dao.searchState();
	 }
	 
	 public ArrayList<String> searchCityByState(String stateId)
	 {
		 System.out.println("inside service ");
		 EmployeeDao dao = new EmployeeDao();
		 return dao.searchCityByState(stateId);
	 }
	 
	 public HashMap<String,String> searchHospitalByCity(String city,String state)
	 {
		 EmployeeDao dao = new EmployeeDao();
		 return dao.searchHospitalByCity(city,state);
	 }
	 public ArrayList<ClaimSearch> search(String hid) {
			EmployeeDao dao=new EmployeeDao();
			ArrayList<ClaimSearch> clist=dao.searchClaimSearchDao(hid);
			return clist;
		}

		public ArrayList<ClaimSearch> search(String claimType,
				String policyYear, String relation) {
			EmployeeDao dao=new EmployeeDao();
			ArrayList<ClaimSearch> clist=dao.searchClaimSearchDao( claimType,policyYear,relation);
			return clist;
		}

	
	 



	////////		START OF AUTO-GENERATION
	public Beneficiary searchDependent(int i, String name) {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		Beneficiary beneficiary = dao.searchDependent(i,name);
		
		return beneficiary;
	}


	public Beneficiary searchDependent(int empId) {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		Beneficiary beneficiary = dao.searchDependent(empId);
		
		return beneficiary;
	}

	public ArrayList<String> searchDependentName(int empId) {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		ArrayList<String> beneficiary = dao.searchDependentName(empId);
		
		return beneficiary;
	}

	public ArrayList<String> getStates() {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		ArrayList<String> stlist = dao.getStates();
		
		return stlist;
	}

	public ArrayList<String> getCities(String stname) {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		ArrayList<String> ctlist = dao.getCities(stname);
		
		return ctlist;
	}

	public ArrayList<String> getHospitals(String stname, String ctname) {
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		ArrayList<String> hplist = dao.getHospitals(stname,ctname);
		
		return hplist;
	}
	//////// 		END OF AUTO-GENERATION
	
	
	public Employee loginEmployee(Employee e) throws  SQLException
	{
		boolean status=false;
		EmployeeDao empDao=new EmployeeDao();
		Employee b= new Employee();
		System.out.println("Service :");
		b=empDao.loginEmployee(e);
		System.out.println("Service"+status);
		return b;
	}


	public String createBeneficiary(Beneficiary b) throws ClassNotFoundException, SQLException
	{
		String c="NULL";
		EmployeeDao bdao=new EmployeeDao();
		c=bdao.addBeneficiary(b);
		return c;
	}

	public ArrayList<Beneficiary> viewBeneficiaries(long empid) {
		EmployeeDao emp=new EmployeeDao();
		ArrayList<Beneficiary> b = new ArrayList<Beneficiary>();
		b=emp.viewBeneficiaries(empid);
		return b;
	}
	public Beneficiary updateSelectedBeneficiary(String hiid) {
		EmployeeDao emp=new EmployeeDao();
		Beneficiary b = new Beneficiary();
		b=emp.updateSelectedBeneficiary(hiid);
		return b;
	}
	public boolean deleteSelectedBeneficiary(String hiid) {
		EmployeeDao emp=new EmployeeDao();
		boolean b=false;
		b=emp.deleteSelectedBeneficiary(hiid);
		return b;
	}
	public boolean updateSelectedBeneficiaryDetails(Beneficiary b1) {
		EmployeeDao emp=new EmployeeDao();
		boolean b=false;
		b=emp.updateSelectedBeneficiaryDetails(b1);
		return b;
	}

	public HashMap<String,Object> viewEmployee(long empid)
	{System.out.println("servide test view employee");
		HashMap<String,Object> map=new HashMap<String,Object>();
		EmployeeDao empdao=new EmployeeDao();
		map=empdao.viewEmployeeDetails(empid);
		return map; 
	}

	public String addEmployee(Employee employee, Beneficiary beneficiary)
	{
		EmployeeDao empdao= new EmployeeDao();
		return empdao.addEmployeeDetails(employee, beneficiary);

	}
	public boolean deleteEmployee(long empId){
		EmployeeDao dao = new EmployeeDao();
		return dao.deleteEmployeeDetails(empId);
	}
	public boolean updateEmployee(Employee employee, Beneficiary beneficiary){

		EmployeeDao dao = new EmployeeDao();
		return dao.updateEmployeeDetails(employee, beneficiary) ;

	}
	public ArrayList<Beneficiary> viewDetailsByEmpid(long empid)
	{
		EmployeeDao dao= new EmployeeDao();
		ArrayList<Beneficiary> blist= dao.viewDetailsByEmpid(empid);
		return blist;
	}
	
	public Beneficiary payPremiumSelectedBeneficiary(String hiid)
	{
		EmployeeDao dao= new EmployeeDao();
		Beneficiary ben = dao.payPremiumSelectedBeneficiary(hiid);
		return ben;
	}
	
	
	
	
	
	
	
	
/*
 * 					SEARCH HOSPITAL
 */
	public ArrayList<Hospital> searchHospital(String searchHospitalByName) {
		// TODO Auto-generated method stub
		System.out.println("by name in service");
		EmployeeDao emp=new EmployeeDao();
		System.out.println("by name in service");
		ArrayList<Hospital> hospital=emp.searchHospital(searchHospitalByName);
		System.out.println("by name in service");
		return hospital;
		
	}

	public ArrayList<Hospital> searchHospital(int searchHospitalByPincode) {
		// TODO Auto-generated method stub
		
		EmployeeDao emp=new EmployeeDao();
		System.out.println("by pin in service");
		ArrayList<Hospital> hospital=emp.searchHospital(searchHospitalByPincode);
		return hospital;
		
	}

	public ArrayList<Hospital> searchHospitalCity(String searchHospitalByState,String searchHospitalByCity) {
		// TODO Auto-generated method stub
		
		EmployeeDao emp=new EmployeeDao();
		System.out.println("by city in service");
		ArrayList<Hospital> hospital=emp.searchHospital(searchHospitalByState,searchHospitalByCity);
		return hospital;
		
	}

	public ArrayList<Hospital> searchNetHospital() {
		// TODO Auto-generated method stub
		EmployeeDao emp=new EmployeeDao();
		System.out.println("by net hospital in service");
		ArrayList<Hospital> hospital=emp.searchNetHospital();
		return hospital;
	}
	
	public ArrayList<String> getSearchHospital(String hospitalname) {
		// TODO Auto-generated method stub
		System.out.println("inside ajax service");
		EmployeeDao dao = new EmployeeDao();
		ArrayList<String> hoslist = dao.getSearchHospital(hospitalname);
		
		return hoslist;
	}
	
	
	
/*
 * 					VALUE ADDED SERVICES
 */
	
	public int threeMonthsValidation(ValueAddedService vas)
	{
		EmployeeDao employeedao=new EmployeeDao();
		System.out.println("Service : "+vas.getHealthInsuranceID());
		int days=employeedao.threeMonthsValidation(vas);
		return days;
	}
	
	public String registerEmployeeVAS(ValueAddedService vas)
	{
		EmployeeDao employeedao=new EmployeeDao();
		String vasId=employeedao.registerEmployeeVAS(vas);
		return vasId;
	}

}
