package com.tcs.ilp.EHI_P1.service;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.bean.TPABean;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.controller.TPAController;
import com.tcs.ilp.EHI_P1.dao.EmployeeDao;
import com.tcs.ilp.EHI_P1.dao.TPADao;

public class TPAService {

	

	SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm a");
	public static final int BUSINESS_START_HOUR = 9; //      9 AM
	public static final int BUSINESS_END_HOUR = 18; // 6 PM
	public TPABean login(TPABean t)throws Exception
	{
	 TPABean status=null;
	 TPADao dao=new TPADao();
	 System.out.println("service");
	 status= dao.login(t);
	 System.out.println("service "+status );
     return status;
	}
	
	public int fetchDate(String hiid) throws SQLException {
		int slaTime=0;
		TPADao dao=new TPADao();
		 System.out.println("service");
		 slaTime= dao.fetchDate(hiid);
		 
		 System.out.println("sla:"+slaTime);
		//System.out.println(status);
     return slaTime;
		
	}
	
	
	
	
	public ArrayList<Beneficiary> pendingRequest() throws SQLException 
	{
		ArrayList<Beneficiary> status=null;
		TPADao dao=new TPADao();
		 System.out.println("service");
		status= dao.pendingRequest();
		 System.out.println("Calling Service DAO");
     return status;
		
	}
	
	public ArrayList<Beneficiary> viewDetailsOfEmployee() throws SQLException 
	{
		ArrayList<Beneficiary> status=null;
		TPADao dao=new TPADao();
		 System.out.println("service");
		status= dao.viewDetailsOfEmployee();
		 System.out.println("Calling Service DAO");
     return status;
		
	}
	
	public void EscalationReportGeneration()
	{
		int slatime=0;
		TPAService t=new TPAService();
		slatime=t.SLATimeCheck();
		System.out.println(slatime);
	}
	
	public void statusOfRequest()
	{
		
	}
	public int SLATimeCheck()
	{
		return 0;
		
	}
	
	//////////////////

	public boolean Reason(String hiid,String reason) throws SQLException {
	
		TPADao dao=new TPADao();
		 System.out.println("service");
		boolean reasonn= dao.Reason(hiid,reason);
		 System.out.println("Calling Service DAO");
     return reasonn;
		
	}
	
	
	
	
	
	
	public boolean RequestApproval(String hiid) throws SQLException {
		boolean status=false;
		TPADao dao=new TPADao();
		 System.out.println("service");
		status= dao.RequestApproval(hiid);
		 System.out.println("Calling Service DAO");
     return status;
		
	}


	public boolean RequestDecline(String hiid) throws SQLException {
		boolean status=false;
		TPADao dao=new TPADao();
		 System.out.println("service");
		status= dao.RequestDecline(hiid);
		 System.out.println("Calling Service DAO");
     return status;
		
	}
	
	
	////
	
	
	public int findTotalBusinessHours(java.util.Date adate,java.util.Date sdate)
	{
		Calendar n_startDateTime = Calendar.getInstance();
		n_startDateTime.setTime(sdate);
		Calendar n_approveDateTime = Calendar.getInstance();
		n_approveDateTime.setTime(adate);
		System.out.println("Present Date:\t\t" + sdf.format(n_startDateTime.getTime()));

		TPAService time = new TPAService();
		int a= time.addBusinessTime(n_startDateTime,n_approveDateTime);

		System.out.println("\nFinal Date :\t\t" + sdf.format(n_approveDateTime.getTime()));
		return a;
	}
	
	public int addBusinessTime(Calendar givenDateTime,Calendar approvedDateTime)
	{
		// To get Present Working Day & Hour excluding Holidays

		System.out.println("Present Date:\t\t" + sdf.format(givenDateTime.getTime()));
		System.out.println("givendate is:"+givenDateTime.get(Calendar.DATE));
		System.out.println("approveddate is:"+approvedDateTime.get(Calendar.DATE));

		int addTimeMins = 0;
		while(approvedDateTime.compareTo(givenDateTime)>=0)

		{
			int diffMins=0;
			adjustToBusinessHours(givenDateTime);


			// Finding Business End Time On That Day
			Calendar businessEndTime = Calendar.getInstance();
			if(givenDateTime.get(Calendar.DAY_OF_YEAR)<approvedDateTime.get(Calendar.DAY_OF_YEAR))
			{


				businessEndTime.setTime(givenDateTime.getTime());
				businessEndTime.set(Calendar.HOUR_OF_DAY, BUSINESS_END_HOUR);
				businessEndTime.clear(Calendar.MINUTE);
				diffMins = (int) (( businessEndTime.getTimeInMillis() -
						givenDateTime.getTimeInMillis())/(1000*60));
				System.out.println("hi"+diffMins);

			}
			else if(givenDateTime.get(Calendar.DAY_OF_YEAR)==approvedDateTime.get(Calendar.DAY_OF_YEAR))
			{
				businessEndTime.setTime(approvedDateTime.getTime());
				diffMins = (int) (( businessEndTime.getTimeInMillis() -
						givenDateTime.getTimeInMillis())/(1000*60));
				System.out.println("hira"+diffMins);

			}

			addTimeMins=addTimeMins+diffMins;

			System.out.println(addTimeMins);

			givenDateTime.add(Calendar.DATE,1);
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);

		}
		addTimeMins=addTimeMins/60;
		System.out.println("delay time is" + addTimeMins);
		return addTimeMins;
	}

	public void adjustToBusinessHours(Calendar givenDateTime)
	{

		int hourOfDay = givenDateTime.get(Calendar.HOUR_OF_DAY);
		//System.out.println(hourOfDay);

		if(hourOfDay < BUSINESS_START_HOUR)    // Skip to 9 AM on that Day
		{

			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		if(hourOfDay >= BUSINESS_END_HOUR)   // Skip to Next Day 9 AM
		{

			givenDateTime.add(Calendar.DATE, 1);
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		skipHolidays(givenDateTime);       // skip Holidays
	}


	// Method to skip Holidays ( Weekends and General )

	public void skipHolidays(Calendar givenDateTime)
	{
		skipGeneralHolidays(givenDateTime);   // General Holidays before Weekends
		//System.out.println(givenDateTime.get(Calendar.DAY_OF_WEEK));

		if(givenDateTime.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY)
		{

			givenDateTime.add(Calendar.DATE,2);    // Saturday and Sunday
			// in case of Business Hour
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR); 
			givenDateTime.clear(Calendar.MINUTE);
		}

		if(givenDateTime.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)
		{

			givenDateTime.add(Calendar.DATE,1);    // Sunday
			// in case of Business Hour
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		skipGeneralHolidays(givenDateTime);   // General Holidays after Weekends
	}

	// Method to skip General Holidays

	public void skipGeneralHolidays(Calendar givenDateTime)
	{
		// Considering only given Date without Time (Temp)
		Calendar givenDate = Calendar.getInstance(); 
		givenDate.setTime(givenDateTime.getTime());    
		givenDate.set(Calendar.HOUR_OF_DAY, 0);
		givenDate.set(Calendar.MINUTE, 0);   
		givenDate.set(Calendar.SECOND, 0);
		givenDate.set(Calendar.MILLISECOND, 0);

		// List of General Holidays
		GregorianCalendar[] generalHolidays =  getGeneralHolidays(givenDate);

		for(int i=0; i<generalHolidays.length; i++)  // Check for all Holidays
		{

			if(givenDate.equals(generalHolidays[i]))  
			{

				givenDateTime.add(Calendar.DATE,1); // Add one date to Actual Date & Time
				// in case of Business Hour
				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				givenDateTime.clear(Calendar.MINUTE);

				givenDate.add(Calendar.DATE,1);    // Add one date to Temp Date
			}
		}
	}

	// General Holidays list

	public GregorianCalendar[] getGeneralHolidays(Calendar givenDate)
	{

		GregorianCalendar[] genHolidays =  {

				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.JANUARY, 14),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.JANUARY, 26),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.MAY, 1),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.AUGUST, 15),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.OCTOBER, 2),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.NOVEMBER, 1),
				new GregorianCalendar(givenDate.get(Calendar.YEAR), Calendar.DECEMBER, 25)

		};

		return genHolidays;
	}

	public boolean updateApprovalTime(String hiid) throws SQLException {
		boolean status=false;
		 TPADao dao=new TPADao();
		 status= dao.updateApprovalTime(hiid);
		 System.out.println("approval updated"+ status );
	     return status;
	}

	public void errorMessage(String string) {
		// TODO Auto-generated method stub
		TPAController c1=new TPAController();
		System.out.println(string);	
		c1.errorMessage(string);
	
	}

	
	
	
	public ArrayList<Beneficiary> GenerateECard(long id) throws SQLException {
		ArrayList<Beneficiary> ecard = new ArrayList<Beneficiary>();
		EmployeeDao empDao=new EmployeeDao();
		System.out.println("service for E-card");
		ecard= empDao.GenerateECard(id);
	 System.out.println("Calling Service E-Card DAO");
     return ecard;
		
	}
	
	
	
	
	
	
	public String addHospital(Hospital hospital) throws SQLException {
		// TODO Auto-generated method stub
		TPADao tPADao = new TPADao();
		return tPADao.addHospital(hospital);
	}

	public ArrayList<Hospital> UpdateHospital(int hospitalId)
			throws SQLException {
		// TODO Auto-generated method
		TPADao td = new TPADao();
		ArrayList<Hospital> hospital = new ArrayList<>();
		hospital = td.UpdateHospital(hospitalId);
		return hospital;
	}

	public Hospital UpdateHospital(String hid) throws SQLException {
		// TODO Auto-generated method stub
		TPADao td = new TPADao();
		Hospital hospital = new Hospital();
		hospital = td.UpdateHospital(hid);
		return hospital;
	}

	public boolean updateSelectedHospitalDetails(String hid,
			String hospitalName, String address, String cityName,
			String stateName, int pinCode, int stdCode, long phoneNumber)
			throws SQLException {
		// TODO Auto-generated method stub
		TPADao td = new TPADao();
		boolean b = false;
		b = td.updateSelectedHospitalDetails(hid, hospitalName, address,
				cityName, stateName, pinCode, stdCode, phoneNumber);
		return b;
	}

	public boolean DeleteHospital(String hid) throws SQLException {
		// TODO Auto-generated method stub
		TPADao td = new TPADao();
		boolean b = false;
		b = td.DeleteHospital(hid);
		return b;
	}

	public ArrayList<VAS> viewVASForms() {
		TPADao emp = new TPADao();
		ArrayList<VAS> b = new ArrayList<>();
		b = emp.viewVASForms();
		return b;
	}

	public boolean acceptSelectedVAS(String vasID) {
		TPADao emp = new TPADao();
		boolean b = false;
		b = emp.acceptSelectedVAS(vasID);
		return b;
	}

	public boolean declineSelectedVAS(String vasID) {
		TPADao emp = new TPADao();
		boolean b = false;
		b = emp.declineSelectedVAS(vasID);
		return b;
	}

	public boolean checkVASSLATime(String vasID) {
		TPADao emp = new TPADao();
		boolean b = false;
		b = emp.checkVASSLATime(vasID);
		return b;
	}

	public boolean esclateVAS(String vasID, String esc) {
		TPADao emp = new TPADao();
		boolean b = false;
		b = emp.esclateVAS(vasID, esc);
		return b;
	}

	public ArrayList<VAS> getEscalations() {
		TPADao emp = new TPADao();
		ArrayList<VAS> b = new ArrayList<>();
		b = emp.getEscalations();
		return b;
	}



	public ArrayList<DomiciliaryClaim> viewDomiciliaryRequest() {

		TPADao tpadao=new TPADao();
		return tpadao.viewDomiciliaryRequest();
	}

	public ArrayList<HospitalizationClaim> viewHospitalizationRequest() {
		TPADao tpadao=new TPADao();
		return tpadao.viewHospitalizationRequest();
	}
	
	public boolean DomiciliaryClaimSLATime(String claim_Id){
		
		TPADao tpadao=new TPADao();
		return tpadao.checkDomiciliarySLATime(claim_Id);
	
	}
	
	public boolean hospitalizationClaimSLATime(String claim_Id){
	
		TPADao tpadao=new TPADao();
		return tpadao.checkHospitalizationSLATime(claim_Id);
	
	}
	
	public boolean approveDomiciliaryClaim(String claimId, double approvedamount,String status,String claimEscaltion,String claimAction){
		TPADao tpadao=new TPADao();
		return tpadao.approveDomiciliaryClaim(claimId, approvedamount, status, claimEscaltion,claimAction);
	}
	
	
	public boolean approveHospitalizationClaim(String claimId, double approvedamount,String status,String claimEscaltion,String claimAction){
		TPADao tpadao=new TPADao();
		return tpadao.approveHospitalizationClaim(claimId, approvedamount, status, claimEscaltion,claimAction);
	}
	

	public boolean esclateDomiciliaryClaim(String claim_Id,String claim_esclate, double approved_Amount, String claim_Status,String claimAction) {

		TPADao tpadao=new TPADao();
		return tpadao.esclateDomiciliaryClaim(claim_Id, claim_esclate,approved_Amount,claim_Status,claimAction);
	}
	public  boolean esclateHospitalizationClaim(String claimId,String claimEsclation,double approved_Amount, String claim_Status,String claimAction)
	{
		TPADao tpadao=new TPADao();
		return tpadao.esclateHospitalizationClaim(claimId, claimEsclation,approved_Amount,claim_Status,claimAction);
	}
	public String[] DomicilaryClaimDocument(String claimid)
	{
		TPADao tpadao=new TPADao();
		return tpadao.DomicilaryClaimDocument(claimid);
	}
	public String[] HospitalizationClaimDocument(String claimid)
	{
		TPADao tpadao=new TPADao();
		return tpadao.HospitalizationClaimDocument(claimid);
	}



}
