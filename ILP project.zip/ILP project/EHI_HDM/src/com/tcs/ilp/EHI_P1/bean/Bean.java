package com.tcs.ilp.EHI_P1.bean;

import java.util.ArrayList;

public class Bean {

	private int employeeId;
	private String employeeName;
	private String emailId;
	private String mobileNo;
	private String address;
	private ArrayList<String> patient = new ArrayList<String>() ;
	private String gender;
	private String relation;
	private int age;
	private String healthinsuranceid;
	private ArrayList<String> stateNames = new ArrayList<String>();
	private ArrayList<String> stateIds = new ArrayList<String>();
	private ArrayList<String> cityNames = new ArrayList<String>();
	private ArrayList<String> cityIds = new ArrayList<String>();
	private ArrayList<String> hospitalNames = new ArrayList<String>();
	private ArrayList<String> hospitalIds = new ArrayList<String>();
	
	public ArrayList<String> getHospitalNames(){
		
		return hospitalNames;
	}
	public void setHospitalNames(ArrayList<String> hospitalNames) {
		this.hospitalNames = hospitalNames;
	}
	public ArrayList<String> getHospitalIds() {
		return hospitalIds;
	}
	public void setHospitalIds(ArrayList<String> hospitalIds) {
		this.hospitalIds = hospitalIds;
	}
	public ArrayList<String> getCityNames() {
		return cityNames;
	}
	public void setCityNames(ArrayList<String> cityNames) {
		this.cityNames = cityNames;
	}
	public ArrayList<String> getCityIds() {
		return cityIds;
	}
	public void setCityIds(ArrayList<String> cityIds) {
		this.cityIds = cityIds;
	}
	public ArrayList<String> getStateNames() {
		return stateNames;
	}
	public void setStateNames(ArrayList<String> stateNames) {
		this.stateNames = stateNames;
	}
	public ArrayList<String> getStateIds() {
		return stateIds;
	}
	public void setStateIds(ArrayList<String> stateIds) {
		this.stateIds = stateIds;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public ArrayList<String> getPatient() {
		return patient;
	}
	public void setPatient(ArrayList<String> patient) {
		this.patient = patient;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getHealthinsuranceid() {
		return healthinsuranceid;
	}
	public void setHealthinsuranceid(String healthinsuranceid) {
		this.healthinsuranceid = healthinsuranceid;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	
}
