package com.tcs.ilp.EHI_P1.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.service.EmployeeService;

/**
 * Servlet implementation class HospitalizationClaimController
 */
public class HospitalizationClaimController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIRECTORY = "C:/uploads"; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HospitalizationClaimController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HospitalizationClaim h=new HospitalizationClaim();
		

		// checks if the request actually contains upload file
		 if(ServletFileUpload.isMultipartContent(request)){
			 
           try {
            	
                List<FileItem> multiparts = new ServletFileUpload(
                                         new DiskFileItemFactory()).parseRequest(request);
    			String filePath[] = new String[5];
                int i=0;
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()).getName();
                        item.write( new File(UPLOAD_DIRECTORY + "/" + name));
                        filePath[i] = UPLOAD_DIRECTORY + "/" + name;
                        i++;
                      System.out.println("path = "+UPLOAD_DIRECTORY + File.separator + name); 
                    }
                    else
                    {
                    	System.out.println("field"+item.getFieldName()+" and "+item.getString());
                   
                    
            				
                    		if("nameofdoctor".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside name of doc");
                    			h.setNameOfDoctor(item.getString());	
                    		}
                    		else if("hospitalname".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside healthinsuranceid");
                    			h.setHospitalId(item.getString());
                    		}
                    		else if("healthinsuranceid".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside healthinsuranceid");
                    			h.setHealthInsuranceId(item.getString());
                    		}
                    		else if("detailsofillness".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside detailsofillness");
                    			h.setDetailsOfIllnessOrInjury(item.getString());
                    		}
                    		else if("y".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside reason");
                    			h.setReasonforInjury(item.getString());
                    		}
                    		else if("amount".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside amount");
                    			h.setTotalClaimAmount(Double.parseDouble(item.getString()));
                    		}
                    		else if("dateofadmission".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside dateofadmission");
                    			//date= new SimpleDateFormat("MM/dd/yyyy hh:mm:ss").parse(item.getString());
                    			System.out.println("date = "+ item.getString());
                    			h.setDateOfAdmission(item.getString());
                    		}
                    		else if("dateofdischarge".equals(item.getFieldName()))
                    		{
                    			System.out.println("Inside dateofdischarge");
                    			//date1= new SimpleDateFormat("mm/dd/yyyy").parse(item.getString());
                    			h.setDateOfAdmission(item.getString());
                    		}
                    		
            				h.setUploadPath(filePath);
                    	
            			
                    }
            			
                    }
                
               request.setAttribute("message", "File Uploaded Successfully");
              // EmployeeService fs = new EmployeeService();
   			
            } catch (Exception ex) {
               request.setAttribute("message", "Form fail to submit due to " + ex+" Try Again after some time.");
            }          
         
        }else{
            request.setAttribute("message",
                                 "Sorry this Servlet only handles file upload request");
        }
    
	//getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
	
		String cid = "";
		System.out.println("about to call service");
		EmployeeService es1=new EmployeeService();
		try {
			cid = es1.claimHospitalization(h);
			System.out.println(" called service");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("cid",cid);
		RequestDispatcher rd=request.getRequestDispatcher("hospitalizationResult.jsp");
		rd.forward(request,response);
		
	
	}

}
