package com.tcs.ilp.EHI_P1.bean;

public class Hospital {
	private String hospitalId;
	private String hospitalName;
	private String address;
	private String  cityName;
	private String stateName;
	private int pinCode;
	private int STDCode;
	private long phoneNumber;
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String string) {
		this.hospitalId = string;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public int getSTDCode() {
		return STDCode;
	}
	public void setSTDCode(int sTDCode) {
		STDCode = sTDCode;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	

}
