package com.tcs.ilp.EHI_P1.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	static int c=0;
public static Connection getconnection() throws SQLException{
		int a=2;
		c=a;
		Connection con= null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con= DriverManager.getConnection("jdbc:oracle:thin:@172.26.132.40:1521:orclilp", "aja26core", "aja26core");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		return con;
	}
	
	public static void closeConnection(Connection con){
		if(con!=null)
		{
			try{
				con.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public static void closeConnection(PreparedStatement con){
		if(con!=null)
		{
			try{
				con.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
		
		public static void closeConnection(ResultSet con){
			if(con!=null)
			{
				try{
					con.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		}
}
