package com.tcs.ilp.EHI_P1.bean;

import java.sql.Timestamp;
import java.util.Date;

public class HospitalizationClaim {

	private String claimId;
	private String HealthInsuranceId;
	private String hospitalId;
	private String TPAId;
	private double approvedAmount;
	private Date approvedDateTime;
	private String status;
	private String dateOfAdmission;
	private String dateOfDischarge;
	private String nameOfDoctor;
	private String DetailsOfIllnessOrInjury;
	private String reasonforInjury;
	private double totalClaimAmount;
	private String[] uploadPath = new String[5];
	private String action;
	private String claim_type;
	private String claim_escalation;
	private Timestamp claim_date;
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	public String getHealthInsuranceId() {
		return HealthInsuranceId;
	}
	public void setHealthInsuranceId(String healthInsuranceId) {
		HealthInsuranceId = healthInsuranceId;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getTPAId() {
		return TPAId;
	}
	public void setTPAId(String tPAId) {
		TPAId = tPAId;
	}
	public double getApprovedAmount() {
		return approvedAmount;
	}
	public void setApprovedAmount(double approvedAmount) {
		this.approvedAmount = approvedAmount;
	}
	public Date getApprovedDateTime() {
		return approvedDateTime;
	}
	public void setApprovedDateTime(Date approvedDateTime) {
		this.approvedDateTime = approvedDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDateOfAdmission() {
		return dateOfAdmission;
	}
	public void setDateOfAdmission(String dateOfAdmission) {
		this.dateOfAdmission = dateOfAdmission;
	}
	public String getDateOfDischarge() {
		return dateOfDischarge;
	}
	public void setDateOfDischarge(String dateOfDischarge) {
		this.dateOfDischarge = dateOfDischarge;
	}
	public String getNameOfDoctor() {
		return nameOfDoctor;
	}
	public void setNameOfDoctor(String nameOfDoctor) {
		this.nameOfDoctor = nameOfDoctor;
	}
	public String getDetailsOfIllnessOrInjury() {
		return DetailsOfIllnessOrInjury;
	}
	public void setDetailsOfIllnessOrInjury(String detailsOfIllnessOrInjury) {
		DetailsOfIllnessOrInjury = detailsOfIllnessOrInjury;
	}
	public String getReasonforInjury() {
		return reasonforInjury;
	}
	public void setReasonforInjury(String reasonforInjury) {
		this.reasonforInjury = reasonforInjury;
	}
	
	
	public double getTotalClaimAmount() {
		return totalClaimAmount;
	}
	public void setTotalClaimAmount(double totalClaimAmount) {
		this.totalClaimAmount = totalClaimAmount;
	}
	public String[] getUploadPath() {
		return uploadPath;
	}
	public void setUploadPath(String[] uploadPath) {
		this.uploadPath = uploadPath;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getClaim_type() {
		return claim_type;
	}
	public void setClaim_type(String claim_type) {
		this.claim_type = claim_type;
	}
	public String getClaim_escalation() {
		return claim_escalation;
	}
	public void setClaim_escalation(String claim_escalation) {
		this.claim_escalation = claim_escalation;
	}
	public Timestamp getClaim_date() {
		return claim_date;
	}
	public void setClaim_date(Timestamp claim_date) {
		this.claim_date = claim_date;
	}
	
	
}
