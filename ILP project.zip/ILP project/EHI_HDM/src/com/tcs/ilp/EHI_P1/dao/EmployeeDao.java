package com.tcs.ilp.EHI_P1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import com.tcs.ilp.EHI_P1.bean.Bean;
import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.ClaimSearch;
import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.bean.Employee;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.bean.TPABean;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.bean.ValueAddedService;
import com.tcs.ilp.EHI_P1.util.DBUtil;

public class EmployeeDao {
	Connection con = null;
	PreparedStatement ps = null;
	Statement s = null;
	ResultSet rs, rs1 = null;
	int vasId = 0;
	Statement stm=null;
	Statement stm1=null;
	//ResultSet rs = null;
	boolean status=false;
	

	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	
	
	PreparedStatement ps1 = null;
	PreparedStatement ps2 = null;
	
	

 
	public String claimDomiciliary(DomiciliaryClaim dc) throws SQLException {
		String claimid = "";
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("INSERT INTO P1_DOMICILIARY_CLAIMS (CLAIMID, TREATMENTSTARTDATE, TREATMENTENDDATE, DATEOFINJURY, NAMEOFDOCTOR, TYPEOFILLNESS, TOTALCLAIMAMOUNT, HEALTHINSURANCEID,CLAIMEDDATE) VALUES (next_P1_DOMICILIARY_SEQUENCE,to_date (?, 'YYYY-MM-DD'),to_date (?, 'YYYY-MM-DD'),to_date (?, 'YYYY-MM-DD'),?,?,?,?,CURRENT_TIMESTAMP)");
			ps.setString(1, dc.getTreatmentStartDate());
			ps.setString(2, dc.getTreatmentEndDate());
			ps.setString(3, dc.getDateOfInjury());
			ps.setString(4,dc.getNameOfDoctor());
			ps.setString(5, dc.getTypeOfillness());
			ps.setDouble(6, dc.getTotalClaimAmount());
			ps.setString(7, dc.getHealthInsuranceId());
			
		    ps.execute();
			ps1 = con.prepareStatement("select 'D'||to_char(P1_DOMICILIARY_SEQUENCE.currval,'FM09999999') from dual");
			rs = ps1.executeQuery();
			if (rs.next()) {
				claimid = rs.getString(1);
			}
		   
			ps2=con.prepareStatement("INSERT INTO P1_DOMICILIARY_CLAIM_DOCUMENT VALUES (P1_DCDOC_SEQ.nextval,?,?,?,?,?)");
			ps2.setString(1,claimid);
			ps2.setString(2,dc.getUploadPath()[0]);
			ps2.setString(3,dc.getUploadPath()[1]);
			ps2.setString(4,dc.getUploadPath()[2]);
			ps2.setString(5,dc.getUploadPath()[3]);
			
			System.out.println("hello" +dc.getUploadPath()[0]);
			int status=ps2.executeUpdate();
			if(status==1)
				System.out.println("Done dude");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}

		return claimid;

	}

	public String claimHospitalization(HospitalizationClaim hc) throws SQLException {
		String claimid = "";
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("INSERT INTO P1_HOSPITALIZATION_CLAIMS (CLAIM_ID,HOSPITALID,DATEOFADMISSION,DATEOFDISCHARGE,HEALTHINSURANCEID,NAMEOFDOCTOR,DETAILSOFILLNESS,REASONFORINJURY,TOTALCLAIMAMOUNT,CLAIMEDDATE) VALUES (NEXT_P1_HOSPITALIZATION_SEQ,?,to_date (?, 'YYYY-MM-DD'),to_date (?, 'YYYY-MM-DD'),?,?,?,?,?,CURRENT_TIMESTAMP)");
			ps.setString(1,hc.getHospitalId());
			ps.setString(2, hc.getDateOfAdmission());
			ps.setString(3, hc.getDateOfDischarge());
			ps.setString(4,hc.getHealthInsuranceId());
			ps.setString(5,hc.getNameOfDoctor());
			ps.setString(6, hc.getDetailsOfIllnessOrInjury());
			ps.setString(7, hc.getReasonforInjury());
			System.out.println(hc.getReasonforInjury());
			ps.setDouble(8,hc.getTotalClaimAmount());
			System.out.println(" before execute"+hc.getTotalClaimAmount());
			 ps.execute();
				ps1 = con.prepareStatement("select 'HC'||to_char(P1_HOSPITALIZATION_SEQ.currval,'FM09999999') from dual");
				rs = ps1.executeQuery();
				if (rs.next()) {
					claimid = rs.getString(1);
				}

				ps2=con.prepareStatement("INSERT INTO P1_HOSPITALIZATION_CLAIM_DOC VALUES (P1_HCDOC_SEQ.nextval,?,?,?,?,?,?)");
				ps2.setString(1,claimid);
				ps2.setString(2,hc.getUploadPath()[0]);
				ps2.setString(3,hc.getUploadPath()[1]);
				ps2.setString(4,hc.getUploadPath()[2]);
				ps2.setString(5,hc.getUploadPath()[3]);
				ps2.setString(6,hc.getUploadPath()[4]);
				System.out.println("hello" +hc.getUploadPath()[0]);
				int status=ps2.executeUpdate();
				if(status==1)
					System.out.println("Done dude");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}

		return claimid;

	}


	
	 
	 public Bean hospitalizationSearchEmployee(int empId) {
			Bean bean = new Bean();
			try{
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT EMPLOYEENAME,E_MAIL,PHONENUMBER,ADDRESS FROM P1_EMPLOYEE WHERE EMPLOYEEID=?");
			ps.setInt(1, empId);
			ResultSet rs= ps.executeQuery();
			while(rs.next())
			{
				String empName = rs.getString(1);
				String emailId = rs.getString(2);
				String mobileNo = rs.getString(3);
				String address = rs.getString(4);
				bean.setEmployeeId(empId);
				bean.setEmployeeName(empName);
				bean.setEmailId(emailId);
				bean.setMobileNo(mobileNo);
				bean.setAddress(address);
				
				
				
			}
			ps1 = con.prepareStatement("SELECT BENEFICIARYNAME FROM P1_BENEFICIARY WHERE EMPLOYEEID=?");
			ps1.setInt(1, empId);
			ResultSet rs1= ps1.executeQuery();
		
		    ArrayList<String> patient = new ArrayList<>();
		    
		   
			while(rs1.next())
			{
				patient.add(rs1.getString(1));
			}
			 System.out.println("name");
			bean.setPatient(patient);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				
				DBUtil.closeConnection(ps);
				DBUtil.closeConnection(ps1);
				DBUtil.closeConnection(con);
				
				
			}
			return bean;
		}
	 
	 public Bean hospitalizationSearchBeneficiary(int empId,String name) {
			Bean bean = new Bean();
			try{
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT GENDER,RELATION,HEALTHINSURANCEID FROM P1_BENEFICIARY WHERE BENEFICIARYNAME=? AND EMPLOYEEID=?");
			ps.setString(1, name);
			ps.setInt(2, empId);
			ResultSet rs= ps.executeQuery();
			System.out.println("its outside while ");
			while(rs.next())
			{
				System.out.println("its inside while ");
				String gender = rs.getString(1);
				String relation = rs.getString(2);
				String healthinsuranceid = rs.getString(3);
				
				bean.setGender(gender);
				bean.setRelation(relation);
				bean.setHealthinsuranceid(healthinsuranceid);
				
				
				
			}
			ps1 = con.prepareStatement("SELECT EXTRACT(YEAR FROM sysdate) - EXTRACT(YEAR FROM (SELECT DATEOFBIRTH FROM P1_BENEFICIARY WHERE BENEFICIARYNAME=? AND EMPLOYEEID=? )) AS AGE FROM dual");
			ps1.setString(1, name);
			ps1.setInt(2, empId);
			ResultSet rs1= ps1.executeQuery();
			while(rs1.next())
			{
				int age = rs1.getInt(1);
				bean.setAge(age);
			}
			 System.out.println("name");
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				
				DBUtil.closeConnection(ps1);;
				DBUtil.closeConnection(ps);;
				DBUtil.closeConnection(con);;
				
			}
			return bean;
		}
	 
	 public Bean domiciliarySearchEmployee(int empId) {
			Bean bean = new Bean();
			try{
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT PHONENUMBER,ADDRESS FROM P1_EMPLOYEE WHERE EMPLOYEEID=?");
			ps.setInt(1, empId);
			ResultSet rs= ps.executeQuery();
			while(rs.next())
			{
				String mobileNo = rs.getString(1);
				String address = rs.getString(2);
				
				
				bean.setMobileNo(mobileNo);
				bean.setAddress(address);
				bean.setEmployeeId(empId);
				
				
			}
			ps1 = con.prepareStatement("SELECT BENEFICIARYNAME FROM P1_BENEFICIARY WHERE EMPLOYEEID=?");
			ps1.setInt(1, empId);
			ResultSet rs1= ps1.executeQuery();
		
		    ArrayList<String> beneficiary = new ArrayList<>();
			while(rs1.next())
			{
				beneficiary.add(rs1.getString(1));
			}
			 System.out.println("name");
			bean.setPatient(beneficiary);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				
				DBUtil.closeConnection(ps);;
				DBUtil.closeConnection(ps1);
				DBUtil.closeConnection(con);;
				
			}
			return bean;
		}
	 

	 public Bean domiciliarySearchBeneficiary(int empId,String name) {
			Bean bean = new Bean();
			try{
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT HEALTHINSURANCEID FROM P1_BENEFICIARY WHERE BENEFICIARYNAME=? AND EMPLOYEEID=?");
			ps.setString(1, name);
			ps.setInt(2, empId);
			ResultSet rs= ps.executeQuery();
			System.out.println("its outside while ");
			while(rs.next()) {
				System.out.println("its inside while ");
				
				String healthinsuranceid = rs.getString(1);
				bean.setHealthinsuranceid(healthinsuranceid);
			 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{				
				DBUtil.closeConnection(ps);
				DBUtil.closeConnection(ps1);
				DBUtil.closeConnection(con);				
			}
			return bean;
		}
	 public HashMap<String,String> searchState()
	 {
		 HashMap<String,String> states = new HashMap<String,String>();
		 try {
		 con = DBUtil.getconnection();
			
				ps = con.prepareStatement("SELECT STATENAME,STATEID from P1_STATE");
			
			ResultSet rs= ps.executeQuery();
			while(rs.next())
			{
				states.put(rs.getString(2),rs.getString(1));
			}
			
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 finally{
				
				DBUtil.closeConnection(ps);;
			
				DBUtil.closeConnection(con);
				
			}
		 return states;
	 }
	 public ArrayList<String> searchCityByState(String stateId)
	 {
		 
		ArrayList<String> cities = new ArrayList<String>();
		 try {
		 con = DBUtil.getconnection();
			
				ps = con.prepareStatement("SELECT CITYNAME from P1_CITY where STATEID=?");
			    ps.setString(1, stateId);
			ResultSet rs= ps.executeQuery();
			while(rs.next())
			{
				cities.add(rs.getString(1));
				System.out.println("city= "+rs.getString(1));
			}
			
		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 finally{
				
				DBUtil.closeConnection(ps);
				
				DBUtil.closeConnection(con);
				
			}
		 return cities;
	 }
	 
	 public HashMap<String,String> searchHospitalByCity(String city,String state)
	 {
		 HashMap<String,String> hos = new HashMap<String,String>();
		 try {
		 con = DBUtil.getconnection();
			
				ps = con.prepareStatement("SELECT HospitalName,HospitalID from P1_Hospital h,P1_STATE s where h.CITY=? and s.STATEID=?");
			    ps.setString(1, city);
			    ps.setString(2, state);
			ResultSet rs= ps.executeQuery();
			System.out.println("above dao");
			while(rs.next())
			{
				System.out.println("dao= "+rs.getString(2));
				hos.put(rs.getString(2),rs.getString(1));
			}

		 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 finally{
				
				DBUtil.closeConnection(ps);
			
				DBUtil.closeConnection(con);
				
			}
		 return hos;
	 }
	 private ResultSet rs2;
		//	Connection con = null;	
			PreparedStatement ps4,ps5 = null;

			 
				
			public ArrayList<ClaimSearch> searchClaimSearchDao(String hid) 
			{
				
				ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
				
				
				System.out.println(hid);
				 try
				 {
					 con=DBUtil.getconnection();
					 ps4=con.prepareStatement("SELECT d.claimId,d.claimedDate,b.BeneficiaryName,b.Relation,d.totalClaimAmount,d.approvedAmount,d.status,d.action,d.Escalation_Report"+
				 " FROM P1_BENEFICIARY b ,P1_DOMICILIARY_CLAIMS d where b.HealthInsuranceId=d.HealthInsuranceId AND b.HealthInsuranceId=? " );
						 ps4.setString(1,hid);
					 		 rs1=ps4.executeQuery();
					 		
					
					 while(rs1.next())
					 {	
						
						 ClaimSearch s1=new ClaimSearch();
						 s1.setClaimType("Domiciliary Claim");
						 s1.setMediAssistClaimNo(rs1.getString("claimId"));
						 s1.setClaimRaisedOn(rs1.getDate("claimedDate"));
						 s1.setPatientName(rs1.getString("BeneficiaryName"));
						 s1.setRelation(rs1.getString("Relation"));
						 s1.setClaimAmount(rs1.getDouble("totalClaimAmount"));
						 s1.setApprovedAmount(rs1.getDouble("approvedAmount"));
						 s1.setClaimStatus(rs1.getString("status"));
						 s1.setAction(rs1.getString("action"));
						 s1.setEscalation_Report(rs1.getString("Escalation_Report"));
						 clist.add(s1); 
						 
						 }	
					 con.commit();
					 for( ClaimSearch s:clist)
					 {
						 System.out.println(s.getMediAssistClaimNo());
					 }
					
			
				 
						ps5=con.prepareStatement("SELECT h.claim_Id,h.claimedDate,b.BeneficiaryName,b.Relation,h.totalClaimAmount," +
							 		"h.approvedAmount,h.status,h.action,h.Escalation_Report " +
							 		" FROM P1_BENEFICIARY b, P1_HOSPITALIZATION_CLAIMS h " +
							 			" where b.HealthInsuranceId=h.HealthInsuranceId and b.HealthInsuranceId=?");
						 ps5.setString(1,hid);
						 rs2=ps5.executeQuery();
							 		 while(rs2.next())
							 		 {	
							 			 ClaimSearch s2=new ClaimSearch();
							 		 s2.setClaimType("Hospitalization Claim");
									 s2.setMediAssistClaimNo(rs2.getString(1));
									 s2.setClaimRaisedOn(rs2.getDate(2));
									 s2.setPatientName(rs2.getString(3));
									 s2.setRelation(rs2.getString(4));
									 s2.setClaimAmount(rs2.getDouble(5));
									 s2.setApprovedAmount(rs2.getDouble(6));
									 s2.setClaimStatus(rs2.getString(7));
									 s2.setAction(rs2.getString(8));
									 s2.setEscalation_Report(rs2.getString(9));
									 clist.add(s2); 		 
									 	
									 	 
							 		 }
							 		 con.commit();
							 		
					
					
					}
			
					catch (Exception e) 
					{
					e.printStackTrace();
					}
				finally
				{
					DBUtil.closeConnection(ps4);	
					DBUtil.closeConnection(ps5);	
					DBUtil.closeConnection(rs1);	
					DBUtil.closeConnection(rs2);	
					DBUtil.closeConnection(con);

				}
					return clist;
			}

			public ArrayList<ClaimSearch> searchClaimSearchDao(String claimType,String policyYear, String relation) 
			{
				System.out.println("ctype is" +claimType+policyYear+ relation);
				ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
			
			
				 try
				 {					
								 con=DBUtil.getconnection();
								 
								if(claimType.equals("All") && relation.equals("All"))
								{
									clist=searchPolicyYear(policyYear) ;
								}else if(claimType.equals("All"))
								{
									 clist=searchPolicyYearRelation( policyYear,  relation) ;
								}else if(relation.equals("All"))
								{	
									 clist=searchClaimTypePolicyYear(claimType,policyYear) ;
								}
								else
								{
									 clist=searchAll( claimType,  policyYear,  relation) ;
								}
							 }
								catch (Exception e) 
								{
								e.printStackTrace();
								}
							finally
							{
								DBUtil.closeConnection(ps4);	
								DBUtil.closeConnection(ps5);	
								DBUtil.closeConnection(rs1);	
								DBUtil.closeConnection(rs2);	
								DBUtil.closeConnection(con);
								}
							 return clist;
								
						}
						
						public ArrayList<ClaimSearch> searchPolicyYear(String policyYear) 
						{
							ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
							 try
							 {	
								 con=DBUtil.getconnection();
									 ps4=con.prepareStatement("SELECT d.claimId,d.claimedDate,b.BeneficiaryName,b.Relation,d.totalClaimAmount, " +
								 		"d.approvedAmount,d.status,d.action,d.Escalation_Report " +
								 		"FROM P1_BENEFICIARY b, P1_DOMICILIARY_CLAIMS d " +
								 			"where b.HEALTHINSURANCEID=d.HEALTHINSURANCEID  " +
								 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
								
									 ps4.setString(1,policyYear);
								 		 rs1=ps4.executeQuery();
								 while(rs1.next())
								 { 

									 ClaimSearch s1=new ClaimSearch();
									 s1.setClaimType("Domiciliary Claim");
									 s1.setMediAssistClaimNo(rs1.getString("claimId"));
									 s1.setClaimRaisedOn(rs1.getDate("claimedDate"));
									 s1.setPatientName(rs1.getString("BeneficiaryName"));
									 s1.setRelation(rs1.getString("Relation"));
									 s1.setClaimAmount(rs1.getDouble("totalClaimAmount"));
									 s1.setApprovedAmount(rs1.getDouble("approvedAmount"));
									 s1.setClaimStatus(rs1.getString("status"));
									 s1.setAction(rs1.getString("action"));
									 s1.setEscalation_Report(rs1.getString("Escalation_Report"));
									 clist.add(s1); 
									 
								 }
								 ps5=con.prepareStatement("SELECT h.claim_Id,h.claimedDate,b.BeneficiaryName,b.Relation,h.totalClaimAmount " +
									 		",h.approvedAmount,h.status,h.action,h.Escalation_Report " +
									 		"FROM P1_BENEFICIARY b , P1_HOSPITALIZATION_CLAIMS h " +
									 			"where b.HEALTHINSURANCEID=h.HEALTHINSURANCEID  " +
									 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
								
								 ps5.setString(1,policyYear);
									 		 rs2=ps5.executeQuery();
									 		 while(rs2.next())
									 		 {									
									 			 ClaimSearch s2=new ClaimSearch();
										 		 s2.setClaimType("Hospitalization Claim");
												 s2.setMediAssistClaimNo(rs2.getString(1));
												 s2.setClaimRaisedOn(rs2.getDate(2));
												 s2.setPatientName(rs2.getString(3));
												 s2.setRelation(rs2.getString(4));
												 s2.setClaimAmount(rs2.getDouble(5));
												 s2.setApprovedAmount(rs2.getDouble(6));
												 s2.setClaimStatus(rs2.getString(7));
												 s2.setAction(rs2.getString(8));
												 s2.setEscalation_Report(rs2.getString(9));
												 clist.add(s2); 		 
												 	
											 	}	 
									 		
								 con.commit();
								
							 }
								 catch (Exception e) 
									{
									e.printStackTrace();
									}
								finally
									{

									DBUtil.closeConnection(ps4);	
									DBUtil.closeConnection(ps5);	
									DBUtil.closeConnection(rs1);	
									DBUtil.closeConnection(rs2);	
									DBUtil.closeConnection(con);
									}
							return clist;
								
								 }
						
						
						
						 ArrayList<ClaimSearch> searchPolicyYearRelation(String policyYear, String relation) 
						{
							 ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
							 try
							 {
								 con=DBUtil.getconnection();
									 ps4=con.prepareStatement("SELECT d.claimId,d.claimedDate,b.BeneficiaryName,b.Relation,d.totalClaimAmount, " +
								 		"d.approvedAmount,d.status,d.action,d.Escalation_Report " +
								 		"FROM P1_BENEFICIARY b, P1_DOMICILIARY_CLAIMS d " +
								 			"where b.HEALTHINSURANCEID=d.HEALTHINSURANCEID  " +
								 			"AND b.relation=? " +
								 					" AND EXTRACT (YEAR from b.POLICYSTARTDATE)= ? ");
									 ps4.setString(1,relation);
									 ps4.setString(2,policyYear);
								 	 rs1=ps4.executeQuery();
								 		
								 while(rs1.next())
								 { 
									 ClaimSearch s1=new ClaimSearch();
									 System.out.println("query finish");
									 s1.setClaimType("Domiciliary Claim");
									 s1.setMediAssistClaimNo(rs1.getString(1));
									 s1.setClaimRaisedOn(rs1.getDate(2));
									 s1.setPatientName(rs1.getString(3));
									 s1.setRelation(rs1.getString(4));
									 s1.setClaimAmount(rs1.getDouble(5));
									 s1.setApprovedAmount(rs1.getDouble(6));
									 s1.setClaimStatus(rs1.getString(7));
									 s1.setAction(rs1.getString(8));
									 s1.setEscalation_Report(rs1.getString(9));
									 clist.add(s1); 
									 for( ClaimSearch s:clist)
									 {
										 System.out.println("for"+s.getMediAssistClaimNo());
									 }
								
								 }
								 
								 ps5=con.prepareStatement("SELECT h.claim_Id,h.claimedDate,b.BeneficiaryName,b.Relation,h.totalClaimAmount, " +
									 		"h.approvedAmount,h.status,h.action,h.Escalation_Report " +
									 		"FROM P1_BENEFICIARY b, P1_Hospitalization_CLAIMS h " +
									 			"where b.HEALTHINSURANCEID=h.HEALTHINSURANCEID  " +
									 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)= ? " +
									 			"AND b.relation=?");
										 ps5.setString(1,policyYear);
										 ps5.setString(2,relation);
									 		 rs2=ps5.executeQuery();
									 while(rs2.next())
									 {  ClaimSearch s2=new ClaimSearch();
							 		 s2.setClaimType("Hospitalization Claim");
									 s2.setMediAssistClaimNo(rs2.getString(1));
									 s2.setClaimRaisedOn(rs2.getDate(2));
									 s2.setPatientName(rs2.getString(3));
									 s2.setRelation(rs2.getString(4));
									 s2.setClaimAmount(rs2.getDouble(5));
									 s2.setApprovedAmount(rs2.getDouble(6));
									 s2.setClaimStatus(rs2.getString(7));
									 s2.setAction(rs2.getString(8));
									 s2.setEscalation_Report(rs2.getString(9));
									 clist.add(s2);
									 con.commit();	
									}
									 
							 }
							
							
							 catch (Exception e) 
									{
									e.printStackTrace();
									}
								finally
									{
									DBUtil.closeConnection(ps4);	
									DBUtil.closeConnection(ps5);	
									DBUtil.closeConnection(rs1);	
									DBUtil.closeConnection(rs2);	
									DBUtil.closeConnection(con);
									}
									return clist;
								 }
						 
						 
						 
						 ArrayList<ClaimSearch> searchClaimTypePolicyYear(String claimType,String policyYear)
								 {
							 ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
							 try
							 {
								 if(claimType.equals("domiciliary"))
								 {
								 con=DBUtil.getconnection();
									 ps4=con.prepareStatement("SELECT d.claimId,d.claimedDate,b.BeneficiaryName,b.Relation,d.totalClaimAmount, " +
								 		"d.approvedAmount,d.status,d.action,d.Escalation_Report " +
								 		"FROM P1_BENEFICIARY b, P1_DOMICILIARY_CLAIMS d " +
								 			"where b.HEALTHINSURANCEID=d.HEALTHINSURANCEID  " +
								 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
									 ps4.setString(1,policyYear);
									
								 		 rs1=ps4.executeQuery();
								 while(rs1.next())
								 { 
									 ClaimSearch s1=new ClaimSearch();
									 s1.setClaimType("Domiciliary Claim");
									 s1.setMediAssistClaimNo(rs1.getString("claimId"));
									 s1.setClaimRaisedOn(rs1.getDate("claimedDate"));
									 s1.setPatientName(rs1.getString("BeneficiaryName"));
									 s1.setRelation(rs1.getString("Relation"));
									 s1.setClaimAmount(rs1.getDouble("totalClaimAmount"));
									 s1.setApprovedAmount(rs1.getDouble("approvedAmount"));
									 s1.setClaimStatus(rs1.getString("status"));
									 s1.setAction(rs1.getString("action"));
									 s1.setEscalation_Report(rs1.getString("Escalation_Report"));
									 clist.add(s1); 
								 }
								 for( ClaimSearch s:clist)
								 {
									 System.out.println(s.getMediAssistClaimNo());
								 }
							
								 con.commit();}
								 else if(claimType.equals("hospitalization"))
								 {
								 ps5=con.prepareStatement("SELECT h.claim_Id,h.claimedDate,b.BeneficiaryName,b.Relation,h.totalClaimAmount, " +
									 		"h.approvedAmount,h.status,h.action,h.Escalation_Report " +
									 		"FROM P1_BENEFICIARY b, P1_Hospitalization_CLAIMS h " +
									 			"where b.HEALTHINSURANCEID=h.HEALTHINSURANCEID  " +
									 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
										 ps5.setString(1,policyYear);
										
									 		 rs2=ps5.executeQuery();
									 while(rs2.next())
									 { 
										 ClaimSearch s2=new ClaimSearch();
								 		 s2.setClaimType("Hospitalization Claim");
										 s2.setMediAssistClaimNo(rs2.getString(1));
										 s2.setClaimRaisedOn(rs2.getDate(2));
										 s2.setPatientName(rs2.getString(3));
										 s2.setRelation(rs2.getString(4));
										 s2.setClaimAmount(rs2.getDouble(5));
										 s2.setApprovedAmount(rs2.getDouble(6));
										 s2.setClaimStatus(rs2.getString(7));
										 s2.setAction(rs2.getString(8));
										 s2.setEscalation_Report(rs2.getString(9));
										 clist.add(s2);
										  
									 }con.commit();
								 }
							 }
								 catch (Exception e) 
									{
									e.printStackTrace();
									}
								finally
									{
									DBUtil.closeConnection(ps4);	
									DBUtil.closeConnection(ps5);	
									DBUtil.closeConnection(rs1);	
									DBUtil.closeConnection(rs2);	
									DBUtil.closeConnection(con);
									}
									return clist;
								 }
						 ArrayList<ClaimSearch> searchAll(String claimType, String policyYear, String relation)
						 {
							 ArrayList<ClaimSearch> clist=new ArrayList<ClaimSearch>();
					 try
					 {
						 if(claimType.equals("domiciliary"))
						 {
						 con=DBUtil.getconnection();
							 ps4=con.prepareStatement("SELECT d.claimId,d.claimedDate,b.BeneficiaryName,b.Relation,d.totalClaimAmount, " +
						 		"d.approvedAmount,d.status,d.action,d.Escalation_Report " +
						 		"FROM P1_BENEFICIARY b, P1_DOMICILIARY_CLAIMS d " +
						 			"where b.HEALTHINSURANCEID=d.HEALTHINSURANCEID  " +
						 			"AND b.relation=?"+
						 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
							 ps4.setString(1,relation);
							 ps4.setString(2,policyYear);
							
						 		 rs1=ps4.executeQuery();
						 while(rs1.next())
						 { 
							 ClaimSearch s1=new ClaimSearch();
							 s1.setClaimType("Domiciliary Claim");
							 s1.setMediAssistClaimNo(rs1.getString("claimId"));
							 s1.setClaimRaisedOn(rs1.getDate("claimedDate"));
							 s1.setPatientName(rs1.getString("BeneficiaryName"));
							 s1.setRelation(rs1.getString("Relation"));
							 s1.setClaimAmount(rs1.getDouble("totalClaimAmount"));
							 s1.setApprovedAmount(rs1.getDouble("approvedAmount"));
							 s1.setClaimStatus(rs1.getString("status"));
							 s1.setAction(rs1.getString("action"));
							 s1.setEscalation_Report(rs1.getString("Escalation_Report"));
							 clist.add(s1); 
						 }
						 con.commit();}
						 else if(claimType.equals("hospitalization"))
						 {
						 ps5=con.prepareStatement("SELECT h.claim_Id,h.claimedDate,b.BeneficiaryName,b.Relation,h.totalClaimAmount, " +
							 		"h.approvedAmount,h.status,h.action,h.Escalation_Report " +
							 		"FROM P1_BENEFICIARY b, P1_Hospitalization_CLAIMS h " +
							 			"where b.HEALTHINSURANCEID=h.HEALTHINSURANCEID " +
							 			"AND b.relation=? " +
							 			"AND EXTRACT (YEAR from b.POLICYSTARTDATE)=?");
						 		ps5.setString(1,relation);
								 ps5.setString(2,policyYear);
								
							 		 rs2=ps5.executeQuery();
							 while(rs2.next())
							 { 
								 ClaimSearch s2=new ClaimSearch();
						 		 s2.setClaimType("Hospitalization Claim");
								 s2.setMediAssistClaimNo(rs2.getString(1));
								 s2.setClaimRaisedOn(rs2.getDate(2));
								 s2.setPatientName(rs2.getString(3));
								 s2.setRelation(rs2.getString(4));
								 s2.setClaimAmount(rs2.getDouble(5));
								 s2.setApprovedAmount(rs2.getDouble(6));
								 s2.setClaimStatus(rs2.getString(7));
								 s2.setAction(rs2.getString(8));
								 s2.setEscalation_Report(rs2.getString(9));
								 clist.add(s2); 		 
								 	
							 }con.commit();
						 }
					 }
						 catch (Exception e) 
							{
							e.printStackTrace();
							}
						finally
							{
							DBUtil.closeConnection(ps4);	
							DBUtil.closeConnection(ps5);	
							DBUtil.closeConnection(rs1);	
							DBUtil.closeConnection(rs2);	
							DBUtil.closeConnection(con);
							}
							return clist;
						 }
	
	 


	// ////// START OF AUTO-GENERATION
	public Beneficiary searchDependent(int i, String name) {
		// TODO Auto-generated method stub
		Beneficiary beneficiary = new Beneficiary();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT HEALTHINSURANCEID FROM P1_BENEFICIARY WHERE EMPLOYEEID=? and BENEFICIARYNAME=?");

			ps.setInt(1, i);
			ps.setString(2, name);
			ResultSet rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");
				String healthinsuranceid = rs.getString(1);

				beneficiary.setHealthInsuranceId(healthinsuranceid);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return beneficiary;
	}

	public Beneficiary searchDependent(int empId) {
		// TODO Auto-generated method stub
		Beneficiary beneficiary = new Beneficiary();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT HEALTHINSURANCEID FROM P1_BENEFICIARY WHERE EMPLOYEEID=?  AND RELATION='SELF'");
			System.out.println(empId);
			ps.setInt(1, empId);
			ResultSet rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");
				String healthinsuranceid = rs.getString(1);

				beneficiary.setHealthInsuranceId(healthinsuranceid);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return beneficiary;
	}

	public ArrayList<String> searchDependentName(int empId) {
		// TODO Auto-generated method stub
		Beneficiary beneficiary = new Beneficiary();
		ArrayList<String> namebeneficiary = new ArrayList<String>();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT BENEFICIARYNAME FROM P1_BENEFICIARY WHERE EMPLOYEEID=?  AND RELATION<>'SELF'");
			System.out.println(empId);
			ps.setInt(1, empId);
			ResultSet rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");

				String name = rs.getString(1);

				namebeneficiary.add(name);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return namebeneficiary;
	}

	public ArrayList<String> getStates() {
		ArrayList<String> stlist = new ArrayList<String>();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT STATENAME FROM P1_STATE");
			ResultSet rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");

				String stname = rs.getString(1);

				stlist.add(stname);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return stlist;
	}

	public ArrayList<String> getCities(String stname) {
		ArrayList<String> ctlist = new ArrayList<String>();
		try {
			String stid = null;
			con = DBUtil.getconnection();
			System.out.println("STATE:" + stname);
			ps = con.prepareStatement("SELECT STATEID FROM P1_STATE WHERE STATENAME=?");
			ps.setString(1, stname);
			rs1 = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs1.next()) {
				System.out.println("its inside while ");
				stid = rs1.getString(1);
			}
			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT CITYNAME FROM P1_CITY WHERE STATEID=?");
			ps.setString(1, stid);
			rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");

				String ctname = rs.getString(1);

				ctlist.add(ctname);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return ctlist;
	}

	public ArrayList<String> getHospitals(String stname, String ctname) {
		ArrayList<String> hplist = new ArrayList<String>();
		try {

			con = DBUtil.getconnection();
			ps = con.prepareStatement("SELECT HOSPITALNAME FROM P1_HOSPITAL WHERE STATE=? AND CITY=?");
			ps.setString(1, stname);
			ps.setString(2, ctname);
			rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");

				String hpname = rs.getString(1);

				hplist.add(hpname);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return hplist;
	}

	public ArrayList<String> getSearchHospital(String hospitalname) {
		// TODO Auto-generated method stub
		ArrayList<String> stlist = new ArrayList<String>();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("select HOSPITALNAME from p1_hospital");
			ResultSet rs = ps.executeQuery();
			System.out.println("its outside while ");
			while (rs.next()) {
				System.out.println("its inside while ");

				String hosname = rs.getString(1);

				stlist.add(hosname);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured");
		} finally {

			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return stlist;
	}

	// ////// END OF AUTO-GENERATION

	
	public Employee loginEmployee(Employee eb) throws  SQLException
	{
		Employee e=new Employee();
	
		try{
			
			con=DBUtil.getconnection();

			if(con!=null)
			{
				stm = con.createStatement();
				stm1= con.createStatement();


				long x=eb.getEmployeeId();
				String y=eb.getPassword();

				ResultSet rs = stm.executeQuery("select EmployeeId,password from P1_employee where employeeId='"+x+"' and password='"+y+"'");

				while(rs.next())
				{

					status=true;
				}
				
				ResultSet rs1=stm1.executeQuery("select status from P1_Beneficiary where employeeId='"+x+"' and relation='SELF'");
				String currentStatus="";
				while(rs1.next())
				{
					currentStatus=rs1.getString(1);
					//System.out.println(currentStatus);
					
				}
				
				
				if(currentStatus.equalsIgnoreCase("approved"))
				{
					if(status)
					{
						status=true;
						ResultSet rs2 = stm.executeQuery("select * from P1_employee where employeeId='"+x+"'");

						while(rs2.next())
						{
							e.setEmployeeId(rs2.getLong(1));
							e.setEmployeeName(rs2.getString(2));
							
						}
					}
					
				}
				else
				{
					status=false;
					e=null;
				}

			}}
		catch (SQLException e1)
		{
			e1.printStackTrace();

		}

		finally
		{
			DBUtil.closeConnection(con);
			if(stm!=null)
				stm.close();

		}
		
			return e;
	
		
	}

	public String addBeneficiary(Beneficiary b)	 throws  SQLException

	{

		PreparedStatement ps1=null;
		Statement s=null;
		PreparedStatement ps2=null;
		ResultSet rs=null;
		ResultSet rs1=null;



		String HIid="";
		String p="PENDING";

		String dummy="null";

		try{
			Connection con=DBUtil.getconnection();
			s=con.createStatement();
			rs1=s.executeQuery("select systimestamp from DUAL");

			Timestamp time=null;
			while(rs1.next())
			{
				time=rs1.getTimestamp(1);
			}
			String n=null;

			ps1=con.prepareStatement("insert into P1_Beneficiary(HealthInsuranceId,EmployeeId,BeneficiaryName," +
					"Relation,DateOfBirth,PolicyNo," +
					"PolicyStartDate,PolicyPeriod,TotalSumInsured,Status,TPAID," +
					"RegisteredTime,ApprovalTime,Reason,LastChangeDate,Gender)" +
					" values(P1_HEALTHINSURANCEID_Sequence.nextVal,?,?,?,TO_DATE(?,'yyyy/MM/dd'),P1_POLICY_Sequence.nextval,TO_DATE(?,'yyyy/MM/dd'),?,?,?,?,?,?,?,?,?)");

			ps1.setLong(1,b.getEmployeeId());
			ps1.setString(2,b.getBeneficiaryName());
			ps1.setString(3,b.getRelation());
			ps1.setString(4,b.getDateOfBirth());						
			ps1.setString(5,b.getPolicyStartDate());
			ps1.setLong(6,b.getPolicyPeriod());
			ps1.setDouble(7,b.getTotalSumInsured());
			ps1.setString(8,p);
			ps1.setString(9,n);
			ps1.setTimestamp(10, time);
			ps1.setTimestamp(11, null);	
			ps1.setString(12,dummy);
			ps1.setTimestamp(13, time);


			String gen="M";
			if(b.getGender().equalsIgnoreCase("f"))
			{
				gen="F";
			}

			ps1.setString(14,gen);
			ps1.executeUpdate();
			con.commit();
			ps2=con.prepareStatement("select P1_HEALTHINSURANCEID_Sequence.currval from dual");
			rs=ps2.executeQuery();
			while(rs.next())
			{
				HIid=rs.getString(1);
			}

		}catch(SQLException e)
		{
			e.printStackTrace();
		}

		DBUtil.closeConnection(con);
		System.out.println(HIid);
		return HIid;

	}
	public ArrayList<Beneficiary> viewBeneficiaries(long empid) {
		ArrayList<Beneficiary> b = new ArrayList<Beneficiary>();
		try {

			con = DBUtil.getconnection();
			ps = con.prepareStatement("select HEALTHINSURANCEID,EMPLOYEEID,BENEFICIARYNAME,RELATION,DATEOFBIRTH," +
					"POLICYNO,POLICYSTARTDATE,POLICYPERIOD,TOTALSUMINSURED,GENDER " +
					"from P1_Beneficiary where employeeid=? AND status= 'APPROVED' AND RELATION NOT LIKE 'SELF'");
			ps.setLong(1, empid);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Beneficiary b1 = new Beneficiary();
				b1.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
				b1.setEmployeeId(rs.getInt("EMPLOYEEID"));
				b1.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
				b1.setRelation(rs.getString("RELATION"));
				String date1=rs.getString("DATEOFBIRTH");
				String date2=date1.substring(0,10);
				b1.setDateOfBirth(date2);
				b1.setGender(rs.getString("GENDER"));
				b1.setPolicyNo(rs.getLong("POLICYNO"));
				date1=rs.getString("POLICYSTARTDATE");
				date2=date1.substring(0,10);

				b1.setPolicyStartDate(date2);
				b1.setPolicyPeriod(rs.getInt("POLICYPERIOD"));
				b1.setTotalSumInsured(rs.getLong("TOTALSUMINSURED"));
				//b1.setStatus(rs.getString(11));
				//b1.setTPAID(rs.getString(12));
				//b1.setApprovetime(rs.getTimestamp(13));
				//b1.setReason(rs.getString(14));
				//b1.setLastUpdateDateTime(rs.getTimestamp(15));
				b.add(b1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b;
	}

	public Beneficiary updateSelectedBeneficiary(String hiid) {
		Beneficiary b1 = new Beneficiary();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("select HEALTHINSURANCEID,EMPLOYEEID,BENEFICIARYNAME,RELATION,DATEOFBIRTH," +
					"POLICYNO,POLICYSTARTDATE,POLICYPERIOD,TOTALSUMINSURED,GENDER " +
					"from P1_Beneficiary where HealthInsuranceId=?");
			ps.setString(1, hiid);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				b1.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
				b1.setEmployeeId(rs.getInt("EMPLOYEEID"));
				b1.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
				b1.setRelation(rs.getString("RELATION"));
				String date1=rs.getString("DATEOFBIRTH");
				String date2=date1.substring(0,10);
				b1.setDateOfBirth(date2);
				//b1.setDateOfBirth(rs.getString("DATEOFBIRTH"));
				b1.setGender(rs.getString("GENDER"));
				b1.setPolicyNo(rs.getLong("POLICYNO"));
				date1=rs.getString("POLICYSTARTDATE");
				date2=date1.substring(0,10);
				b1.setPolicyStartDate(date2);
				b1.setPolicyPeriod(rs.getInt("POLICYPERIOD"));
				b1.setTotalSumInsured(rs.getLong("TOTALSUMINSURED"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b1;
	}


	public boolean deleteSelectedBeneficiary(String hiid) {
		boolean b=false;
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("update p1_Beneficiary set status='DELETE' where HealthInsuranceId=?");
			ps.setString(1, hiid);
			int i = ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b;
	}


	public boolean updateSelectedBeneficiaryDetails(Beneficiary b1) {
		boolean b=false;
		try {
			con = DBUtil.getconnection();
			String DateOfBirth=b1.getDateOfBirth();
			String HIid=b1.getHealthInsuranceId();
			long Policyperiod=b1.getPolicyNo();

			ps = con.prepareStatement("update p1_Beneficiary set DATEOFBIRTH=TO_DATE(?,'yyyy/MM/dd'),POLICYPERIOD=? where HealthInsuranceId=?");
			ps.setString(1, DateOfBirth);
			ps.setLong(2,Policyperiod);
			ps.setString(3, HIid);
			int i = ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b;
	}

	public String addEmployeeDetails(Employee employee, Beneficiary beneficiary)
	{
		// empseqname sequence is for employee ids and healthseqname sequence is for health insurance ids
		String healthInsuranceId="";
		int isworking=0;
		//Queries are in the format:
		//INSERT INTO table_name (column1,column2,column3,...)
		//VALUES (value1,value2,value3,...);

		String insertEmpQuery="INSERT INTO P1_EMPLOYEE (EmployeeId, EmployeeName, E_mail, AlternateE_mail, " +
				"PhoneNumber, AlternateMobileNumber, Address," +
				"Password, BankAccountNumber, NameOfBank, IFSCCode" +
				" ) VALUES(?,?,?,?,?,?,?,?,?,?,?)";

		try
		{
			Connection con=DBUtil.getconnection();
			PreparedStatement ps1=null;
			ps1=con.prepareStatement(insertEmpQuery);
			ps1.setLong(1, employee.getEmployeeId());
			ps1.setString(2,employee.getEmployeeName());
			ps1.setString(3, employee.getEmail());
			ps1.setString(4,employee.getAlternateEmail());
			ps1.setLong(5,employee.getPhoneNumber() );
			ps1.setLong(6,employee.getAlternateMobileNo());
			ps1.setString(7, employee.getAddress());
			ps1.setString(8, employee.getPassword());
			ps1.setLong(9, employee.getBankAccountNo());
			ps1.setString(10, employee.getNameOfBank());
			ps1.setString(11, employee.getIFSCCode());
			isworking =ps1.executeUpdate();	//test in local	
			healthInsuranceId= addBeneficiary(beneficiary);

		} 

		catch (SQLException e)
		{
			e.printStackTrace();
		}

		return healthInsuranceId;
	}


	public HashMap<String,Object> viewEmployeeDetails(long empid)
	{	System.out.println(empid);
		//change table names before uploading on svn
		String selectEmpQuery="SELECT * FROM P1_EMPLOYEE WHERE EMPLOYEEID="+empid;
		String selectBenQuery="SELECT * FROM P1_BENEFICIARY WHERE EMPLOYEEID="+empid+" AND RELATION IN('SELF', 'self','Self')";

		HashMap<String,Object> map=new HashMap<String,Object>();
		Beneficiary beneficiary=new Beneficiary();
		Employee employee= new Employee();

		try
		{
			con=DBUtil.getconnection();
			ps=con.prepareStatement(selectEmpQuery);
			rs=ps.executeQuery();
			while(rs.next())
			{
				employee.setEmployeeId(rs.getLong("EMPLOYEEID"));
				employee.setEmployeeName(rs.getString("EMPLOYEENAME"));
				employee.setEmail(rs.getString("E_MAIL"));
				employee.setAlternateEmail(rs.getString("ALTERNATEE_MAIL"));
				employee.setPhoneNumber(rs.getLong("PHONENUMBER"));
				employee.setAlternateMobileNo(rs.getLong("ALTERNATEMOBILENUMBER"));
				employee.setAddress(rs.getString("ADDRESS"));
				employee.setPassword(rs.getString("PASSWORD"));
				employee.setBankAccountNo(rs.getLong("BANKACCOUNTNUMBER"));
				employee.setNameOfBank(rs.getString("NAMEOFBANK"));
				employee.setIFSCCode(rs.getString("IFSCCODE"));				
			}
			ps=con.prepareStatement(selectBenQuery);
			rs=ps.executeQuery();
			while(rs.next())
			{
				beneficiary.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
				beneficiary.setEmployeeId(rs.getInt("EMPLOYEEID"));
				beneficiary.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
				beneficiary.setRelation(rs.getString("RELATION"));
				
				String date1=rs.getString("DATEOFBIRTH");
				String date2=date1.substring(0,10);
				//b1.setDateOfBirth(date2);
				
				beneficiary.setDateOfBirth(date2);
				beneficiary.setPolicyNo(rs.getLong("POLICYNO"));
				 date1=rs.getString("POLICYSTARTDATE");
				 date2=date1.substring(0,10);
				beneficiary.setPolicyStartDate(date2);
				beneficiary.setPolicyPeriod(rs.getInt("POLICYPERIOD"));
				beneficiary.setTotalSumInsured(rs.getInt("TOTALSUMINSURED"));
				beneficiary.setStatus(rs.getString("STATUS"));
				beneficiary.setTPAID(rs.getString("TPAID"));
				beneficiary.setRegisteredTime(rs.getTimestamp("REGISTEREDTIME"));
				beneficiary.setApprovetime(rs.getTimestamp("APPROVALTIME"));
				beneficiary.setReason(rs.getString("REASON"));
				beneficiary.setLastUpdateDateTime(rs.getTimestamp("LASTCHANGEDATE"));
				beneficiary.setGender(rs.getString("GENDER"));
			}
			map.put("Employee",employee);
			map.put("Beneficiary",beneficiary);		
			System.out.println("dao test"+empid);
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return map;
	}

	public boolean deleteEmployeeDetails(long empId){
		int result=0;
		boolean flag=false;
		String updateStatusQuery="UPDATE P1_BENEFICIARY SET Status='DELETE' where EmployeeId=? ";
		try{
			con=DBUtil.getconnection();
			ps=con.prepareStatement(updateStatusQuery);
			System.out.println("inside dao class delete method empid: "+empId);
			ps.setLong(1,empId);
			//ps.setString(2, beneficiary.getHealthInsuranceId());
			result = ps.executeUpdate();
			if(result>=1){
				flag=true;
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	public boolean updateEmployeeDetails(Employee employee, Beneficiary beneficiary){
		//DateFormat df = new SimpleDateFormat("dd/MM/yyyy");

		boolean flag= false;
		int result1, result2=0;
		//String updateBeneficiaryQuery ="UPDATE p1_BENEFICIARY SET DateOfBirth=TO_DATE(?,'yyyy/MM/dd'), Policyperiod=? WHERE EmployeeId=? and Relation in('SELF', 'self', 'Self')";
		String updateEmployeeQuery ="UPDATE p1_EMPLOYEE SET E_mail=?, AlternateE_mail=?, PhoneNumber=?, AlternateMobileNumber=?, Address=?, Password=?, BankAccountNumber=?, NameOfbank=?, IFSCCode=? WHERE EmployeeId=?";
		try
		{			
			con=DBUtil.getconnection();
			PreparedStatement ps=null;
			//ps1=con.prepareStatement(updateBeneficiaryQuery);
			//ps1.setString(1, beneficiary.getDateOfBirth());
			//ps1.setInt(2, beneficiary.getPolicyPeriod());
			//ps1.setDouble(3,beneficiary.getTotalSumInsured());
			//ps1.setInt(4, beneficiary.getEmployeeId());
			//result1=ps1.executeUpdate();
			
			//System.out.println(beneficiary.getDateOfBirth());
			ps = con.prepareStatement("update p1_Beneficiary set DATEOFBIRTH=TO_DATE(?,'yyyy/MM/dd'),POLICYPERIOD=? where EmployeeId=? and Relation in('SELF', 'self', 'Self')");
			
			
			ps.setString(1,beneficiary.getDateOfBirth());
			ps.setLong(2, beneficiary.getPolicyPeriod());
			ps.setLong(3,beneficiary.getEmployeeId());
			System.out.println(beneficiary.getEmployeeId());
			result1=ps.executeUpdate();
			System.out.println("Table beneficiary updated "+result1+" employee");
			PreparedStatement ps2=null;
			ps2=con.prepareStatement(updateEmployeeQuery);
			ps2.setString(1, employee.getEmail());
			ps2.setString(2,employee.getAlternateEmail());
			ps2.setLong(3,employee.getPhoneNumber() );
			ps2.setLong(4,employee.getAlternateMobileNo());
			ps2.setString(5, employee.getAddress());
			ps2.setString(6, employee.getPassword());
			ps2.setLong(7, employee.getBankAccountNo());
			ps2.setString(8, employee.getNameOfBank());
			ps2.setString(9, employee.getIFSCCode());
			ps2.setLong(10,beneficiary.getEmployeeId());
			result2=ps2.executeUpdate();
			System.out.println("Table employee updated "+result2+" employee(s)");
			
			if(result1==1 && result2==1){
				flag=true;
			}


		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	public boolean login(TPABean t) throws Exception
	{
		System.out.println("DAO1");
		Connection con = null;
		con = DBUtil.getconnection();
		boolean status=false;
		if(con!=null)
		{
			Statement stm = con.createStatement();
			System.out.println("DAO2");

			try
			{
				String x=t.getTPAuserid();
				String y=t.getPassword();
				System.out.println(x);
				System.out.println(y);
				ResultSet rs = stm.executeQuery("select * from prema where userid='"+x+"' and password='"+y+"'");

				while(rs.next())
				{
					//String s=null;
					//s=rs.getString(2);
					System.out.println("dao");
					//	System.out.println(s);
					status=true;
				} 
			}

			catch (SQLException e)
			{
				e.printStackTrace();

			}

			finally
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();

			}
		}
		return status;
	}

	public boolean pendingRequest() throws SQLException
	{
		Connection con =null;
		con= DBUtil.getconnection();
		if(con!=null)
		{
			Statement stm = con.createStatement();
			try
			{
				ResultSet rs = stm.executeQuery("Select bid from vnr where status='pending'");
				while(rs.next())
				{
					System.out.println(rs.getString(1));	
				}
			} 

			catch (SQLException e) 
			{
				return false;
			}

			finally

			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}

		else
			return false;
		return false;
	}

	public boolean RequestApproval(String  hid ) throws SQLException {
		System.out.println("request");
		Connection con =null;
		con= DBUtil.getconnection();

		if(con!=null)
		{
			Statement stm = con.createStatement();
			try
			{
				ResultSet rs = stm.executeQuery("UPDATE VNR SET status='approved' WHERE bid='101'");
				while(rs.next())
				{
					System.out.println("approved ");	
				}
			} 

			catch (SQLException e) 
			{
				return false;
			}

			finally

			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}

		else
			return false;
		return false;
	}

	public boolean RequestDecline(String  hid ) throws SQLException {
		System.out.println("decline");
		Connection con =null;
		con= DBUtil.getconnection();

		if(con!=null)
		{
			Statement stm = con.createStatement();
			try
			{
				ResultSet rs = stm.executeQuery("UPDATE VNR SET status='declined' WHERE bid='103'");
				while(rs.next())
				{
					System.out.println("declined ");	
				}
			} 

			catch (SQLException e) 
			{
				return false;
			}

			finally

			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}

		else
			return false;
		return false;
	}



	public ArrayList<Beneficiary> GenerateECard(long id) throws SQLException {
		System.out.println("E-Card DAO");
		Connection con =null;
		con= DBUtil.getconnection();
		
		ArrayList<Beneficiary> ecard = new ArrayList<Beneficiary>();
		
		
		if(con!=null)
	{
			Statement stm = con.createStatement();
			try
		{
				ResultSet rs = stm.executeQuery("SELECT POLICYNO,BENEFICIARYNAME,HEALTHINSURANCEID,EMPLOYEEID,RELATION,DATEOFBIRTH FROM P1_BENEFICIARY WHERE Employeeid="+id+" AND STATUS='APPROVED'");

				while(rs.next())
			{
					Beneficiary ben =new Beneficiary();
					
					ben.setPolicyNo(rs.getLong("POLICYNO"));
					ben.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
					ben.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
					ben.setEmployeeId(rs.getLong("EMPLOYEEID"));
					ben.setRelation(rs.getString("RELATION"));
					ben.setDateOfBirth(rs.getString("DATEOFBIRTH"));
					
					ecard.add(ben);
					
					System.out.println(rs.getLong("POLICYNO"));
					System.out.println(rs.getString("BENEFICIARYNAME"));
					
				} 
			}
				catch (SQLException e) 
				{
				e.printStackTrace();
				}

				finally
	
				{
				DBUtil.closeConnection(con);
				if(stm!=null)
				stm.close();
				}
		}
		else
		{
			ecard=null;
		}
		return ecard;
	}

	



public ArrayList<Beneficiary> viewDetailsByEmpid(long empid) {
	ArrayList<Beneficiary> b = new ArrayList<Beneficiary>();
	try {

		con = DBUtil.getconnection();
		ps = con.prepareStatement("select HEALTHINSURANCEID,EMPLOYEEID,BENEFICIARYNAME,RELATION, " +
				"POLICYNO, TOTALSUMINSURED " +
				"from P1_Beneficiary where employeeid=? AND status= 'APPROVED'");
		ps.setLong(1, empid);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Beneficiary b1 = new Beneficiary();
			b1.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
			b1.setEmployeeId(rs.getInt("EMPLOYEEID"));
			b1.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
			b1.setRelation(rs.getString("RELATION"));
			//String date1=rs.getString("DATEOFBIRTH");
			//String date2=date1.substring(0,10);
			//b1.setDateOfBirth(date2);
			//b1.setGender(rs.getString("GENDER"));
			b1.setPolicyNo(rs.getLong("POLICYNO"));
			//date1=rs.getString("POLICYSTARTDATE");
			//date2=date1.substring(0,10);

			//b1.setPolicyStartDate(date2);
			//b1.setPolicyPeriod(rs.getInt("POLICYPERIOD"));
			b1.setTotalSumInsured(rs.getLong("TOTALSUMINSURED"));
			//b1.setStatus(rs.getString(11));
			//b1.setTPAID(rs.getString(12));
			//b1.setApprovetime(rs.getTimestamp(13));
			//b1.setReason(rs.getString(14));
			//b1.setLastUpdateDateTime(rs.getTimestamp(15));
			b.add(b1);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBUtil.closeConnection(con);
		DBUtil.closeConnection(ps);
		DBUtil.closeConnection(rs);
	}
	return b;
}

public Beneficiary payPremiumSelectedBeneficiary(String hiid) {
	Beneficiary b1 = new Beneficiary();
	try {
		con = DBUtil.getconnection();
		ps = con.prepareStatement("select HEALTHINSURANCEID,EMPLOYEEID,BENEFICIARYNAME,RELATION," +
				"POLICYNO,TOTALSUMINSURED " +
				"from P1_Beneficiary where HealthInsuranceId=?");
		ps.setString(1, hiid);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			b1.setHealthInsuranceId(rs.getString("HEALTHINSURANCEID"));
			b1.setEmployeeId(rs.getInt("EMPLOYEEID"));
			b1.setBeneficiaryName(rs.getString("BENEFICIARYNAME"));
			b1.setRelation(rs.getString("RELATION"));
			//String date1=rs.getString("DATEOFBIRTH");
			//String date2=date1.substring(0,10);
			//b1.setDateOfBirth(date2);
			//b1.setDateOfBirth(rs.getString("DATEOFBIRTH"));
			//b1.setGender(rs.getString("GENDER"));
			b1.setPolicyNo(rs.getLong("POLICYNO"));
			//date1=rs.getString("POLICYSTARTDATE");
			//date2=date1.substring(0,10);
			//b1.setPolicyStartDate(date2);
			//b1.setPolicyPeriod(rs.getInt("POLICYPERIOD"));
			b1.setTotalSumInsured(rs.getLong("TOTALSUMINSURED"));

		}
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DBUtil.closeConnection(con);
		DBUtil.closeConnection(ps);
		DBUtil.closeConnection(rs);
	}
	return b1;
}
	
	
	
	
	
	
	
	
	
	/*
	 * SEARCH HOSPITAL
	 */
	public ArrayList<Hospital> searchHospital(String searchHospitalByName) {
		ArrayList<Hospital> c1 = new ArrayList<Hospital>();
		System.out.println(searchHospitalByName);
		try {
			con = DBUtil.getconnection();
			System.out.println(searchHospitalByName);
			String query = "select * from p1_hospital where HospitalName=?";
			ps = con.prepareStatement(query);
			ps.setString(1, searchHospitalByName);
			rs = ps.executeQuery();

			while (rs.next()) {
				System.out.println(searchHospitalByName);
				Hospital hospital = new Hospital();
				hospital.setHospitalId(rs.getString("HOSPITALID"));
				hospital.setHospitalName(rs.getString("HOSPITALNAME"));
				hospital.setAddress(rs.getString("ADDRESS"));
				hospital.setCityName(rs.getString("CITY"));
				hospital.setStateName(rs.getString("STATE"));
				hospital.setPinCode(Integer.parseInt(rs.getString("PINCODE")));
				hospital.setSTDCode(Integer.parseInt(rs.getString("STDCODE")));
				hospital.setPhoneNumber(Long.parseLong(rs
						.getString("PHONENUMBER")));
				c1.add(hospital);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return c1;

	}

	public ArrayList<Hospital> searchHospital(int searchHospitalByPincode) {
		ArrayList<Hospital> c1 = new ArrayList<Hospital>();
		try {
			System.out.println("dao1");
			con = DBUtil.getconnection();
			String query = "select * from p1_hospital where PINCODE=?";

			System.out.println("dao11");
			ps = con.prepareStatement(query);
			ps.setInt(1, searchHospitalByPincode);
			rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println("dao114");
				Hospital hospital = new Hospital();
				hospital.setHospitalId(rs.getString("HOSPITALID"));
				hospital.setHospitalName(rs.getString("HOSPITALNAME"));
				hospital.setAddress(rs.getString("ADDRESS"));
				hospital.setCityName(rs.getString("CITY"));
				hospital.setStateName(rs.getString("STATE"));
				hospital.setPinCode(Integer.parseInt(rs.getString("PINCODE")));
				hospital.setSTDCode(Integer.parseInt(rs.getString("STDCODE")));
				hospital.setPhoneNumber(Long.parseLong(rs
						.getString("PHONENUMBER")));

				c1.add(hospital);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return c1;

	}

	public ArrayList<Hospital> searchHospital(String searchHospitalByState,
			String searchHospitalByCity) {
		ArrayList<Hospital> c1 = new ArrayList<Hospital>();
		try {
			con = DBUtil.getconnection();
			String query = "select * from p1_hospital  where CITY=? and STATE=?";

			ps = con.prepareStatement(query);
			ps.setString(1, searchHospitalByCity);
			ps.setString(2, searchHospitalByState);
			rs = ps.executeQuery();
			while (rs.next()) {
				Hospital hospital = new Hospital();
				hospital.setHospitalId(rs.getString("HOSPITALID"));
				hospital.setHospitalName(rs.getString("HOSPITALNAME"));
				hospital.setAddress(rs.getString("ADDRESS"));
				hospital.setCityName(rs.getString("CITY"));
				hospital.setStateName(rs.getString("STATE"));
				hospital.setPinCode(Integer.parseInt(rs.getString("PINCODE")));
				hospital.setSTDCode(Integer.parseInt(rs.getString("STDCODE")));
				hospital.setPhoneNumber(Long.parseLong(rs
						.getString("PHONENUMBER")));

				c1.add(hospital);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return c1;
	}

	public ArrayList<Hospital> searchNetHospital() {
		System.out.println("net hosp array");
		ArrayList<Hospital> c1 = new ArrayList<Hospital>();
		try {
			con = DBUtil.getconnection();
			String query = "select * from p1_hospital";

			s = con.createStatement();
			rs = s.executeQuery(query);
			while (rs.next()) {

				System.out.println("net hosp array-while");
				Hospital hospital = new Hospital();
				hospital.setHospitalId(rs.getString("HOSPITALID"));
				hospital.setHospitalName(rs.getString("HOSPITALNAME"));
				hospital.setAddress(rs.getString("ADDRESS"));
				hospital.setCityName(rs.getString("CITY"));
				hospital.setStateName(rs.getString("STATE"));
				hospital.setPinCode(Integer.parseInt(rs.getString("PINCODE")));
				hospital.setSTDCode(Integer.parseInt(rs.getString("STDCODE")));
				hospital.setPhoneNumber(Long.parseLong(rs
						.getString("PHONENUMBER")));

				c1.add(hospital);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);

		}
		return c1;
	}

	/*
	 * VALUE ADDED SERVICES
	 */
	public int threeMonthsValidation(ValueAddedService vas) {
		String Hid = "";
		int days = -1;
		System.out.println("Assign: " + days);
		String s = "";
		s = vas.getHealthInsuranceID();
		System.out.println("DAO : " + s);
		System.out.println("Assign 1: " + days);
		try {
			con = DBUtil.getconnection();

			ps = con.prepareStatement("SELECT VALUEADDEDSERVICEID "
					+ "FROM VALUE_ADDED_SERVICE_983430 WHERE HEALTHINSURANCEID='"
					+ s + "'");
			rs = ps.executeQuery();
			if (!rs.next()) {
				System.out.println("Assign 2: " + days);
				days = -2;
				System.out.println("Assign 2-2: " + days);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Assign 3: " + days);
		if (days == -1) {
			try {
				ps = con.prepareStatement("SELECT extract(day FROM trunc(sysdate) - max(vasregisteredtime)) FROM VALUE_ADDED_SERVICE_983430 WHERE HEALTHINSURANCEID='"
						+ s + "'");
				rs = ps.executeQuery();
				while (rs.next()) {
					System.out.println("Assign 4: " + days);
					days = rs.getInt(1);
					System.out.println("Assign 5: " + days);

				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				DBUtil.closeConnection(con);
				DBUtil.closeConnection(ps);
				DBUtil.closeConnection(rs);
			}
		}

		else {

		}
		System.out.println("Assign 6: " + days);
		return days;

	}

	

	public String registerEmployeeVAS(ValueAddedService vas) {
		String hospitalId = "";
		String vasId = "";
		try {
			con = DBUtil.getconnection();
			System.out.println(vas.getHospitalName());
			ps = con.prepareStatement("select HospitalId from p1_hospital where HospitalName= ? and City=? and State=?");
			System.out.println("Stmt");
			System.out.println("Hospital Name:"+vas.getHospitalName()+"::STATE::"+vas.getState()+"::City::"+vas.getCity());
			ps.setString(1, vas.getHospitalName());
			ps.setString(2,vas.getCity());
			ps.setString(3,vas.getState());
			rs = ps.executeQuery();
			System.out.println("After query");

			while (rs.next()) {
				hospitalId = rs.getString(1);
			}

			String preferredDateTime = vas.getPreferredDate() + " "
					+ vas.getPrefferedTime();

			ps = con.prepareStatement("insert into Value_Added_Service_983430 values(Value_Added_Service_Seq.nextval,?,?,to_date(?,'yyyy-mm-dd hh24:mi:ss'),?,'pending',NULL,sysdate,NULL,NULL)");
			ps.setString(1, vas.getAppointmentFor());

			ps.setString(2, vas.getHealthInsuranceID());

			ps.setString(3, preferredDateTime);

			ps.setString(4, hospitalId);

			ps.executeUpdate();
			ps = con.prepareStatement("SELECT Value_Added_Service_Seq.currval from Value_Added_Service_983430");
			rs = ps.executeQuery();

			while (rs.next()) {
				vasId = rs.getString(1);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return vasId;

	}

}