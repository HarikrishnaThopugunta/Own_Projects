package com.tcs.ilp.EHI_P1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.tcs.ilp.EHI_P1.bean.Beneficiary;
import com.tcs.ilp.EHI_P1.bean.DomiciliaryClaim;
import com.tcs.ilp.EHI_P1.bean.Hospital;
import com.tcs.ilp.EHI_P1.bean.HospitalizationClaim;
import com.tcs.ilp.EHI_P1.bean.TPABean;
import com.tcs.ilp.EHI_P1.bean.VAS;
import com.tcs.ilp.EHI_P1.service.TPAService;
import com.tcs.ilp.EHI_P1.service.tc1;
import com.tcs.ilp.EHI_P1.util.DBUtil;

public class TPADao {

	
	Date adate;
	Date sdate;
	
	static Connection con = null;
	static PreparedStatement ps = null;
	static PreparedStatement ps1 = null;
	static PreparedStatement ps2 = null;

	static final int BUSINESS_START_HOUR = 9; // 9 AM
	static final int BUSINESS_END_HOUR = 18; // 6 PM
	static final int WORKING_MINS_PER_DAY = 540; // Total Working Minutes per
													// day
	static final int MINUTES_PER_HOUR = 60;

	ResultSet rs = null;
	boolean tpaApprove, tpaDecline = false;
	TPABean tpaObject= new TPABean();
	
	
	
	

	public TPABean login(TPABean t) throws Exception
	{
	System.out.println("DAO1");
	Connection con = null;
	con = DBUtil.getconnection();
	TPABean status=null;
	
	tpaObject=t;
	if(con!=null)
	{
		Statement stm = con.createStatement();
		 System.out.println("DAO2");
		
		try
		{
			String x=t.getTPAuserid();
			String y=t.getPassword();
			System.out.println(x);
			System.out.println(y);
			ResultSet rs = stm.executeQuery("select * from prema where userid='"+x+"' and password='"+y+"'");
			
			while(rs.next())
			{
				System.out.println("dao");
			
				status=t;
		} 
		}
		
		catch (SQLException e)
		{
	e.printStackTrace();
			
		}
		
		finally
		{
			DBUtil.closeConnection(con);
			if(stm!=null)
				stm.close();
			
		}
		}
	return status;
	}

	public ArrayList<Beneficiary> pendingRequest() throws SQLException
	{
		ArrayList<Beneficiary> listPendingRequest = new ArrayList<Beneficiary>();
		Connection con =null;
		//Statement stm=null;
		con= DBUtil.getconnection();
		if(con!=null)
		{
			try {
			ps = con.prepareStatement("select HEALTHINSURANCEID,employeeid,status from P1_Beneficiary where STATUS='PENDING'");
			rs = ps.executeQuery();
			while (rs.next()) {
				Beneficiary beneficiaryobject = new Beneficiary();
				beneficiaryobject.setHealthInsuranceId(rs.getString(1));
				beneficiaryobject.setEmployeeId(rs.getLong(2));
				beneficiaryobject.setStatus(rs.getString("status"));
				listPendingRequest.add(beneficiaryobject);
			}
		}
		
			catch (Exception e)
			{
			e.printStackTrace();
		}

			finally {
				DBUtil.closeConnection(con);
				DBUtil.closeConnection(ps);
				DBUtil.closeConnection(rs);
			}
		}
		return listPendingRequest;

	}

//	View employee details for TPA
	
	public ArrayList<Beneficiary> viewDetailsOfEmployee() throws SQLException
	{
		ArrayList<Beneficiary> listPendingRequest = new ArrayList<Beneficiary>();
		Connection con =null;
		Statement stm=null;
		con= DBUtil.getconnection();
		if(con!=null)
		{
			try {
			ps = con.prepareStatement("select HEALTHINSURANCEID,EMPLOYEEID ,BENEFICIARYNAME  ,RELATION ,DATEOFBIRTH ,POLICYNO,POLICYSTARTDATE,POLICYPERIOD,TOTALSUMINSURED,STATUS,TPAID,REGISTEREDTIME,APPROVALTIME,REASON ,LASTCHANGEDATE,GENDER from P1_Beneficiary");
			rs = ps.executeQuery();
			
			
		
			System.out.println(rs);	
				
				
				while (rs.next()) 
				{
					
					
					Beneficiary beneficiaryobject = new Beneficiary();
					beneficiaryobject.setHealthInsuranceId(rs.getString(1));
					beneficiaryobject.setEmployeeId(rs.getInt(2));
					beneficiaryobject.setBeneficiaryName(rs.getString(3));
					beneficiaryobject.setRelation(rs.getString(4));
					//beneficiaryobject.setDateOfBirth(rs.getDate(5));
				
					beneficiaryobject.setPolicyNo(rs.getLong(6));
				/*	beneficiaryobject.setPolicyStartDate(rs.getDate(7));*/
					beneficiaryobject.setPolicyPeriod(rs.getInt(8));
					beneficiaryobject.setTotalSumInsured(rs.getLong(9));
					beneficiaryobject.setStatus(rs.getString(10));
					beneficiaryobject.setTPAID(rs.getString(11));
				/*	beneficiaryobject.setApproveTime(rs.getTimestamp(12));*/
					beneficiaryobject.setReason(rs.getString(14));
				/*	beneficiaryobject.setLastUpdateDateTime(rs.getTimestamp(14));*/
					beneficiaryobject.setGender(rs.getString(15));
					listPendingRequest.add(beneficiaryobject);
				
				}
				System.out.println("sizeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");

				System.out.println(listPendingRequest.size());
				
			
		}
			catch (Exception e)
			{
			e.printStackTrace();
		}

			finally
			
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}
		return listPendingRequest;

	}

// 	
	public boolean RequestApproval(String hiid) throws SQLException {
		int a=0;
		java.util.Date date = new java.util.Date();
		Timestamp tt=new Timestamp(date.getTime());
		System.out.println("request");
		Connection con =null;
		con= DBUtil.getconnection();
		System.out.println(hiid);
System.out.println(con);
		if(con!=null)
		{
			System.out.println(con);
			Statement stm = con.createStatement();
			
			try
			{          
				System.out.println("idiot");
			ResultSet rs = stm.executeQuery( "UPDATE p1_beneficiary SET status='APPROVED',tpaid='"+tpaObject.getTPAuserid()+"'"+" WHERE HealthInsuranceID='"+hiid+"'");
			/*ps.setTimestamp(1,tt);	
			
			PreparedStatement ps1 = con.prepareStatement("select approvaltime,registeredtime from p1_beneficiary where  HealthInsuranceID='"+hiid+"'" );
			rs=ps1.executeQuery();*/
			while(rs.next())
				{
				/*	adate=rs.getDate(1);
					sdate=rs.getDate(2);*/
	/*System.out.println();*/
					System.out.println("approved ");	
				}
				TPAService es=new TPAService();
				a=es.findTotalBusinessHours(adate, sdate);
			} 
			
			catch (SQLException e) 
			{
				return false;
			}
			
			finally
			
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}
		
		else
			return false;
		return false;
	}/////////////////////////////////////////////////////////////////////////
	
	public boolean Reason(String hiid,String reason) throws SQLException {
		boolean status=false;
		System.out.println("request");
		Connection con =null;
		con= DBUtil.getconnection();
		System.out.println(hiid);
		System.out.println(con);
		if(con!=null)
		{
			Statement stm = con.createStatement();
			
			try
			{          
				System.out.println("reason");
				PreparedStatement ps1 = con.prepareStatement("UPDATE p1_beneficiary SET reason=? WHERE HealthInsuranceID='"+hiid+"'");
				ps1.setString(1,reason);
			/*	ResultSet rs = ps1.executeQuery();*/
				int isworking=ps1.executeUpdate();
			
			System.out.println();
			
			/*ps.setTimestamp(1,tt);	
			
			PreparedStatement ps1 = con.prepareStatement("select approvaltime,registeredtime from p1_beneficiary where  HealthInsuranceID='"+hiid+"'" );
			rs=ps1.executeQuery();*/
			if(isworking==1)
			{
				status=true;
			System.out.println("reason entered ");
			}
			/*while(rs.next())
			{
				rs.getString();
				status=true;
					System.out.println("reason entered ");
					
				}*/
				
			} 
			
			catch (SQLException e) 
			{
			e.printStackTrace();
			}
			
			finally
			
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}
		
		
		return status;
	}

	
	
	
	
	
	
	
	
	
	
//////////////////////////////////////////////////////////////////////////////
	public boolean RequestDecline(String hiid ) throws SQLException {
		System.out.println("Decline");
		Connection con =null;
		con= DBUtil.getconnection();

		if(con!=null)
		{
			Statement stm = con.createStatement();
			try
			{
			ResultSet rs = stm.executeQuery("UPDATE p1_beneficiary SET status='DECLINED' WHERE HealthInsuranceID='"+hiid+"'");
				while(rs.next())
				{
				System.out.println("declined ");	
				}
			} 
			
			catch (SQLException e) 
			{
				return false;
			}
			
			finally
			
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}
		
		else
			return false;
		return false;
	}

	/////
	
	public int fetchDate(String hiid) throws SQLException {
		
		
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm a");
		System.out.println("DAO");
		Connection con =null;
		con= DBUtil.getconnection();
		System.out.println(hiid);
		int slaTime=0;
		Timestamp registerDate = null;
		Timestamp approvalDate = null;
		if(con!=null)
		{
			Statement stm = con.createStatement();
			
			try
			{          
			ResultSet rs = stm.executeQuery( "select REGISTEREDTIME,approvaltime from p1_beneficiary WHERE HealthInsuranceID='"+hiid+"'");
			System.out.println(rs);	
			while(rs.next())
				{
				
				registerDate=rs.getTimestamp(1);
				System.out.println(rs.getTimestamp(1));
				System.out.println("Registered Date and time:\t\t" + sdf.format(registerDate.getTime()));
				approvalDate=rs.getTimestamp(2);
				System.out.println("approval Date and time:\t\t" + sdf.format(approvalDate.getTime()));
				}
			tc1 checkObject=new tc1();
			if(registerDate!=null&&approvalDate!=null)
			{
				slaTime=checkObject.HourDifference(registerDate,approvalDate);
			}
			else
			{
				TPAService t1=new TPAService();
				t1.errorMessage("null pointer exception");
			}
			
			
			System.out.println("hour differ"+slaTime);
			} 
			
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
			finally
			{
				DBUtil.closeConnection(con);
				if(stm!=null)
					stm.close();
			}
		}
		return slaTime;
	}

	public boolean updateApprovalTime(String hiid) throws SQLException {
		System.out.println("Approval Time updation");
		boolean status=false;
		Connection con =null;
		con= DBUtil.getconnection();
		Statement stm = con.createStatement();
		System.out.println("hiii");
		
		/*ResultSet rs1=stm.executeQuery("select systimestamp from DUAL");
		Timestamp approvalTime = null;
		
		while(rs1.next())
		{
		approvalTime=rs1.getTimestamp(1);
		System.out.println(approvalTime);
		}*/
		try
		{
		ResultSet rs = stm.executeQuery("UPDATE p1_beneficiary SET approvaltime=current_timestamp WHERE HealthInsuranceID='"+hiid+"'");
		System.out.println(rs);
		while(rs.next())
			{
			status=true;
			System.out.println("date updated  "+status);	
		
			}
		} 
		
		catch (SQLException e) 
		{
			return status;
		}
		
		finally
		
		{
			DBUtil.closeConnection(con);
			if(stm!=null)
				stm.close();
		}
		return status;
	}
	
	
	
	
	
	
	
	public String addHospital(Hospital hospital) throws SQLException {
		// TODO Auto-generated method stub
		Connection con = DBUtil.getconnection();

		String HospitalId = null;
		String addQuery = "Insert into p1_hospital values(HospitalSeq.nextval,?,?,?,?,?,?,?)";
		try {

			ps1 = con.prepareStatement(addQuery);

			System.out.println(hospital.getCityName());
			System.out.println(hospital.getStateName());
			System.out.println(hospital.getPinCode());
			ps1.setString(1, hospital.getHospitalName());
			ps1.setString(2, hospital.getAddress());
			ps1.setString(3, hospital.getCityName());
			ps1.setString(4, hospital.getStateName());
			ps1.setInt(5, hospital.getPinCode());
			ps1.setInt(6, hospital.getSTDCode());
			ps1.setLong(7, hospital.getPhoneNumber());
			ps1.executeUpdate();
			System.out.println("hii");
			ps2 = con
					.prepareStatement("select 'HospitaliD'||to_char(hospitalseq.currval,'FM09999999') as ID from dual ");
			rs = ps2.executeQuery();
			System.out.println("hello");

			if (rs.next()) {
				HospitalId = rs.getString("ID");
				System.out.println("hello11");

			}
			System.out.println("hello22");

		} catch (Exception e) {
			System.out.println("Exception occured");
		}

		finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
			DBUtil.closeConnection(ps1);
			DBUtil.closeConnection(ps2);
		}
		return HospitalId;
	}

	public ArrayList<Hospital> UpdateHospital(int hospitalId)
			throws SQLException {
		// TODO Auto-generated method stub
		Connection con = DBUtil.getconnection();
		PreparedStatement ps1 = null;
		ArrayList<Hospital> hospital = new ArrayList<>();
		try {

			con = DBUtil.getconnection();
			ps1 = con.prepareStatement("select * from p1_hospital");// where

			ResultSet rs = ps1.executeQuery();
			while (rs.next()) {
				Hospital h1 = new Hospital();
				h1.setHospitalId(rs.getString(1));
				h1.setHospitalName(rs.getString(2));
				h1.setAddress(rs.getString(3));
				h1.setCityName(rs.getString(4));
				h1.setStateName(rs.getString(5));
				h1.setPinCode(rs.getInt(6));
				h1.setSTDCode(rs.getInt(7));
				h1.setPhoneNumber(rs.getLong(8));

				hospital.add(h1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps1);
			DBUtil.closeConnection(rs);
		}
		return hospital;
	}

	public Hospital UpdateHospital(String hid) throws SQLException {
		// TODO Auto-generated method stub
		Connection con = DBUtil.getconnection();
		PreparedStatement ps = null;
		Hospital hospital = new Hospital();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("select * from p1_hospital where HOSPITALID=?");
			ps.setString(1, hid);
			ResultSet rs = ps.executeQuery();
			System.out.println("6");
			while (rs.next()) {
				System.out.println("5");
				hospital.setHospitalId(rs.getString(1));
				hospital.setHospitalName(rs.getString(2));
				hospital.setAddress(rs.getString(3));
				hospital.setCityName(rs.getString(4));
				hospital.setStateName(rs.getString(5));
				hospital.setPinCode(rs.getInt(6));
				hospital.setSTDCode(rs.getInt(7));
				hospital.setPhoneNumber(rs.getInt(8));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return hospital;
	}

	public boolean updateSelectedHospitalDetails(String hid,
			String hospitalName, String address, String cityName,
			String stateName, int pinCode, int stdCode, long phoneNumber)
			throws SQLException {
		// TODO Auto-generated method stub
		Connection con = DBUtil.getconnection();
		PreparedStatement ps = null;
		boolean b = false;
		try {
			System.out.println("next");
			con = DBUtil.getconnection();
			ps = con.prepareStatement("update p1_hospital set HospitalName=?, Address=?, City=?, State=?, PinCode=?, StdCode=?, PhoneNumber=? where HospitalId=?");
			ps.setString(1, hospitalName);
			ps.setString(2, address);
			ps.setString(3, cityName);
			ps.setString(4, stateName);
			ps.setInt(5, pinCode);
			ps.setInt(6, stdCode);
			ps.setLong(7, phoneNumber);
			ps.setString(8, hid);
			System.out.println(hid);
			System.out.println("next1");
			int i = ps.executeUpdate();
			if (i > 0) {
				b = true;
				System.out.println("Hey from b=true;");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b;
	}

	public boolean DeleteHospital(String hid) throws SQLException {
		// TODO Auto-generated method stub
		boolean b = false;
		Connection con = DBUtil.getconnection();
		PreparedStatement ps = null;
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("Delete from p1_hospital WHERE HospitalId = ?");
			ps.setString(1, hid);
			int i = ps.executeUpdate();
			if (i > 0) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeConnection(con);
			DBUtil.closeConnection(ps);
			DBUtil.closeConnection(rs);
		}
		return b;

	}

	public String getHospitalName(String hid) {
		String hname = "";
		try {
			con = DBUtil.getconnection();
			System.out.println(hid);
			ps = con.prepareStatement("select HospitalName from p1_hospital where HospitalId= ?");
			System.out.println("Stmt");
			ps.setString(1, hid);
			rs = ps.executeQuery();
			System.out.println("After query");
			while (rs.next()) {
				System.out.println(rs.getString(1));
				hname = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hname;
	}
	
	
	public ArrayList<VAS> viewVASForms() {
		ArrayList<VAS> b = new ArrayList<>();
		try {

			con = DBUtil.getconnection();
			ps = con.prepareStatement("select * from VALUE_ADDED_SERVICE_983430 where status= 'pending'");// where
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				VAS b1 = new VAS();
				b1.setHealthInsuranceID(rs.getString("HEALTHINSURANCEID"));
				b1.setAppointmentFor(rs.getString("APPOINTMENTFOR"));
				b1.setVASId(Integer.parseInt(rs
						.getString("VALUEADDEDSERVICEID")));
				b1.setVASRegisteredTime(rs.getDate("VASREGISTEREDTIME"));
				b1.setHospitalName(this.getHospitalName(rs.getString("HID")));
				b.add(b1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}


	public ArrayList<VAS> getEscalations() {
		ArrayList<VAS> b = new ArrayList<>();
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("select * from VALUE_ADDED_SERVICE_983430 where ESCALATIONREPORT!='NULL'");// where
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				VAS b1 = new VAS();
				b1.setHealthInsuranceID(rs.getString("HEALTHINSURANCEID"));
				b1.setAppointmentFor(rs.getString("APPOINTMENTFOR"));
				b1.setVASId(Integer.parseInt(rs
						.getString("VALUEADDEDSERVICEID")));
				b1.setVASRegisteredTime(rs.getDate("VASREGISTEREDTIME"));
				b1.setEscalationReport(rs.getString("ESCALATIONREPORT"));
				b1.setStatus(rs.getString("status"));
				b1.setTpaApprovedTime(rs.getDate("TPAAPPROVEDTIME"));
				b1.setHospitalName(this.getHospitalName(rs.getString("HID")));
				b.add(b1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	
	
	public boolean acceptSelectedVAS(String vasID) {
		boolean b = false;
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("update VALUE_ADDED_SERVICE_983430 set status='APPROVED',TPAAPPROVEDTIME=current_timestamp,"
					+ "ESCALATIONREPORT='SLA Time not crossed. No need of report.' where VALUEADDEDSERVICEID=?");
			ps.setString(1, vasID);
			int i = ps.executeUpdate();
			if (i > 0) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}

	public boolean declineSelectedVAS(String vasID) {
		boolean b = false;
		try {
			con = DBUtil.getconnection();
			ps = con.prepareStatement("update VALUE_ADDED_SERVICE_983430 set status='DECLINE',TPAAPPROVEDTIME=current_timestamp,"
					+ "ESCALATIONREPORT='SLA Time not crossed. No need of report.'  where VALUEADDEDSERVICEID=?");
			ps.setString(1, vasID);
			int i = ps.executeUpdate();
			if (i > 0) {
				b = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return b;
	}

	public boolean checkVASSLATime(String id) {
		boolean b = false;
		try {

			b = vasskipNonBusinessHours(id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;

	}

	public boolean vasskipNonBusinessHours(String id) {
		boolean b = false;

		int addTime = 96;
		String sDaysOrHours = "hours"; // "days";

		if (sDaysOrHours.equalsIgnoreCase("days")) {

			addTime = addTime * WORKING_MINS_PER_DAY; // Converting Days to Mins
		} else if (sDaysOrHours.equalsIgnoreCase("hours")) {

			addTime = addTime * MINUTES_PER_HOUR; // Converting Hours to Mins
		}
		// Getting Present Date and Time
		Calendar n_givenDateTime = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {

			ps = con.prepareStatement("select VASREGISTEREDTIME from VALUE_ADDED_SERVICE_983430 where VALUEADDEDSERVICEID=?");
			ps.setString(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Timestamp d = rs.getTimestamp(1);
				Date d4 = null;
				d4 = sdf.parse(sdf.format(d));
				n_givenDateTime.setTime(d4);
				System.out.println("D::: " + d);
			}
		} catch (ParseException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		System.out.println("VAS Registered Date:\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		TPADao time = new TPADao();
		time.addBusinessTime(n_givenDateTime, addTime);
		System.out.println("\nFinal Date for approval :\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		String c = sdf.format(n_givenDateTime.getTime());
		// System.out.println(c);
		Date d = new Date();
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = sdf.parse(c);
			d2 = sdf.parse(sdf.format(d));
			System.out.println(d2);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		if (d1.compareTo(d2) > 0) {
			b = true;// SLA time is not Crossed
		} else {
			b = false;// SLA time is Crossed
		}
		return b;
	}

	public boolean esclateVAS(String vasId, String vasEsclation) {
		int i = 0;
		try {
			con = DBUtil.getconnection();
			Date d = new Date();
			Date d1 = null;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			d1 = sdf.parse(sdf.format(d));
			Timestamp sq = new Timestamp(d1.getTime());
			ps = con.prepareStatement("update VALUE_ADDED_SERVICE_983430 set ESCALATIONREPORT=?,TPAAPPROVEDTIME=current_timestamp where VALUEADDEDSERVICEID=?");
			ps.setString(1, vasEsclation);
			// ps.setTimestamp(2, sq);
			ps.setString(2, vasId);
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (i == 1) {
			return true;
		} else
			return false;
	}
	public ArrayList<DomiciliaryClaim> viewDomiciliaryRequest() {
		ArrayList<DomiciliaryClaim> listDomiciliaryRequest = new ArrayList<DomiciliaryClaim>();
		try {

			con = DBUtil.getconnection();
			ps = con.prepareStatement("select HEALTHINSURANCEID,CLAIMID,STATUS,CLAIMEDDATE,TOTALCLAIMAMOUNT from P1_DOMICILIARY_CLAIMS where STATUS='pending'");
			rs = ps.executeQuery();
			while (rs.next()) {
				DomiciliaryClaim domiciliaryclaim = new DomiciliaryClaim();
				domiciliaryclaim.setHealthInsuranceId(rs.getString(1));
				domiciliaryclaim.setClaimId(rs.getString(2));
				domiciliaryclaim.setStatus(rs.getString(3));
				domiciliaryclaim.setClaim_date(rs.getTimestamp(4));
				domiciliaryclaim.setTotalClaimAmount(rs.getDouble(5));
				listDomiciliaryRequest.add(domiciliaryclaim);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listDomiciliaryRequest;
	}

	public ArrayList<HospitalizationClaim> viewHospitalizationRequest() {
		ArrayList<HospitalizationClaim> listHospitalizationRequest = new ArrayList<HospitalizationClaim>();
		try {
			con = DBUtil.getconnection();

			ps = con.prepareStatement("select HEALTHINSURANCEID,CLAIM_ID,STATUS,CLAIMEDDATE,TOTALCLAIMAMOUNT from P1_HOSPITALIZATION_CLAIMS where STATUS='pending'");
			rs = ps.executeQuery();
			while (rs.next()) {
				HospitalizationClaim hospitalizationclaim = new HospitalizationClaim();
				hospitalizationclaim.setHealthInsuranceId(rs.getString(1));
				hospitalizationclaim.setClaimId(rs.getString(2));
				hospitalizationclaim.setStatus(rs.getString(3));
				hospitalizationclaim.setClaim_date(rs.getTimestamp(4));
				hospitalizationclaim.setTotalClaimAmount(rs.getDouble(5));
				listHospitalizationRequest.add(hospitalizationclaim);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listHospitalizationRequest;

	}

	public boolean approveDomiciliaryClaim(String claimId,
			double approvedamount, String status, String claimEscaltion,String claimAction) {
		int i = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");

		Date d = new Date();
		Date d1 = null;
		try {
			d1 = sdf.parse(sdf.format(d));
			Timestamp sq = new Timestamp(d1.getTime());
			con = DBUtil.getconnection();

			ps = con.prepareStatement("update P1_DOMICILIARY_CLAIMS set STATUS=?,APPROVEDAMOUNT=?,APPROVEDDATETIME=?,ESCALATION_REPORT=?,ACTION=? where CLAIMID=?");
			ps.setString(1, status);
			ps.setDouble(2, approvedamount);
			ps.setTimestamp(3, sq);
			ps.setString(4, claimEscaltion);
			ps.setString(5, claimAction);
			ps.setString(6, claimId);
			i = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (i == 1) {
			return true;
		} else {
			return false;
		}
	}

	public boolean approveHospitalizationClaim(String claimId,
			double approvedamount, String status, String claimEscaltion,String claimAction) {
		int i = 0;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		Date d = new Date();
		Date d1 = null;
		try {

			con = DBUtil.getconnection();

			d1 = sdf.parse(sdf.format(d));
			Timestamp sq = new Timestamp(d1.getTime());
			ps = con.prepareStatement("update P1_HOSPITALIZATION_CLAIMS set STATUS=?,APPROVEDAMOUNT=?,APPROVEDDATETIME=?,ESCALATION_REPORT=?,ACTION=? where CLAIM_ID=?");
			ps.setString(1, status);
			ps.setDouble(2, approvedamount);
			ps.setTimestamp(3, sq);
			ps.setString(4, claimEscaltion);
			ps.setString(5, claimAction);
			ps.setString(6, claimId);
			i = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (i == 1) {
			return true;
		} else {
			return false;
		}
	}

	public boolean checkDomiciliarySLATime(String id) {
		boolean b = false;
		try {

			b = domiciliaryskipNonBusinessHours(id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;

	}

	public boolean checkHospitalizationSLATime(String id) {
		boolean b = false;
		try {

			b = hospitalizationskipNonBusinessHours(id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;

	}
	public boolean domiciliaryskipNonBusinessHours(String id) {
		boolean b = false;

		int addTime = 96;
		String sDaysOrHours = "hours"; // "days";

		if (sDaysOrHours.equalsIgnoreCase("days")) {

			addTime = addTime * WORKING_MINS_PER_DAY; // Converting Days to Mins
		}
		else if (sDaysOrHours.equalsIgnoreCase("hours")) {

			addTime = addTime * MINUTES_PER_HOUR; // Converting Hours to Mins
		}
		// Getting Present Date and Time
		Calendar n_givenDateTime = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {

			ps = con.prepareStatement("select CLAIMEDDATE from P1_Domiciliary_CLAIMS where CLAIMID=?");
			ps.setString(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Timestamp d = rs.getTimestamp(1);
				Date d4 = null;
				d4 = sdf.parse(sdf.format(d));
				n_givenDateTime.setTime(d4);
			}
		} catch (ParseException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		System.out.println("Claim raised Date:\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		TPADao time = new TPADao();
		time.addBusinessTime(n_givenDateTime, addTime);
		System.out.println("\nFinal Date for approval :\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		String c = sdf.format(n_givenDateTime.getTime());
		// System.out.println(c);
		Date d = new Date();
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = sdf.parse(c);
			d2 = sdf.parse(sdf.format(d));
			System.out.println(d2);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		if (d1.compareTo(d2) > 0) {
			b =true;// SLA time is not Crossed
		} else  {
			b =false;// SLA time is Crossed
		}
		return b;
	}
	public boolean hospitalizationskipNonBusinessHours(String id) {
		boolean b = false;

		int addTime = 96;
		String sDaysOrHours = "hours"; // "days";

		if (sDaysOrHours.equalsIgnoreCase("days")) {

			addTime = addTime * WORKING_MINS_PER_DAY; // Converting Days to Mins
		}
		else if (sDaysOrHours.equalsIgnoreCase("hours")) {

			addTime = addTime * MINUTES_PER_HOUR; // Converting Hours to Mins
		}
		// Getting Present Date and Time
		Calendar n_givenDateTime = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		try {

			ps = con.prepareStatement("select CLAIMEDDATE from P1_HOSPITALIZATION_CLAIMS where CLAIM_ID=?");
			ps.setString(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Timestamp d = rs.getTimestamp(1);
				Date d4 = null;
				d4 = sdf.parse(sdf.format(d));
				n_givenDateTime.setTime(d4);
			}
		} catch (ParseException e) {

			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		System.out.println("Claim raised Date:\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		TPADao time = new TPADao();
		time.addBusinessTime(n_givenDateTime, addTime);
		System.out.println("\nFinal Date for approval :\t\t"
				+ sdf.format(n_givenDateTime.getTime()));
		String c = sdf.format(n_givenDateTime.getTime());
		// System.out.println(c);
		Date d = new Date();
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = sdf.parse(c);
			d2 = sdf.parse(sdf.format(d));
			System.out.println(d2);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		if (d1.compareTo(d2) > 0) {
			b =true;// SLA time is not Crossed
		} else  {
			b =false;// SLA time is Crossed
		}
		return b;
	}
	public boolean esclateDomiciliaryClaim(String claimId,String claimEsclation, double approvedAmount, String claimStatus,String claimAction) {
		int i = 0;
		try {
			con = DBUtil.getconnection();

			Date d = new Date();
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
			
			Timestamp sq = new Timestamp(d.getTime());
			ps = con.prepareStatement("update P1_DOMICILIARY_CLAIMS set ESCALATION_REPORT=?,APPROVEDDATETIME=?,APPROVEDAMOUNT=?,STATUS=?,ACTION=? where CLAIMID=?");
			ps.setString(1, claimEsclation);
			ps.setTimestamp(2, sq);
			ps.setDouble(3,approvedAmount);
			ps.setString(4,claimStatus);
			ps.setString(5, claimAction);
			ps.setString(6, claimId);
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (i == 1) {
			return true;
		} else
			return false;
	}

	public boolean esclateHospitalizationClaim(String claimId,String claimEsclation,double approvedAmount,String claimStatus,String claimAction) {
		int i = 0;
		try {
			con = DBUtil.getconnection();

			Date d = new Date();
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		;
			Timestamp sq = new Timestamp(d.getTime());
			ps = con.prepareStatement("update P1_HOSPITALIZATION_CLAIMS set ESCALATION_REPORT=?,APPROVEDDATETIME=?,APPROVEDAMOUNT=?,STATUS=?,ACTION=? where CLAIM_ID=?");
			ps.setString(1, claimEsclation);
			ps.setTimestamp(2, sq);
			ps.setDouble(3, approvedAmount);
			ps.setString(4,claimStatus);
			ps.setString(5, claimAction);
			ps.setString(6, claimId);
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (i == 1) {
			return true;
		} else
			return false;
	}
   public String[] DomicilaryClaimDocument(String claimid)
   {
	   String arr[]=new String[5];
	   try
	   {
		   
		   con = DBUtil.getconnection();
		   ps=con.prepareStatement("SELECT FILELOCATION1, FILELOCATION2, FILELOCATION3, FILELOCATION4 FROM P1_DOMICILIARY_CLAIM_DOCUMENT where CLAIMID=?");

		   ps.setString(1,claimid);
		   rs=ps.executeQuery();
		   while(rs.next())
		   {
			   
			   arr[0]=rs.getString(1);
			   arr[1]=rs.getString(2);
			   arr[2]=rs.getString(3);
			   arr[3]=rs.getString(4);
			   
		   }
		   
	   }
	   catch(SQLException ex)
	   {
		   ex.printStackTrace();
	   }
	   return arr;
	   
   }
   public String[] HospitalizationClaimDocument(String claimid)
   {
	   String arr[]=new String[5];
	   try
	   {
		   
		   con = DBUtil.getconnection();
		   ps=con.prepareStatement("SELECT FILELOCATION1, FILELOCATION2, FILELOCATION3, FILELOCATION4, FILELOCATION5 FROM P1_HOSPITALIZATION_CLAIM_DOC where CLAIMID=?");
		   ps.setString(1,claimid);
		   rs=ps.executeQuery();
		   while(rs.next())
		   {
			   
			   arr[0]=rs.getString(1);
			   arr[1]=rs.getString(2);
			   arr[2]=rs.getString(3);
			   arr[3]=rs.getString(4);
			   arr[4]=rs.getString(5);
		   }
		   
	   }
	   catch(SQLException ex)
	   {
		   ex.printStackTrace();
	   }
	   return arr;
	   
   }

	public void addBusinessTime(Calendar givenDateTime, int addTimeMins) {
		// To get Present Working Day & Hour excluding Holidays
		adjustToBusinessHours(givenDateTime);

		while (addTimeMins > 0) {
			// Finding Business End Time On That Day
			Calendar businessEndTime = Calendar.getInstance();
			businessEndTime.setTime(givenDateTime.getTime());
			businessEndTime.set(Calendar.HOUR_OF_DAY, BUSINESS_END_HOUR);
			businessEndTime.clear(Calendar.MINUTE);

			// Difference of Time in Minutes AND Conversion Milli-Seconds to
			// Minutes
			int diffMins = (int) ((businessEndTime.getTimeInMillis() - givenDateTime
					.getTimeInMillis()) / (1000 * 60));

			if (addTimeMins < diffMins) // Adding Total Minutes to the Same Day
			{

				givenDateTime.add(Calendar.MINUTE, addTimeMins);
				break;
			} else // Adding available Minutes to the Same Day
			{

				givenDateTime.add(Calendar.MINUTE, diffMins);
				adjustToBusinessHours(givenDateTime);
				addTimeMins = addTimeMins - diffMins;
			}
		}
	}

	public static void adjustToBusinessHours(Calendar givenDateTime) {

		int hourOfDay = givenDateTime.get(Calendar.HOUR_OF_DAY);

		if (hourOfDay < BUSINESS_START_HOUR) // Skip to 9 AM on that Day
		{

			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		if (hourOfDay >= BUSINESS_END_HOUR) // Skip to Next Day 9 AM
		{

			givenDateTime.add(Calendar.DATE, 1);
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		skipHolidays(givenDateTime); // skip Holidays
	}

	public static void skipHolidays(Calendar givenDateTime) {
		skipGeneralHolidays(givenDateTime); // General Holidays before Weekends

		if (givenDateTime.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {

			givenDateTime.add(Calendar.DATE, 2); // Saturday and Sunday
													// in case of Business Hour
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		if (givenDateTime.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {

			givenDateTime.add(Calendar.DATE, 1); // Sunday
													// in case of Business Hour
			givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
			givenDateTime.clear(Calendar.MINUTE);
		}

		skipGeneralHolidays(givenDateTime); // General Holidays after Weekends
	}

	public static void skipGeneralHolidays(Calendar givenDateTime) {
		// Considering only given Date without Time (Temp)
		Calendar givenDate = Calendar.getInstance();
		givenDate.setTime(givenDateTime.getTime());
		givenDate.set(Calendar.HOUR_OF_DAY, 0);
		givenDate.set(Calendar.MINUTE, 0);
		givenDate.set(Calendar.SECOND, 0);
		givenDate.set(Calendar.MILLISECOND, 0);

		// List of General Holidays
		GregorianCalendar[] generalHolidays = getGeneralHolidays(givenDate);

		for (int i = 0; i < generalHolidays.length; i++) // Check for all
															// Holidays
		{

			if (givenDate.equals(generalHolidays[i])) {

				givenDateTime.add(Calendar.DATE, 1); // Add one date to Actual
														// Date & Time
														// in case of Business
														// Hour
				givenDateTime.set(Calendar.HOUR_OF_DAY, BUSINESS_START_HOUR);
				givenDateTime.clear(Calendar.MINUTE);

				givenDate.add(Calendar.DATE, 1); // Add one date to Temp Date
			}
		}
	}

	public static GregorianCalendar[] getGeneralHolidays(Calendar givenDate) {

		GregorianCalendar[] genHolidays = {

				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.JANUARY, 14),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.JANUARY, 26),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.MAY, 1),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.AUGUST, 15),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.OCTOBER, 2),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.NOVEMBER, 1),
				new GregorianCalendar(givenDate.get(Calendar.YEAR),
						Calendar.DECEMBER, 25)

		};

		return genHolidays;
	}


}
