package com.tcs.ilp.EHI_P1.bean;

public class TPABean {

	private String TPAuserid;
	private String password;
	

	public TPABean()
	{
		super();
	}
	
	public TPABean(String tPAuserid, String password) 
	{
		super();
		TPAuserid = tPAuserid;
		this.password = password;
	}


	public String getTPAuserid() 
	{
		return TPAuserid;
	}
	public void setTPAuserid(String userid)
	{
		TPAuserid = userid;
	}
	public String getPassword()
	{
		
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
}