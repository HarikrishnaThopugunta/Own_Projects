function validation(){
	//var employeeid=document.getElementsByName("empid").value;
	//var employeename=document.getElementsByName("empname").value;
	var password=document.getElementById("password").value;
	//var retypepassword=document.getElementsByName("retypepassword").value;	
	var dob=document.getElementById("DOB").value;
	var address=document.getElementById("address").value;
	var email=document.getElementById("email").value;
	var altemail=document.getElementById("altemail").value;
	var mobile=document.getElementById("mobilenum").value;
	var altmobile=document.getElementById("altmobilenum").value;
	//var date=document.getElementsByName("policystartdate").value;	
	var policyperiod=document.getElementById("policyperiod").value;	
	var totalsum=document.getElementById("totalSumInsured").value;
	//var amount=document.getElementsByName("premamt").value;
	var accno=document.getElementById("bankAccountNo").value;
	var bank=document.getElementById("nameOfBank").value;
	var code=document.getElementById("IFSCCode").value;
	var decimal=/^[-+]?[0-9]+\.[0-9]+$/;
	var reg=/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	var letters = /^[A-Za-z]+$/; 	
	/*if(employeeid==""|| employeeid==null){
		alert("please enter your EmployeeID");
		document.getElementsByName("empid").focus();
		return false;}
	if(isNaN(employeeid)){
		alert("please enter numeric data as your EmployeeID");
		document.getElementsByName("empid").focus();
		return false;}*/
	/*if(employeename==""|| employeename==null){
		alert("please enter your Name");
		document.getElementsByName("empname").focus();
		return false;}
	if( !employeename.match(letters)){		
		alert("please enter only alphabets");
		document.getElementsByName("empname").focus();
		return  false;}*/
	if(password==""|| password==null){
		alert('please enter your Password');
		document.getElementById("password").focus();
		return false;}
	/*
	if(retypepassword==""|| retypepassword==null){
		alert('please Retype your Password');
		document.getElementsByName("retypepassword").focus();
		return false;}
	
	if( !retypepassword.match(password)){		
		alert("retypepassword didnt match with your password");
		document.getElementsByName("retypepassword").focus();
		return false ;}*/
	if(dob==""|| dob==null){
		alert("please enter your Date of Birth");
		document.getElementById("DOB").focus();
		return false;}

   /* var gender = document.getElementsByName("gender");
    for(var i=0;i<gender.length;i++){
    	if(gender[i].checked==true){
    		break;
    	}
       }if(i==gender.length)
    	   {
    	   alert('please select gender');
    	   return false;
    	   }*/
    	 
	if(address=="" || address==null){
		alert("please enter your address");
		document.getElementById("address").focus();
		return false;
	}	
	if(email==""|| email==null){
		alert("please enter your email");
		document.getElementById("email").focus();
		return false;}
	if( !email.match(reg)){		
		alert("Please enter a valid email.For eg:abc@xyz.com");
		document.getElementById("email").focus();
		return false ;}
	if( !altemail.match(reg)){		
		alert("Please enter a valid alternate email. For eg:abc@xyz.com");
		document.getElementById("altemail").focus();
		return  false;}
	if(mobile==""|| mobile==null){
		alert("please enter your Mobile NUmber");
		document.getElementById("mobilenum").focus();
		return false;}
	if(isNaN(mobile)){
		alert("please enter numeric data as you Mobile Number");
		document.getElementById("mobilenum").focus();
		return false;}
	if(mobile.length!=10){
		alert('please enter a valid mobile number of 10 digits');
		document.getElementById("mobilenum").focus();
		return false;}
	if(isNaN(altmobile)){
		alert("please enter numeric data as your alternate Mobile Number");
		document.getElementById("altmobilenum").focus();
		return false;}
	if(altmobile.length!=10){
		alert('please enter a valid alternate mobile number of 10 digits');
		document.getElementById("altmobilenum").focus();
		return false;}
	/*if(date==""|| date==null){
		alert("please enter your Policy Start Date");
		document.getElementsByName("policystartdate").focus();
		return false;}*/
	if(policyperiod==""|| policyperiod==null){
		alert("please enter your Policy Period");
		document.getElementById("policyperiod").focus();
		return false;}
	if(isNaN(policyperiod)){
		alert("please enter numeric data as your Policy Period");
		document.getElementById("policyperiod").focus();
		return false;}
	if(totalsum==""|| totalsum==null){
		alert("please enter your Total sum Insured");
		document.getElementById("totalSumInsured").focus();
		return false;}
	if( !totalsum.match(decimal)){		
		alert("Please enter a valid amount");
		document.getElementById("totalSumInsured").focus();
		return false  ;}
	/*if(amount==""|| amount==null){
		alert("please enter your Premium Amount");
		document.getElementsByName("premamt").focus();
		return false;}
	if(isNaN(amount)){
		alert("please enter numeric data as your Premium Amount");
		document.getElementsByName("premamt").focus();
		return false;}
	if( !amount.match(decimal)){		
		alert("Please enter a valid Amount");
		document.getElementsByName("premamt").focus();
		return false ;}*/
	if(accno==""|| accno==null){
		alert("please enter your AccountNumber");
		document.getElementById("accno").focus();
		return false;}
	if(isNaN(accno)){
		alert("please enter numeric data as your Account Number");
		document.getElementById("bankAccountNo").focus();
		return false;}
	if(bank==""|| bank==null){
		alert("please enter your Bank Name");
		document.getElementById("nameOfBank").focus();
		return false;}
	if( !bank.match(letters)){		
		alert("please enter only alphabets");
		document.getElementById("nameOfBank").focus();
		return  false;}
	if(code==""|| code==null){
		alert("please enter your IFSC Code");
		document.getElementById("IFSCCode").focus();
		return false;}
	if(isNaN(code)){
		alert("please enter numeric data as your IFSC Code");
		document.getElementById("IFSCCode").focus();
		return false;}

return true;
}