function validation(){
	
	var employeeId= document.getElementById("employeeid").value;
	var beneficiary= document.getElementById("Beneficiary").value;
	var policyperiod=document.getElementById("PolicyPeriod").value;
	var totalsuminsured=document.getElementById("TotalSumInsured").value;
	var premiumamount=document.getElementById("PremiumAmount").value;
	var letters = /^[A-Za-z]+$/; 
	if(employeeId=="" || employeeId==null){
		alert("please enter the employee id");
		document.getElementById("employeeid").focus();
		return false;
	}
	if(beneficiary=="" || beneficiary==null){
		alert("Please enter the beneficiary name");
		document.getElementById("Beneficiary").focus();
		return false;
	}
	if(!beneficiary.match(letters)){
		alert("please enter only alphabets in beneficiary name.");
		document.getElementById("Beneficiary").focus();
		return false;
	}
	if(policyperiod==""|| policyperiod==null){
		alert("please enter your Policy Period");
		document.getElementById("PolicyPeriod").focus();
		return false;}
	if(isNaN(policyperiod)){
		alert("please enter numeric data as your Policy Period");
		document.getElementById("PolicyPeriod").focus();
		return false;}
	
	if(premiumamount==""|| premiumamount==null){
		alert("please enter your Premium Amount");
		document.getElementById("PremiumAmount").focus();
		return false;}
	if(isNaN(premiumamount)){
		alert("please enter numeric data as your Premium Amount");
		document.getElementById("PremiumAmount").focus();
		return false;}
	if( !premiumamount.match(decimal)){		
		alert("Please enter a valid Amount");
		document.getElementById("PremiumAmount").focus();
		return false ;}
	if(totalsuminsured==""|| totalsuminsured==null){
		alert("please enter your Total sum Insured");
		document.getElementById("TotalSumInsured").focus();
		return false;}
	if( !totalsuminsured.match(decimal)){		
		alert("Please enter a valid amount");
		document.getElementById("TotalSumInsured").focus();
		return false  ;}
	return true;
}