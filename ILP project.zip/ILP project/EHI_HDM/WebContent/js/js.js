function ajaxHospital()
{
	
	var xmlhttp;
	var state=document.myform.state.value;
	var city=document.myform.city.value;
	var action = "hospitalization";
//alert("hii"+city+" 0 "+state);
	var urls="EmployeeController?state="+state+"&city="+city+"&action="+action;
	
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		
		var some=xmlhttp.responseXML.documentElement;
		document.getElementById("hospitalname").innerHTML = "";
		for(var i=0;i<some.getElementsByTagName("hospitalName").length;i++)
		{
			
		var combo = document.getElementById("hospitalname"); 
		var option = document.createElement("option");
		
		option.text = some.getElementsByTagName("hospitalName")[i].childNodes[0].nodeValue;
		option.value =  some.getElementsByTagName("hospitalId")[i].childNodes[0].nodeValue;
		try 
		{ 
		combo.add(option, null); //Standard 
		}catch(error){combo.add(option); // IE only 
		} 

	}
	}
	};
	xmlhttp.open("GET",urls,true);
	xmlhttp.send();	

}
function ajaxC()
{
	
	var xmlhttp;
	var id=document.myform.state.value;
	var action = "hospitalization";
	var urls="EmployeeController?stateId="+id+"&action="+action;
	//alert("city"+id);
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		//alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		
		var some=xmlhttp.responseXML.documentElement;
		document.getElementById("city").innerHTML = "";
	
		
		for(var i=0;i<some.getElementsByTagName("cityName").length;i++)
		{
		var combo = document.getElementById("city"); 
		var option = document.createElement("option");
		
		option.text = some.getElementsByTagName("cityName")[i].childNodes[0].nodeValue;
		option.value =  some.getElementsByTagName("cityName")[i].childNodes[0].nodeValue;
		try 
		{ 
		combo.add(option, null); //Standard 
		}catch(error){combo.add(option); // IE only 
		} 

	}
	}
	};
	xmlhttp.open("GET",urls,true);
	xmlhttp.send();	

}
function ajaxH()
{
	
	var action = "hospitalization";
	var xmlhttp;
	var id=document.myform.nameofpatient.value;
	var urls="EmployeeController?name="+id+"&name="+name+"&action="+action;
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		//alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		
	var some=xmlhttp.responseXML.documentElement;
	
	if(some.getElementsByTagName("gender")[0].childNodes[0].nodeValue=='M'){

	document.getElementById("male").checked =true;
	}
	else
		document.getElementById("female").checked =true;

	document.getElementById("relationship").value =some.getElementsByTagName("relationship")[0].childNodes[0].nodeValue;
	document.getElementById("age").value=some.getElementsByTagName("age")[0].childNodes[0].nodeValue;
	document.getElementById("healthinsuranceid").value=some.getElementsByTagName("hiid")[0].childNodes[0].nodeValue;
	}
	};
	xmlhttp.open("GET",urls,true);
	xmlhttp.send();	
}

function ajaxD()
{
	var xmlhttp;
	var name=document.myform1.beneficiary.value;
	var id = document.myform1.employeeid.value;
	var action = "domiciliary";
	
	var urls="EmployeeController?name="+name+"&id="+id+"&action="+action;
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
	xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		//alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
	if (xmlhttp.readyState==4 && xmlhttp.status==200)
	{
		
	var some=xmlhttp.responseXML.documentElement;
	document.getElementById("healthinsuranceid").value=some.getElementsByTagName("hiid")[0].childNodes[0].nodeValue;
	}
	};
	xmlhttp.open("GET",urls,true);
	xmlhttp.send();	
}
