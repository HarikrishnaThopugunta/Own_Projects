function hosvalidation() {

	var companyname=document.getElementById("companyname").value;
	var nameofpatient=document.getElementById("nameofpatient").value;
	var nameofdoctor=document.getElementById("nameofdoctor").value;
	var state=document.getElementById("state").value;
	var city=document.getElementById("city").value;
	var hospitalname=document.getElementById("hospitalname").value;
	var StartDate= document.getElementById("dateofadmission").value;
	var EndDate= document.getElementById("dateofdischarge").value;
	var eDate = new Date(EndDate);
	var sDate = new Date(StartDate);
	var detailsofillness=document.getElementById("detailsofillness").value;
	var amount=document.getElementById("amount").value;
	var doc1=document.getElementById("document1").value;
	var doc2=document.getElementById("document2").value;
	var doc3=document.getElementById("document3").value;
	var doc4=document.getElementById("document4").value;
	var doc5=document.getElementById("document5").value;
		var decimal=/^[-+]?[0-9]+\.[0-9]+$/;
		var letters = /^[A-Za-z ]+$/; 
		if(companyname==""|| companyname==null){
			alert("please enter your Company Name");
			document.getElementById("companyname").focus();
			return false;}
		if( !(companyname.match(letters))){		
			alert("please enter only alphabets");
			document.getElementById("companyname").focus();
			return  false;}
		if(nameofpatient=="Select"){
			alert("please select the name of the Patient");
			document.getElementById("nameofpatient").focus();
			return false;}
		if( !nameofpatient.match(letters)){		
			alert("please enter only alphabets");
			document.getElementById("nameofpatient").focus();
			return  false;}
		if(nameofdoctor==""|| nameofdoctor==null){
			alert("please enter  Name of the Doctor");
			document.getElementById("nameofdoctor").focus();
			return false;}
		if( !nameofdoctor.match(letters)){		
			alert("please enter only alphabets");
			document.getElementById("nameofdoctor").focus();
			return  false;}
		if(state=="Select"){
			alert("please select the state");
			document.getElementById("state").focus();
			return false;}
		if(city=="Select"){
			alert("please select the city");
			document.getElementById("city").focus();
			return false;}
		if(hospitalname=="Select"){
			alert("please enter Hospital Name");
			document.getElementById("hospitalname").focus();
			return false;}
		if(StartDate==""|| StartDate==null){
			alert("please enter your date of admission");
			document.getElementById("dateofadmission").focus();
			return false;}
		if(EndDate==""|| EndDate==null){
			alert("please enter your date of discharge");
			document.getElementById("dateofdischarge").focus();
			return false;}
		if(sDate>= eDate)
			{
			alert("Please ensure that the End Date should be after the Start Date.");
			return false;
			}
		if(detailsofillness==""|| detailsofillness==null){
			alert("please enter the details of illness");
			document.getElementById("detailsofillness").focus();
			return false;}
		if( !detailsofillness.match(letters)){		
			alert("please enter only alphabets");
			document.getElementById("detailsofillness").focus();
			return  false;}
		if ( ( myform.y[0].checked == false ) && ( myform.y[1].checked == false ) ) 
		{
		alert ( "Please choose your Gender: Male or Female" ); 
		return false;
		}
		if(amount==""|| amount==null){
			alert("please enter Total Claim Amount");
			document.getElementById("amount").focus();
			return false;}
		if(isNaN(amount)){
			alert("please enter numeric data as your Total Claim Amount");
			document.getElementById("amount").focus();
			return false;}
		if( !amount.match(decimal)){		
			alert("Please enter a valid Total Claim Amount");
			document.getElementById("amount").focus();
			return false ;}
		if(doc1==""|| doc1==null){
			alert("please upload admission or discharge summary/card issued by the hospital");
			document.getElementById("document1").focus();
			return false;}
		if(doc2==""|| doc2==null){
			alert("please upload the bill for hospitalization expenses ");
			document.getElementById("document2").focus();
			return false;}
		if(doc3==""|| doc3==null){
			alert("please upload the numbered bill/receipt/cash memo issued by the hospital");
			document.getElementById("document3").focus();
			return false;}
		if(doc4==""|| doc4==null){
			alert("please upload the copies of lab/test reports ");
			document.getElementById("document4").focus();
			return false;}
		if(doc5==""|| doc5==null){
			alert("please upload the medical bill/receipt with prescription for the medicine ");
			document.getElementById("document5").focus();
			return false;}
}		
		
