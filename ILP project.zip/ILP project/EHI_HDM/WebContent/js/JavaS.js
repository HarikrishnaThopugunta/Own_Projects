function valself() {

	var xmlhttp;
	var id = "self";
	document.getElementById("HIIDdependent").value="";
	var urls = "EmployeeController?name=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			VASform.HIIDdependent.value = xmlhttp.responseText;

		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function val() {
	var xmlhttp;
	var id = VASform.select1.value;
	document.getElementById("HIIDdependent").value="";
	var urls = "EmployeeController?dependentName=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				VASform.HIIDdependent.value = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function valdependent() {
	var req;
	var id = "dependent";
	var url = "EmployeeController?name=" + id;
	document.getElementById("HIIDdependent").value="";
	if (window.XMLHttpRequest) {
		req = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		req = new ActiveXObject("Microsoft.XMLHTTP");
	}
	req.onreadystatechange = function() {
		if (req.readyState == 4) {
			if (req.status == 200) {
				document.getElementById("select").innerHTML = req.responseText;
			}
		}
	}
	req.open("post", url, true);
	req.send(null);
}

function stateVal() {
	var xmlhttp;
	/*var ddl = document.getElementById('stateList');
	if(ddl.options[0].value=="--select--"){
		
		location.reload(true);
	}
	else {*/
		var id = "state";
		var urls = "EmployeeController?stname=" + id

		if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera,
									// Safari
			xmlhttp = new XMLHttpRequest();
		} else {// code for IE6, IE5
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function() {
			// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {

					document.getElementById("state").innerHTML = xmlhttp.responseText;
				}
			}
		};
		xmlhttp.open("GET", urls, true);
		xmlhttp.send();
	//}
}

function cityVal() {
	var xmlhttp;
	var id = document.getElementById("stateList").value;
	var urls = "EmployeeController?STforCT=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("city").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}
function hospVal() {
	var xmlhttp;
	var id = VASform.cityList.value;
	var id1= VASform.stateList.value;
	var urls = "EmployeeController?CTforHP=" + id+"&STforCT="+id1;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				if(xmlhttp.responseText=="no match"){
					alert("Please refresh the page.");
				}
				else
					document.getElementById("hospital").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}
function stCHVal()
{
	var xmlhttp;
	var id = document.getElementById("stateList").value;
	var urls = "EmployeeController?STforCT=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("city").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}
function ctCHVal()
{
	var xmlhttp;
	var id = VASform.cityList.value;
	var id1= VASform.stateList.value;
	var urls = "EmployeeController?CTforHP=" + id+"&STforCT="+id1;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				if(xmlhttp.responseText=="no match"){
					alert("Please refresh the page.");
				}
				else
					document.getElementById("hospital").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function validation(){
	//var employeeid= document.getElementById("employeeid").value;
	var employeename= document.getElementById("employeename").value;
	var age=document.getElementById("age").value;
	var mobilenumber=document.getElementById("mobilenumber").value;
	var email=document.getElementById("email").value;
	//var date = document.getElementById("date").value;
	 var time = document.getElementById("time").value;
	//var convert=convertTo24Hour($("time").val().toLowerCase());


	var reg=/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	var letters = /^[A-Za-z]+$/;  

	if(employeename==""|| employeename==null){
		alert("please enter your Name");
		document.getElementById("employeename").focus();
		return false;}
	if( !employeename.match(letters)){
		
		alert("please enter only alphabets");
		document.getElementById("employeename").focus();
		return false;
		}

	if(age==""|| age==null){
		alert("please enter your age");
		document.getElementById("age").focus();
		return false;}

		if(isNaN(age)){
		alert('please enter numeric data as age');
		document.getElementById("age").focus();
		return false;}
		
		if(mobilenumber==""||mobilenumber==null){
			alert('please enter your Mobile Number');
			document.getElementById("mobilenumber").focus();
			return false;}

			if(isNaN(mobilenumber)){
			alert('please enter numeric data as your Mobile Number');
			document.getElementById("mobilenumber").focus();
			return false;}
			if(mobilenumber.length!=10){
				alert('please enter a valid mobile number of 10 digits');
				document.getElementById("mobilenumber").focus();
				return false;
				}
			if(email==""||email==null){
				alert("please enter your email");
				document.getElementById("email").focus();
				return false;}
			if(!email.match(reg)){
				alert("please enter valid email");
				document.getElementById("email").focus();
				return false;
			}
			/*if(date=="")
			{
				alert('Please Give Preferred Date');
				document.getElementById("date").focus();
				return false;
			}*/
			 //var re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

		    /*if( !date.match(re)) {
		      alert("Invalid date format: " + date);
		      document.getElementById("date").focus();
		      return false;}*/
			if(time=="")
			{
				alert('Please Give "Preferred Time"');
				document.getElementById("time").focus();
				return false;
			}
			 var r =  /^(2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/;

			    if(!time.match(r)) {
			      alert("please enter a valid Time. Eg: 23:13:33");
			      document.getElementById("time").focus();
			      return false;
			    }
	}
function switching(val) {
	if(val==1) {
		
		document.getElementById('dependent').style.display='none';
		document.getElementById('self').style.display='block';
	}
	else if(val==2) {
		
		document.getElementById('self').style.display='none';
		document.getElementById('dependent').style.display='block';
	}
}