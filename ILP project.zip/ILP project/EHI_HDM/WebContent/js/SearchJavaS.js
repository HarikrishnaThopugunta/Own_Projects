function shstateVal() {
	var xmlhttp;
	/*var ddl = document.getElementById('stateList');
	if(ddl.options[0].value=="--select--"){
		
		location.reload(true);
	}
	else {*/
		var id = "state";
		var urls = "EmployeeController?stname=" + id

		if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera,
									// Safari
			xmlhttp = new XMLHttpRequest();
		} else {// code for IE6, IE5
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function() {
			// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {
					//alert(xmlhttp.responseText);
					document.getElementById("state").innerHTML = xmlhttp.responseText;
				}
			}
		};
		xmlhttp.open("GET", urls, true);
		xmlhttp.send();
	//}
}

function shcityVal() {
	var xmlhttp;
	var id = document.getElementById("stateList").value;
	var urls = "EmployeeController?STforCT=" + id;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("city").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function nameVal() {
	var xmlhttp;
	/*var ddl = document.getElementById('stateList');
	if(ddl.options[0].value=="--select--"){
		
		location.reload(true);
	}
	else {*/
		var id = "hname";
		var urls = "EmployeeController?hosname=" + id

		if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera,
									// Safari
			xmlhttp = new XMLHttpRequest();
		} else {// code for IE6, IE5
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function() {
			// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
			if (xmlhttp.readyState == 4) {
				if (xmlhttp.status == 200) {
					//alert(xmlhttp.responseText);
					document.getElementById("hname").innerHTML = xmlhttp.responseText;
				}
			}
		};
		xmlhttp.open("GET", urls, true);
		xmlhttp.send();
	//}
}
function stCHVal()
{
	var xmlhttp;
	var id = document.getElementById("stateList").value;
	var urls = "EmployeeController?STforCT=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("city").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}