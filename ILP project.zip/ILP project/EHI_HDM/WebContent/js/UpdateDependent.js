function validation(){
	
	var dob=document.getElementById("DateOfBirth").value;
	var policyperiod=document.getElementById("PolicyPeriod").value;	
	//var totalsum=document.getElementsByName("TotalSumInsured").value;
	
	if(policyperiod==""|| policyperiod==null){
		alert("please enter your Policy Period");
		document.getElementById("PolicyPeriod").focus();
		return false;}
	if(isNaN(policyperiod)){
		alert("please enter numeric data as your Policy Period");
		document.getElementById("PolicyPeriod").focus();
		return false;}
	/*if(totalsum==""|| totalsum==null){
		alert("please enter your Total sum Insured");
		document.getElementsByName("TotalSumInsured").focus();
		return false;}*/
	/*if( !totalsum.match(decimal)){		
		alert("Please enter a valid amount");
		document.getElementsByName("TotalSumInsured").focus();
		return false  ;}*/
	if(dob==""){
		alert('please enter your Date of Birth');
		document.getElementById("DateOfBirth").focus();
		return false;}

	return true;
	
}