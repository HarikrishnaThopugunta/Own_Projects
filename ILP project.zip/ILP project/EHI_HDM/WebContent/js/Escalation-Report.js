function validation(){
var employeeid=document.getElementById("employeeid").value;
var employeename= document.getElementById("employeename").value;
var healthinsuranceid=document.getElementById("healthInsuranceId").value;
var totaltimetaken=document.getElementById("totalTimeTaken").value;
var reasonforsla=document.getElementById("SLAReason").value;
var letters = /^[A-Za-z]+$/;
var numbers=/^[0-9]+$/;
if(employeeid==""|| employeeid==null){
	alert('please enter your Employee ID');
	document.getElementById("employeeid").focus();
	return false;

}
if( !employeename.match(letters)){
	
	alert("please enter only alphabets in employee name");
	document.getElementById("employeename").focus();
	return false;
	}

if(healthinsuranceid==""|| healthinsuranceid==null){
	alert('please enter your Health Insurance ID');
	document.getElementById("healthinsuranceid").focus();
	return false;
}
if(!healthinsuranceid.match(numbers)){
	alert("please enter only numbers in HI-ID");
	document.getElementById("healthinsuranceid").focus();
	return false;
}
if(totaltimetaken==""|| totaltimetaken==null){
	alert('please enter  total time taken');
	document.getElementById("totalTimeTaken").focus();
	return false;
}
if( !reasonforsla.match(letters)){
	
	alert("please enter only alphabets in SLA Reason");
	document.getElementById("SLAReason").focus();
	return false;
	}
return true;
}
