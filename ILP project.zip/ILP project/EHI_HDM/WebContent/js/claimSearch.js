function srcValidation()
{	
	var Ctype =	document.getElementById("claimType"); 
	var Hid =document.getElementById("healthinsuranceid");
	var Pyear =	document.getElementById("policyYear");
	var relatnshp =	document.getElementById("relationship");
	if((Ctype.selectedIndex==0 && Pyear.selectedIndex==0 && relatnshp.selectedIndex==0) && (Hid.value==0))
	{
		alert("please enter either HI-ID or Benificiary");
		return false;
	}else if((Ctype.selectedIndex!=0 || Pyear.selectedIndex!=0 || relatnshp.selectedIndex!=0) && (Hid.value!=0))
	{
		alert("please enter either HI-ID or Benificiary");
		return false;
	}
	else if((Ctype.selectedIndex!=0 && Pyear.selectedIndex!=0 && relatnshp.selectedIndex!=0) && (Hid.value!=0))
	{
		alert("please enter either HI-ID or Benificiary");
		return false;
	}
	else if((Ctype.selectedIndex!=0 || Pyear.selectedIndex!=0 || relatnshp.selectedIndex!=0) && (Hid.value==0))
	{
		if(Ctype.selectedIndex==0)
	    {
			alert("please select Claim Type");
			return false;
	    }else if(Pyear.selectedIndex==0)
	    {
			alert("please select Policy Year");
			return false;
	    }else if (relatnshp.selectedIndex==0)
	    {
			alert("please select RelationShip");
			return false;
	    }
	}

}

