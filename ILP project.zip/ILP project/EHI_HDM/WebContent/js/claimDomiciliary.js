function domvalidation(){
var beneficiary=document.getElementById("beneficiary").value;
var email=document.getElementById("alternateemailid").value;
var StartDate= document.getElementById("treatmentstartdate").value;
var EndDate= document.getElementById("treatmentenddate").value;
var InjuryDate= document.getElementById("dateofinjury").value;
var eDate = new Date(EndDate);
var sDate = new Date(StartDate);
var nameofdoctor=document.getElementById("nameofdoctor").value;
var injury=document.getElementById("injury").value;
var amount=document.getElementById("amount").value;
var doc1=document.getElementById("document1").value;
var doc2=document.getElementById("document2").value;
var doc3=document.getElementById("document3").value;
var doc4=document.getElementById("document4").value;
var decimal=/^[-+]?[0-9]+\.[0-9]+$/;
var letters = /^[A-Za-z ]+$/; 	
if(beneficiary=="Select"){
	alert("please select the beneficiary Name");
	document.getElementById("beneficiary").focus();
	return false;}
if( !beneficiary.match(letters)){		
	alert("please enter only alphabets");
	document.getElementById("beneficiary").focus();
	return  false;}
if(email==""|| email==null){
	alert("please enter your email");
	document.getElementById("alternateemailid").focus();
	return false;}
if( !email.match(/(^[a-zA-Z0-9_\.\-]+\@[a-zA-Z0-9\-]+\.[a-zA-Z0-9])/)){		
	alert("Please enter a valid email.For eg:abc@xyz.com");
	document.getElementById("alternateemailid").focus();
	return false ;}
if(StartDate==""|| StartDate==null){
	alert("please enter your treatement start date");
	document.getElementById("treatmentstartdate").focus();
	return false;}
if(EndDate==""|| EndDate==null){
	alert("please enter your treatement end date");
	document.getElementById("treatmentenddate").focus();
	return false;}
if(sDate> eDate)
	{
	alert("Please ensure that the End Date should be after the Start Date.");
	return false;
	}
if(InjuryDate==""|| InjuryDate==null){
	alert("please enter your date of injury");
	document.getElementById("dateofinjury").focus();
	return false;}
if(nameofdoctor==""|| nameofdoctor==null){
	alert("please enter Doctor's Name");
	document.getElementById("nameofdoctor").focus();
	return false;}
if( !nameofdoctor.match(letters)){		
	alert("please enter only alphabets");
	document.getElementById("nameofdoctor").focus();
	return  false;}
if(injury==""|| injury==null){
	alert("please enter injury");
	document.getElementById("injury").focus();
	return false;}
if( !injury.match(letters)){		
	alert("please enter only alphabets");
	document.getElementById("injury").focus();
	return  false;}
if(isNaN(amount)){
	alert("please enter numeric data as your Premium Amount");
	document.getElementById("amount").focus();
	return false;}
if( !amount.match(decimal)){		
	alert("Please enter a valid Amount");
	document.getElementById("amount").focus();
	return false ;}
if(doc1==""|| doc1==null){
	alert("please enter the Doctor�s prescription document");
	document.getElementById("document1").focus();
	return false;}
if(doc2==""|| doc2==null){
	alert("please upload the pre-numbered medical bill receipt ");
	document.getElementById("document2").focus();
	return false;}
if(doc3==""|| doc3==null){
	alert("please upload the bill along with prescription for medicines");
	document.getElementById("document3").focus();
	return false;}
if(doc4==""|| doc4==null){
	alert("please upload the copies of lab/test reports ");
	document.getElementById("document4").focus();
	return false;}
}