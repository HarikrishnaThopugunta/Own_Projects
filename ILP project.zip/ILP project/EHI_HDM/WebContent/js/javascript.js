function speciality(val) {



						if(val==1) {



							document.getElementById('sarch3').style.display='none';



							document.getElementById('sarch2').style.display='none';



							document.getElementById('sarch1').style.display='block';



						}



						else if(val==2) {



							document.getElementById('sarch3').style.display='none';



							document.getElementById('sarch1').style.display='none';



							document.getElementById('sarch2').style.display='block';



						}



						else if(val==3) {



							document.getElementById('sarch1').style.display='none';



							document.getElementById('sarch2').style.display='none';



							document.getElementById('sarch3').style.display='block';



						}



					}		

function validate(){
	
	var pincode= document.getElementsByName("pincode").value;
	if(pincode==""){
		alert('please enter your pincode');
		return false;}

		/*if(isNaN(pincode)){
		alert('please enter numeric data ');
		return false;}*/

		/*if(pincode.length!=6){
		alert('please enter a valid pincode ');
		return false;
		}*/
}



