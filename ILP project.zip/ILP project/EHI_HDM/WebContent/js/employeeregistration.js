function validation(){
	var employeeid=document.getElementById("employeeid").value;
	var employeename=document.getElementById("employeename").value;
	var password=document.getElementById("password").value;
	var retypepassword=document.getElementById("retypepassword").value;	
	var dob=document.getElementById("dob").value;	
	var email=document.getElementById("email").value;
	var altemail=document.getElementById("altemail").value;
	var mobile=document.getElementById("mobile").value;
	var altmobile=document.getElementById("altmobile").value;
	var date=document.getElementById("date").value;	
	var policyperiod=document.getElementById("policyperiod").value;	
	var totalsum=document.getElementById("totalsum").value;
	var amount=document.getElementById("amount").value;
	var accno=document.getElementById("accno").value;
	var bank=document.getElementById("bank").value;
	var code=document.getElementById("code").value;
	var decimal=/^[-+]?[0-9]+\.[0-9]+$/;
	var reg=/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
	var letters = /^[A-Za-z]+$/; 	
	if(employeeid==""|| employeeid==null){
		alert("please enter your EmployeeID");
		document.getElementById("employeeid").focus();
		return false;}
	if(isNaN(employeeid)){
		alert("please enter numeric data as your EmployeeID");
		document.getElementById("employeeid").focus();
		return false;}
	if(employeename==""|| employeename==null){
		alert("please enter your Name");
		document.getElementById("employeename").focus();
		return false;}
	if(!employeename.match(letters)){		
		alert("please enter only alphabets");
		document.getElementById("employeename").focus();
		return  false;}
	if(password==""|| password==null){
		alert('please enter your Password');
		document.getElementById("password").focus();
		return false;}
	
	if(retypepassword==""|| retypepassword==null){
		alert('please Retype your Password');
		document.getElementById("retypepassword").focus();
		return false;}
	
	if( !retypepassword.match(password)){		
		alert("retypepassword didnt match with your password");
		document.getElementById("retypepassword").focus();
		return false ;}
	if(dob==""|| dob==null){
		alert("please enter your Date of Birth");
		document.getElementById("dob").focus();
		return false;}
	if(email==""|| email==null){
		alert("please enter your email");
		document.getElementById("email").focus();
		return false;}
	if( !email.match(reg)){		
		alert("Please enter a valid email.For eg:abc@xyz.com");
		document.getElementById("email").focus();
		return false ;}
	if( !altemail.match(reg)){		
		alert("Please enter a valid alternate email. For eg:abc@xyz.com");
		document.getElementById("altemail").focus();
		return  false;}
	if(mobile==""|| mobile==null){
		alert("please enter your Mobile NUmber");
		document.getElementById("mobile").focus();
		return false;}
	if(isNaN(mobile)){
		alert("please enter numeric data as you Mobile Number");
		document.getElementById("mobile").focus();
		return false;}
	if(mobile.length!=10){
		alert('please enter a valid mobile number of 10 digits');
		document.getElementById("mobile").focus();
		return false;}
	if(isNaN(altmobile)){
		alert("please enter numeric data as your alternate Mobile Number");
		document.getElementById("altmobile").focus();
		return false;}
	if(altmobile.length!=10){
		alert('please enter a valid alternate mobile number of 10 digits');
		document.getElementById("altmobile").focus();
		return false;}
	if(date==""|| date==null){
		alert("please enter your Policy Start Date");
		document.getElementById("date").focus();
		return false;}
	if(policyperiod==""|| policyperiod==null){
		alert("please enter your Policy Period");
		document.getElementById("policyperiod").focus();
		return false;}
	if(isNaN(policyperiod)){
		alert("please enter numeric data as your Policy Period");
		document.getElementById("policyperiod").focus();
		return false;}
	if(totalsum==""|| totalsum==null){
		alert("please enter your Total sum Insured");
		document.getElementById("totalsum").focus();
		return false;}
	if( !totalsum.match(decimal)){		
		alert("Please enter a valid amount");
		document.getElementById("totalsum").focus();
		return false  ;}
	if(amount==""|| amount==null){
		alert("please enter your Premium Amount");
		document.getElementById("amount").focus();
		return false;}
	if(isNaN(amount)){
		alert("please enter numeric data as your Premium Amount");
		document.getElementById("amount").focus();
		return false;}
	if( !amount.match(decimal)){		
		alert("Please enter a valid Amount");
		document.getElementById("Amount").focus();
		return false ;}
	if(accno==""|| accno==null){
		alert("please enter your AccountNumber");
		document.getElementById("accno").focus();
		return false;}
	if(isNaN(accno)){
		alert("please enter numeric data as your Account Number");
		document.getElementById("accno").focus();
		return false;}
	if(bank==""|| bank==null){
		alert("please enter your Bank Name");
		document.getElementById("bank").focus();
		return false;}
	if( !bank.match(letters)){		
		alert("please enter only alphabets");
		document.getElementById("bank").focus();
		return  false;}
	if(code==""|| code==null){
		alert("please enter your IFSC Code");
		document.getElementById("code").focus();
		return false;}
	if(isNaN(code)){
		alert("please enter numeric data as your IFSC Code");
		document.getElementById("code").focus();
		return false;}

return true;
}