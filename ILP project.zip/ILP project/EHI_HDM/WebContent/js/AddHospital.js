function validation(){
	
	var hospitalName= document.getElementById("HospitalName").value;
	var cityName= document.getElementById("CityName").value;
	var stateName= document.getElementById("StateName").value;
	var pinCode= document.getElementById("PinCode").value;
	var STDCode= document.getElementById("STDCode").value;
	var phoneNumber= document.getElementById("PhoneNumber").value;
	var address= document.getElementById("Address").value;
	
	if(address==""|| address==null){
		alert("Please enter the address.");
		document.getElementById("Address").focus();
		return false;
	}
	
	if(!hospitalName.match(/([a-z])/)){
		alert("Please enter only alphabets in Hospital Name.");
		document.getElementById("HospitalName").focus();
		return false;
	}
	
	if(!cityName.match(/([a-z])/)){
		alert("Please enter only alphabets in City Name.");
		document.getElementById("CityName").focus();
		return false;
	}
	
	if(!stateName.match(/([a-z])/)){
		alert("Please enter only alphabets in State Name.");
		document.getElementById("StateName").focus();
		return false;
	}
	
	
	if(isNaN(STDCode)){
		alert("Please enter correct STD Code.");
		document.getElementById("STDCode").focus();
		return false;
	}
	
	if(STDCode.length<=5){
		alert('please enter a valid STD Code of atmost 5 digits');
		document.getElementById("STDCode").focus();
		return false;}
	
	if(pinCode.length!=6){
		alert('please enter a valid pin code of 6 digits');
		document.getElementById("PinCode").focus();
		return false;
		}
	
	if(isNaN(pinCode)){
		alert("Please enter correct Pin Code.");
		document.getElementById("PinCode").focus();
		return false;
	}
	
	if(phoneNumber==""|| phoneNumber==null){
		alert("please enter your phone Number");
		document.getElementById("PhoneNumber").focus();
		return false;}
	if(isNaN(phoneNumber)){
		alert("please enter numeric data as you phone Number");
		document.getElementById("PhoneNumber").focus();
		return false;}
	if(phoneNumber.length!=10){
		alert('please enter a valid phone number of 10 digits');
		document.getElementById("PhoneNumber").focus();
		return false;}
}