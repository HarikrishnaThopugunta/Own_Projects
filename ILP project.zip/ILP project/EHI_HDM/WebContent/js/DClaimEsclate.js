function validation()
{
	var x=document.getElementById("status").value;
	var y=document.getElementById("amount").value;
	var z=document.getElementById("esclate").value;
	var w=document.getElementById("action").value;
	
	if(x=="--select--"){
		  alert("please select status");
		  return false;
	} 
	if(y==""){
		alert('please enter amount');
		return false;
	}
	if(isNaN(y)){
		alert('please enter valid amount');
		return false;
	}
	if(z==""){
		alert('please enter valid characters');
		return false;
	}
	
	if(w==""){
		alert('please enter valid characters');
		return false;
	}
	return true;

}