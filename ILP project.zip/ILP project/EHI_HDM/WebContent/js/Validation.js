function validation()
{

	var claimID=/^[A-Z]+[a-z0-9]+$/;
	var DClaimIdCheck=document.getElementById("claimId").value;
	
	if(DClaimIdCheck==""||claimID.test(DClaimIdCheck)==false)
	{
		alert('Please provide Claim Id.');
		DomiciliaryClaimIdCheck.claimid.focus();
		return false;
	}
	return true;
}


function validate(){
	var claimID=/^[A-Z]+[a-z0-9]+$/;

	var HClaimIdCheck=document.getElementById("claimId").value;
	
	if(HClaimIdCheck==""||claimID.test(HClaimIdCheck)==false)
	{
		alert('Please provide Claim Id.');
		HospitalizationClaimIdCheck.claimid.focus();
		return false;
	}
	return true;
	}
	