function valself() {

	var xmlhttp;
	var id = "self";
	VASform.HIIDdependent.value="";
	var urls = "EmployeeController?name=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			VASform.HIIDdependent.value = xmlhttp.responseText;

		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function val() {
	var xmlhttp;
	var id = VASform.select1.value;
	VASform.HIIDdependent.value="";
	var urls = "EmployeeController?dependentName=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		// alert("outside if" + xmlhttp.readyState + " " + xmlhttp.status);
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				VASform.HIIDdependent.value = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}

function valdependent() {
	var req;
	var id = "dependent";
	VASform.HIIDdependent.value="";
	var url = "EmployeeController?name=" + id;
	if (window.XMLHttpRequest) {
		req = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		req = new ActiveXObject("Microsoft.XMLHTTP");
	}
	req.onreadystatechange = function() {
		if (req.readyState == 4) {
			if (req.status == 200) {
				document.getElementById("select").innerHTML = req.responseText;
			}
		}
	}
	req.open("post", url, true);
	req.send(null);
}

function stateVal() {
	var xmlhttp;
	var id = "state";
	var urls = "EmployeeController?stname=" + id

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera,
		// Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("state").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
	// }
}

function cityVal() {
	var xmlhttp;
	var id = VASform.stateList.value;
	var urls = "EmployeeController?STforCT=" + id;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera,
		// Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				document.getElementById("city").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}
function hospVal() {
	var xmlhttp;
	var id = VASform.cityList.value;
	var id1 = VASform.stateList.value;
	var urls = "EmployeeController?CTforHP=" + id + "&STforCT=" + id1;

	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4) {
			if (xmlhttp.status == 200) {
				if (xmlhttp.responseText == "no match") {
					alert("Please refresh the page.");
				} else
					document.getElementById("hospital").innerHTML = xmlhttp.responseText;
			}
		}
	};
	xmlhttp.open("GET", urls, true);
	xmlhttp.send();
}
