function validation(){
//var employeeid= document.getElementById("employeeid").value;
var employeename= document.getElementById("employeename").value;
var age=document.getElementById("age").value;
var mobilenumber=document.getElementById("mobilenumber").value;
var email=document.getElementById("email").value;
//var date = document.getElementById("date").value;
// var time = document.getElementById("time").value;
//var convert=convertTo24Hour($("time").val().toLowerCase());


var reg=/^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
var letters = /^[A-Za-z]+$/;  

if(employeename==""|| employeename==null){
	alert("please enter your Name");
	document.getElementById("employeename").focus();
	return false;}
if( !employeename.match(letters)){
	
	alert("please enter only alphabets");
	document.getElementById("employeename").focus();
	return false;
	}

if(age==""|| age==null){
	alert("please enter your age");
	document.getElementById("age").focus();
	return false;}

	if(isNaN(age)){
	alert('please enter numeric data as age');
	document.getElementById("age").focus();
	return false;}
	
	if(mobilenumber==""||mobilenumber==null){
		alert('please enter your Mobile Number');
		document.getElementById("mobilenumber").focus();
		return false;}

		if(isNaN(mobilenumber)){
		alert('please enter numeric data as your Mobile Number');
		document.getElementById("mobilenumber").focus();
		return false;}
		if(mobilenumber.length!=10){
			alert('please enter a valid mobile number of 10 digits');
			document.getElementById("mobilenumber").focus();
			return false;
			}
		if(email==""||email==null){
			alert("please enter your email");
			document.getElementById("email").focus();
			return false;}
		if(!email.match(reg)){
			alert("please enter valid email");
			document.getElementById("email").focus();
			return false;
		}
		if(date=="")
		{
			alert('Please Give Preferred Date');
			document.getElementById("date").focus();
			return false;
		}
		 var re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

	    if( !date.match(re)) {
	      alert("Invalid date format: " + date);
	      document.getElementById("date").focus();
	      return false;}
		if(time==""||time==null)
		{
			alert('Please Give "Preferred Time"');
			document.getElementById("time").focus();
			return false;
		}
		 var r = /^\d{1,2}:\d{2}([ap]m)?$/;

		    if(!time.match(r)) {
		      alert("Invalid time format: " + time);
		      document.getElementById("time").focus();
		      return false;
		    }
		    
		  /*  if(!checkDate(form.startdate)){
		    	return false;
		    }
		    if(!checkTime(form.starttime)) {
		    	return false;
		    }*/
}
		/*var d = new Date("February 04, 2011 19:00"),
	     hh = d.getHours(),  mm = d.getMinutes(),  dd = "AM", h = hh;
	    mm=(mm.toString().length == 1)? mm = "0" + mm:mm;
	    h=(h>=12)?hh-12:h;
	     dd=(hh>=12)?"PM":"AM";
	    h=(h == 0)?12:h;
	    var textvalue=document.getElementById("date");
	    textvalue.value=h + ":" + mm + " " + dd;*/

 /*function getDisplayDatetime() {
	    var d = new Date("February 04, 2011 19:00"),
	     hh = d.getHours(),  mm = d.getMinutes(),  dd = "AM", h = hh;
	    mm=(mm.toString().length == 1)? mm = "0" + mm:mm;
	    h=(h>=12)?hh-12:h;
	     dd=(hh>=12)?"PM":"AM";
	    h=(h == 0)?12:h;
	    var textvalue=document.getElementById("date");
	    textvalue.value=h + ":" + mm + " " + dd;
	}
*/

   
function populateDropDown(){	 
	/* Clear the entire subjects drop down*/
	document.getElementById("cityList").options.length = 0;	 
	/* adding a Default "Select" option in Subjects Menu*/
	var optn = document.createElement("OPTION");
	optn.text = "Select City";
	cityList.options.add(optn);	 
	/* This can be changed according to the rest of the code instead of hard coded values*/
	var selectedIndexVal = document.getElementById("stateList").selectedIndex;
	var cityValList =document.getElementById("stateList").options[selectedIndexVal].value;
	var cityValArray=cityValList.split(",");
	for(var j=0;j<cityValArray.length;j++){
	var optn = document.createElement("OPTION");
	optn.text = cityValArray[j];
	optn.value = cityValArray[j];
	cityList.options.add(optn);
	}	 
	}
function switching(val) {
	if(val==1) {
		
		document.getElementById('dependent').style.display='none';
		document.getElementById('self').style.display='block';
	}
	else if(val==2) {
		
		document.getElementById('self').style.display='none';
		document.getElementById('dependent').style.display='block';
	}
}
