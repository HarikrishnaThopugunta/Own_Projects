/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package services;

/**
 *
 * @author VidyaMurali
 */
public class test {
    public static void main(String[] args)

    {
         ss.mail("varunreddy6666@gmail.com","Testing.....................");
    }

}
