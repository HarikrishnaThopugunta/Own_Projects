/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package services;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class Mail {
 protected void service(HttpServletRequest request,
                                  HttpServletResponse response)
                   throws IOException, ServletException {
     String uname=request.getParameter("uname");
      ResultSet rst = null;
        String email = null;
        String key = null;
        try{
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hari","priya");
         rst = con.createStatement().executeQuery("select * from register where uname='"+uname+"'");
        if(rst.next()){
            email = rst.getString("email");
            key = rst.getString("key");
        }
         java.sql.Date d=new java.sql.Date(System.currentTimeMillis());
        PreparedStatement pst=con.prepareStatement("insert into emaildata values(?,?,?,?,?)");
        pst.setString(1,email);
        pst.setString(2,"11");
        pst.setString(3,"12");
        pst.setString(4,key);
        pst.setDate(5, d);
        int i=pst.executeUpdate();
        }
        catch(Exception eea){eea.printStackTrace();}

 ss.mail(email, key);
 }
}